#!/bin/sh
########################################################################
#   5724-E34
#   (c) Copyright IBM Corporation 2008, 2009.
#   All rights reserved.
#
#   The source code for this program is not published or otherwise
#   divested of its trade secrets, irrespective of what has been
#   deposited with the U.S. Copyright Office.
########################################################################

echo --DROP TABLES IN GOSALESRT SCHEMA
echo echo DROPPING TABLE ${GOSALESRT_SCHEMA}.ACTIVITY_STATUS_LOOKUP:
echo @
echo DROP TABLE ${GOSALESRT_SCHEMA}.ACTIVITY_STATUS_LOOKUP
echo @
echo echo DROPPING TABLE ${GOSALESRT_SCHEMA}.RETAILER:
echo @
echo DROP TABLE ${GOSALESRT_SCHEMA}.RETAILER
echo @
echo echo DROPPING TABLE ${GOSALESRT_SCHEMA}.RETAILER_ACTIVITY:
echo @
echo DROP TABLE ${GOSALESRT_SCHEMA}.RETAILER_ACTIVITY
echo @
echo echo DROPPING TABLE ${GOSALESRT_SCHEMA}.RETAILER_CONTACT:
echo @
echo DROP TABLE ${GOSALESRT_SCHEMA}.RETAILER_CONTACT
echo @
echo echo DROPPING TABLE ${GOSALESRT_SCHEMA}.RETAILER_SITE:
echo @
echo DROP TABLE ${GOSALESRT_SCHEMA}.RETAILER_SITE
echo @
echo echo DROPPING TABLE ${GOSALESRT_SCHEMA}.RETAILER_SITE_MB:
echo @
echo DROP TABLE ${GOSALESRT_SCHEMA}.RETAILER_SITE_MB
echo @
echo echo DROPPING TABLE ${GOSALESRT_SCHEMA}.RETAILER_TYPE:
echo @
echo DROP TABLE ${GOSALESRT_SCHEMA}.RETAILER_TYPE
echo @

