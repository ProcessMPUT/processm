#!/bin/sh
##################################################################
#   5724-E34
#   (c) Copyright IBM Corporation 2008, 2009.
#   All rights reserved.
#
#   The source code for this program is not published or otherwise
#   divested of its trade secrets, irrespective of what has been
#   deposited with the U.S. Copyright Office.
##################################################################
#  SetupGSDB.sh
#
# This script accepts the following optional parameters in order
# to allow for automation :
#   -createdb          => creates the database, bufferpools and tablespaces
#                         assumption is made that a userid with permission
#                         to create a database is running this script.
#                         This option will drop any existing database with
#                         the same name before creating the database
#   -database <name>   => overrides the database name
#   -userid <admin userid> => overrides the administrative userid
#   -password <admin passwd> => sets the password for the administrative
#                         userid
#   -noprompt          => indicates that the user should not be prompted
#                         for any information
#   -addComments       => Will only add table comments to existing tables.
#   
#
# Notes
#
# 1) If any of the command line arguments are used, then the script
#    will not prompt the user to confirm information with the exception
#    that if the -userid parameter is used without the -password
#    parameter, the user will be prompted for the password
#
#
#
#
####################################################################

echo "Starting script"

GOSALES_PARENT_DIR=`pwd`
GOSALES_SCRIPT_DIR="${GOSALES_PARENT_DIR}/GS_SCRIPTS"
GOSALES_START=1

#Change to script directory
cd "${GOSALES_SCRIPT_DIR}"

# Call the main run script 
. ./RUN_GOSALES_IMPORT.sh $*

cd ..
