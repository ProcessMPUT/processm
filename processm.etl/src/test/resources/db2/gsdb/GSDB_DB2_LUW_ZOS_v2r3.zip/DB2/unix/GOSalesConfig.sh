#!/bin/sh
########################################################################
#   5724-E34
#   (c) Copyright IBM Corporation 2008, 2009.
#   All rights reserved.
#
#   The source code for this program is not published or otherwise
#   divested of its trade secrets, irrespective of what has been
#   deposited with the U.S. Copyright Office.
########################################################################
#   Filename: GOSalesConfig.sh
#
#   Description :
#      This file contains the default configuration options that
#      are used when creating the GOSALES data.  These options
#      can be modified by the user to alter the configuration of
#      the sample database.
#
########################################################################

########################################################################
#   Enter the name or alias of the database
########################################################################
GOSALES_INST=GSDB

########################################################################
#   OPTIONAL: Create the database(Y/N)?  This will cause
#   an existing database with the same name to be dropped.
########################################################################
GOSALES_CREATEDB=

########################################################################
#   When creating a database this is the territory
#   of the UTF-8 database that is created.
########################################################################
GOSALES_DB_TERRITORY=US

###########################################################################
#   Change to 'Y' if installing in a database partitioned environment (DPF)
###########################################################################
GOSALES_DPF=N

########################################################################
#   OPTIONAL: Enter the buffer pool and tablespace name
#   if you want these to be created by the script
########################################################################
GOSALES_BP=GOSALES_BP
GOSALES_TS=GOSALES_TS

########################################################################
#   Enter the list of users, groups or PUBLIC that will have CONTROL
#   permissions for the GOSALES, GOSALESHR, GOSALESMR, GOSALESRT
#   and GOSALESCT schemas
#   This string needs to follow the syntax of the GRANT command.
#   Examples :
#     1) Provide control access to the user GOSALES and the group DBUSERS
#          GOSALES_GRANTEES=USER GOSALES, GROUP DBUSERS
#     2) Provide control access to everyone using PUBLIC
#          GOSALES_GRANTEES=PUBLIC
#     3) Provide control access to users BOB, JOE and SUE
#          GOSALES_GRANTEES=BOB,JOE,SUE
#
########################################################################
GOSALES_GRANTEES=GOSALES,DB2ADMIN

########################################################################
#   Enter the list of users, groups or PUBLIC that will have CONTROL
#   permissions for the GOSALESDW schema
########################################################################
GOSALESDW_GRANTEES=GOSALESDW,DB2ADMIN

########################################################################
#   Enter the names to use for each schema
########################################################################
GOSALES_SCHEMA=GOSALES
GOSALESHR_SCHEMA=GOSALESHR
GOSALESMR_SCHEMA=GOSALESMR
GOSALESRT_SCHEMA=GOSALESRT
GOSALESCT_SCHEMA=GOSALESCT
GOSALESDW_SCHEMA=GOSALESDW
