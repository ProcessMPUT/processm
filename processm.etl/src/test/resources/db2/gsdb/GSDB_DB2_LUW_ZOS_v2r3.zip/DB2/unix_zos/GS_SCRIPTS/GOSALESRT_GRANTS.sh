#!/bin/sh
########################################################################
#   5724-E34
#   (c) Copyright IBM Corporation 2008, 2009.
#   All rights reserved.
#
#   The source code for this program is not published or otherwise
#   divested of its trade secrets, irrespective of what has been
#   deposited with the U.S. Copyright Office.
########################################################################

echo --CREATE GRANTS FOR GOSALESRT SCHEMA
echo echo CREATING GRANTS ON TABLE ${GOSALESRT_SCHEMA}.ACTIVITY_STATUS_LOOKUP:
echo @
echo  GRANT ALL ON ${GOSALESRT_SCHEMA}.ACTIVITY_STATUS_LOOKUP TO ${GOSALES_GRANTEES}
echo @
echo echo CREATING GRANTS ON TABLE ${GOSALESRT_SCHEMA}.RETAILER:
echo @
echo  GRANT ALL ON ${GOSALESRT_SCHEMA}.RETAILER TO ${GOSALES_GRANTEES}
echo @
echo echo CREATING GRANTS ON TABLE ${GOSALESRT_SCHEMA}.RETAILER_ACTIVITY:
echo @
echo  GRANT ALL ON ${GOSALESRT_SCHEMA}.RETAILER_ACTIVITY TO ${GOSALES_GRANTEES}
echo @
echo echo CREATING GRANTS ON TABLE ${GOSALESRT_SCHEMA}.RETAILER_CONTACT:
echo @
echo  GRANT ALL ON ${GOSALESRT_SCHEMA}.RETAILER_CONTACT TO ${GOSALES_GRANTEES}
echo @
echo echo CREATING GRANTS ON TABLE ${GOSALESRT_SCHEMA}.RETAILER_SITE:
echo @
echo  GRANT ALL ON ${GOSALESRT_SCHEMA}.RETAILER_SITE TO ${GOSALES_GRANTEES}
echo @
echo echo CREATING GRANTS ON TABLE ${GOSALESRT_SCHEMA}.RETAILER_SITE_MB:
echo @
echo  GRANT ALL ON ${GOSALESRT_SCHEMA}.RETAILER_SITE_MB TO ${GOSALES_GRANTEES}
echo @
echo echo CREATING GRANTS ON TABLE ${GOSALESRT_SCHEMA}.RETAILER_TYPE:
echo @
echo  GRANT ALL ON ${GOSALESRT_SCHEMA}.RETAILER_TYPE TO ${GOSALES_GRANTEES}
echo @
echo
