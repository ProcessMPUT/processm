#!/bin/sh
##################################################################
#   5724-E34
#   (c) Copyright IBM Corporation 2008, 2009.
#   All rights reserved.
#
#   The source code for this program is not published or otherwise
#   divested of its trade secrets, irrespective of what has been
#   deposited with the U.S. Copyright Office.
##################################################################
echo ------------------------------------------------
echo -- CREATE THE ${GOSALES_LOB_TS} TABLESPACE
echo ------------------------------------------------
echo
echo CREATE  LOB TABLESPACE  ${GOSALES_LOB_TS} IN ${GOSALES_DB}
echo     USING STOGROUP ${GOSALES_STG}
echo     PRIQTY 1600   
echo     SECQTY 1024
echo     ERASE NO
echo     GBPCACHE SYSTEM
echo     DSSIZE 4G
echo     BUFFERPOOL ${GOSALES_BP}
echo     LOCKSIZE LOB           
echo     LOCKMAX 0
echo     CLOSE YES 
echo @
echo COMMIT
echo @
echo ------------------------------------------------
echo -- CREATE THE ${GOSALES_TS} TABLESPACE
echo ------------------------------------------------
echo
echo CREATE  TABLESPACE  ${GOSALES_TS} IN ${GOSALES_DB}
echo     USING STOGROUP ${GOSALES_STG}
echo     PRIQTY 100000   
echo     SECQTY 100000
echo     ERASE NO
echo     FREEPAGE 0 
echo     PCTFREE 5
echo     TRACKMOD YES
echo     COMPRESS NO   
echo     GBPCACHE CHANGED
echo     SEGSIZE  4
echo     CCSID UNICODE
echo     BUFFERPOOL ${GOSALES_BP}
echo     LOCKSIZE ROW           
echo     LOCKMAX SYSTEM
echo     CLOSE NO 
echo @
echo  COMMIT
echo @
echo
