#!/bin/sh
##################################################################
#   5724-E34
#   (c) Copyright IBM Corporation 2008, 2009.
#   All rights reserved.
#
#   The source code for this program is not published or otherwise
#   divested of its trade secrets, irrespective of what has been
#   deposited with the U.S. Copyright Office.
##################################################################
echo ------------------------------------------------
echo -- CREATE THE "${GOSALES_BP}" BUFFERPOOL
echo ------------------------------------------------
echo
echo CREATE BUFFERPOOL "${GOSALES_BP}" IMMEDIATE SIZE 250 PAGESIZE 16 K
echo @
echo ------------------------------------------------
echo -- CREATE THE "${GOSALES_TS}" TABLESPACE
echo ------------------------------------------------
echo
echo CREATE REGULAR TABLESPACE \"${GOSALES_TS}\" PAGESIZE 16 K MANAGED BY SYSTEM USING \(\'${GOSALES_TS}\'\) BUFFERPOOL ${GOSALES_BP}
echo @
echo
