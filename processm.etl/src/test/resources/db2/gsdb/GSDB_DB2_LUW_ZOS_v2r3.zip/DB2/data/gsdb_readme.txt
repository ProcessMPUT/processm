 *******************************************************************
 *  5724-E34
 *  (c) Copyright IBM Corporation 2008, 2009.
 *  All rights reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************

It is recommended that you use the automation scripts provided to create the GSDB sample database. From the unix directory, run setupGSDB.sh, or from the win folder, run setupGSDB.bat

Alternatively, you can use db2move to load a database, and then a sql file to add grants, constraints, and views.
-- SETUP INSTRUCTIONS FOR DB2MOVE

1. create a database called GSDB. Specify a minimum page size of 16 KB. 

2. Open CLP on the folder or directory containing the ixf files. The files are in the install location under SETUP_SCRIPTS\data. 

3. In CLP execute: db2move GSDB import [-u] <username> [-p] <password>

4. Edit gsdb_constraints.sql at the top of the page to specify a login.

5. In CLP execute: db2 -td~ -f gsdb_constraints.sql -z gsdb_constraints.log 
	
	
NOTES

The PTNR_ACTIVITY table has an XML column and is created when running gsdb_constraints.sql, and not during the db2move.

Rather than use db2admin for basic querying, You may want to create two OS users called gosales and gosalesdw: 
-gsdb_constraints.sql assigns ownership of all transaction system objects to the gosales user. These include objects in the gosales, gosalesct, gosaleshr, gosalesmr, and gosalesrt schemas.
-gsdb_constraints.sql assigns ownership of all warehouse objects to the gosalesdw user. These include objects in the gosalesdw schema.

