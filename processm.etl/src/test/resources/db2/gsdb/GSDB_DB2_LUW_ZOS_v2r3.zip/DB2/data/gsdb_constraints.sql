-- *******************************************************************
-- *  5724-E34
-- *  (c) Copyright IBM Corporation 2008, 2009.
-- *  All rights reserved.
-- *
-- *  The source code for this program is not published or otherwise
-- *  divested of its trade secrets, irrespective of what has been
-- *  deposited with the U.S. Copyright Office.
-- *******************************************************************

connect to GSDB user <user name> using <password>
~

--GRANT AUTHORITIES TO USER GOSALES
GRANT  BINDADD,CONNECT,LOAD ON DATABASE TO USER GOSALES
~


--CREATE TABLE WITH XML DATATYPE
------------------------------------------------
-- DDL Statements for table GOSALESCT.PTNR_ACTIVITY
------------------------------------------------
 
CREATE TABLE GOSALESCT.PTNR_ACTIVITY  (
		  PTNR_CODE INTEGER NOT NULL , 
		  CUST_CODE INTEGER NOT NULL , 
		  CUST_ORDER_NUMBER INTEGER NOT NULL , 
		  PTNR_CUST_ORDER XML NOT NULL )   
		 IN USERSPACE1 ~

-- DDL Statements for primary key on Table GOSALESCT.PTNR_ACTIVITY

ALTER TABLE GOSALESCT.PTNR_ACTIVITY 
	ADD PRIMARY KEY
		(PTNR_CODE,
		 CUST_CODE,
		 CUST_ORDER_NUMBER)~

INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,100022,181649,'<cust_order><cust_code>100022</cust_code><cust_order_number>181649</cust_order_number><cust_order_date>4/9/2007 8:43</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="61110" cust_quantity="1" cust_unit_sale_price="74.91"></cust_order_details1><cust_order_details2 product_number="99110" cust_quantity="1" cust_unit_sale_price="11.64"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,100035,181682,'<cust_order><cust_code>100035</cust_code><cust_order_number>181682</cust_order_number><cust_order_date>4/23/2007 17:11</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="53110" cust_quantity="1" cust_unit_sale_price="66.3"></cust_order_details1><cust_order_details2 product_number="54110" cust_quantity="1" cust_unit_sale_price="103.2"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,100086,181813,'<cust_order><cust_code>100086</cust_code><cust_order_number>181813</cust_order_number><cust_order_date>4/10/2007 0:40</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="99110" cust_quantity="1" cust_unit_sale_price="11.33"></cust_order_details1><cust_order_details2 product_number="10110" cust_quantity="1" cust_unit_sale_price="36"></cust_order_details2><cust_order_details3 product_number="63140" cust_quantity="1" cust_unit_sale_price="78.75"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,100095,181837,'<cust_order><cust_code>100095</cust_code><cust_order_number>181837</cust_order_number><cust_order_date>4/30/2007 16:22</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="25110" cust_quantity="1" cust_unit_sale_price="515.45"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,100126,181919,'<cust_order><cust_code>100126</cust_code><cust_order_number>181919</cust_order_number><cust_order_date>4/11/2007 11:52</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="122130" cust_quantity="1" cust_unit_sale_price="110.21"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,100292,182355,'<cust_order><cust_code>100292</cust_code><cust_order_number>182355</cust_order_number><cust_order_date>5/7/2007 14:41</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="101110" cust_quantity="1" cust_unit_sale_price="1021.16"></cust_order_details1><cust_order_details2 product_number="106110" cust_quantity="1" cust_unit_sale_price="1427.17"></cust_order_details2><cust_order_details3 product_number="109110" cust_quantity="1" cust_unit_sale_price="147.76"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,100347,182491,'<cust_order><cust_code>100347</cust_code><cust_order_number>182491</cust_order_number><cust_order_date>5/2/2007 14:06</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="29110" cust_quantity="1" cust_unit_sale_price="130.33"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,100578,183087,'<cust_order><cust_code>100578</cust_code><cust_order_number>183087</cust_order_number><cust_order_date>5/15/2007 22:41</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="26110" cust_quantity="1" cust_unit_sale_price="687.67"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,100724,183453,'<cust_order><cust_code>100724</cust_code><cust_order_number>183453</cust_order_number><cust_order_date>5/10/2007 21:16</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="11110" cust_quantity="1" cust_unit_sale_price="565.18"></cust_order_details1><cust_order_details2 product_number="96110" cust_quantity="1" cust_unit_sale_price="61.44"></cust_order_details2><cust_order_details3 product_number="17110" cust_quantity="1" cust_unit_sale_price="115.61"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,100738,183494,'<cust_order><cust_code>100738</cust_code><cust_order_number>183494</cust_order_number><cust_order_date>5/9/2007 9:35</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="44110" cust_quantity="1" cust_unit_sale_price="451.63"></cust_order_details1><cust_order_details2 product_number="16110" cust_quantity="2" cust_unit_sale_price="3.78"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,100795,183641,'<cust_order><cust_code>100795</cust_code><cust_order_number>183641</cust_order_number><cust_order_date>5/3/2007 15:43</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="123130" cust_quantity="1" cust_unit_sale_price="56.84"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,100915,183940,'<cust_order><cust_code>100915</cust_code><cust_order_number>183940</cust_order_number><cust_order_date>5/8/2007 22:21</cust_order_date><cust_unique_items>4</cust_unique_items><cust_order_details1 product_number="47110" cust_quantity="1" cust_unit_sale_price="91.54"></cust_order_details1><cust_order_details2 product_number="48110" cust_quantity="1" cust_unit_sale_price="237.22"></cust_order_details2><cust_order_details3 product_number="46110" cust_quantity="1" cust_unit_sale_price="86.6"></cust_order_details3><cust_order_details4 product_number="15110" cust_quantity="1" cust_unit_sale_price="1379.54"></cust_order_details4></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,100949,184028,'<cust_order><cust_code>100949</cust_code><cust_order_number>184028</cust_order_number><cust_order_date>5/22/2007 9:36</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="122130" cust_quantity="1" cust_unit_sale_price="130.71"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,100982,184117,'<cust_order><cust_code>100982</cust_code><cust_order_number>184117</cust_order_number><cust_order_date>5/14/2007 11:53</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="21110" cust_quantity="1" cust_unit_sale_price="93.57"></cust_order_details1><cust_order_details2 product_number="90110" cust_quantity="1" cust_unit_sale_price="20.5"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,101039,184269,'<cust_order><cust_code>101039</cust_code><cust_order_number>184269</cust_order_number><cust_order_date>5/25/2007 12:39</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="132140" cust_quantity="1" cust_unit_sale_price="176.23"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,101090,184402,'<cust_order><cust_code>101090</cust_code><cust_order_number>184402</cust_order_number><cust_order_date>5/30/2007 14:26</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="40110" cust_quantity="1" cust_unit_sale_price="56.42"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,101110,184449,'<cust_order><cust_code>101110</cust_code><cust_order_number>184449</cust_order_number><cust_order_date>5/17/2007 13:34</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="111110" cust_quantity="1" cust_unit_sale_price="333.27"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,101233,184760,'<cust_order><cust_code>101233</cust_code><cust_order_number>184760</cust_order_number><cust_order_date>5/20/2007 11:36</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="76110" cust_quantity="1" cust_unit_sale_price="62.24"></cust_order_details1><cust_order_details2 product_number="2110" cust_quantity="1" cust_unit_sale_price="22.67"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,101292,184906,'<cust_order><cust_code>101292</cust_code><cust_order_number>184906</cust_order_number><cust_order_date>5/23/2007 14:32</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="17110" cust_quantity="1" cust_unit_sale_price="115.61"></cust_order_details1><cust_order_details2 product_number="11110" cust_quantity="1" cust_unit_sale_price="565.18"></cust_order_details2><cust_order_details3 product_number="22110" cust_quantity="1" cust_unit_sale_price="31.72"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,101313,184965,'<cust_order><cust_code>101313</cust_code><cust_order_number>184965</cust_order_number><cust_order_date>5/20/2007 19:10</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="8110" cust_quantity="1" cust_unit_sale_price="277.47"></cust_order_details1><cust_order_details2 product_number="46110" cust_quantity="1" cust_unit_sale_price="88.41"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,101388,185163,'<cust_order><cust_code>101388</cust_code><cust_order_number>185163</cust_order_number><cust_order_date>5/27/2007 11:20</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="83110" cust_quantity="1" cust_unit_sale_price="167.5"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,101405,185206,'<cust_order><cust_code>101405</cust_code><cust_order_number>185206</cust_order_number><cust_order_date>5/28/2007 11:15</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="125160" cust_quantity="1" cust_unit_sale_price="116.2"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,101546,185580,'<cust_order><cust_code>101546</cust_code><cust_order_number>185580</cust_order_number><cust_order_date>5/28/2007 9:17</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="18110" cust_quantity="1" cust_unit_sale_price="212.67"></cust_order_details1><cust_order_details2 product_number="21110" cust_quantity="1" cust_unit_sale_price="93.57"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,101547,185583,'<cust_order><cust_code>101547</cust_code><cust_order_number>185583</cust_order_number><cust_order_date>5/21/2007 22:14</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="4110" cust_quantity="1" cust_unit_sale_price="16.13"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,101568,185631,'<cust_order><cust_code>101568</cust_code><cust_order_number>185631</cust_order_number><cust_order_date>5/17/2007 11:09</cust_order_date><cust_unique_items>4</cust_unique_items><cust_order_details1 product_number="22110" cust_quantity="1" cust_unit_sale_price="31.72"></cust_order_details1><cust_order_details2 product_number="17110" cust_quantity="1" cust_unit_sale_price="115.61"></cust_order_details2><cust_order_details3 product_number="21110" cust_quantity="1" cust_unit_sale_price="91.1"></cust_order_details3><cust_order_details4 product_number="11110" cust_quantity="1" cust_unit_sale_price="565.18"></cust_order_details4></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,101597,185707,'<cust_order><cust_code>101597</cust_code><cust_order_number>185707</cust_order_number><cust_order_date>5/24/2007 12:40</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="81110" cust_quantity="1" cust_unit_sale_price="185.4"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,101695,185975,'<cust_order><cust_code>101695</cust_code><cust_order_number>185975</cust_order_number><cust_order_date>5/2/2007 0:59</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="135130" cust_quantity="1" cust_unit_sale_price="375.11"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,101814,186271,'<cust_order><cust_code>101814</cust_code><cust_order_number>186271</cust_order_number><cust_order_date>5/26/2007 14:00</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="43110" cust_quantity="2" cust_unit_sale_price="309.05"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,101861,186397,'<cust_order><cust_code>101861</cust_code><cust_order_number>186397</cust_order_number><cust_order_date>6/6/2007 13:52</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="74110" cust_quantity="1" cust_unit_sale_price="23.74"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,102061,186895,'<cust_order><cust_code>102061</cust_code><cust_order_number>186895</cust_order_number><cust_order_date>6/20/2007 16:45</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="21110" cust_quantity="1" cust_unit_sale_price="75.37"></cust_order_details1><cust_order_details2 product_number="18110" cust_quantity="1" cust_unit_sale_price="212.43"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,102100,186993,'<cust_order><cust_code>102100</cust_code><cust_order_number>186993</cust_order_number><cust_order_date>6/8/2007 15:03</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="28110" cust_quantity="1" cust_unit_sale_price="66.88"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,102452,187882,'<cust_order><cust_code>102452</cust_code><cust_order_number>187882</cust_order_number><cust_order_date>6/6/2007 0:49</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="12110" cust_quantity="1" cust_unit_sale_price="978.45"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,102606,188275,'<cust_order><cust_code>102606</cust_code><cust_order_number>188275</cust_order_number><cust_order_date>6/1/2007 11:26</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="124110" cust_quantity="1" cust_unit_sale_price="44.44"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,102945,189160,'<cust_order><cust_code>102945</cust_code><cust_order_number>189160</cust_order_number><cust_order_date>6/8/2007 14:43</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="82110" cust_quantity="1" cust_unit_sale_price="59.18"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,103006,189317,'<cust_order><cust_code>103006</cust_code><cust_order_number>189317</cust_order_number><cust_order_date>6/22/2007 20:35</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="45110" cust_quantity="1" cust_unit_sale_price="915.58"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,103172,189733,'<cust_order><cust_code>103172</cust_code><cust_order_number>189733</cust_order_number><cust_order_date>6/17/2007 21:02</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="30110" cust_quantity="1" cust_unit_sale_price="28.8"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,103272,190005,'<cust_order><cust_code>103272</cust_code><cust_order_number>190005</cust_order_number><cust_order_date>6/19/2007 12:55</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="46110" cust_quantity="1" cust_unit_sale_price="86.69"></cust_order_details1><cust_order_details2 product_number="6110" cust_quantity="1" cust_unit_sale_price="226.45"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,103710,191135,'<cust_order><cust_code>103710</cust_code><cust_order_number>191135</cust_order_number><cust_order_date>7/7/2007 16:13</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="85110" cust_quantity="1" cust_unit_sale_price="646.68"></cust_order_details1><cust_order_details2 product_number="76110" cust_quantity="1" cust_unit_sale_price="64.17"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,103815,191408,'<cust_order><cust_code>103815</cust_code><cust_order_number>191408</cust_order_number><cust_order_date>7/6/2007 22:54</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="73110" cust_quantity="1" cust_unit_sale_price="20.47"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,104226,192463,'<cust_order><cust_code>104226</cust_code><cust_order_number>192463</cust_order_number><cust_order_date>7/14/2007 14:35</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="18110" cust_quantity="2" cust_unit_sale_price="211.25"></cust_order_details1><cust_order_details2 product_number="13110" cust_quantity="1" cust_unit_sale_price="860.8"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,104628,193499,'<cust_order><cust_code>104628</cust_code><cust_order_number>193499</cust_order_number><cust_order_date>8/16/2007 0:32</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="2110" cust_quantity="1" cust_unit_sale_price="23.64"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,104834,194021,'<cust_order><cust_code>104834</cust_code><cust_order_number>194021</cust_order_number><cust_order_date>8/26/2007 10:46</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="148110" cust_quantity="1" cust_unit_sale_price="78.74"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,104920,194237,'<cust_order><cust_code>104920</cust_code><cust_order_number>194237</cust_order_number><cust_order_date>8/20/2007 12:33</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="46110" cust_quantity="1" cust_unit_sale_price="114.93"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,105033,194537,'<cust_order><cust_code>105033</cust_code><cust_order_number>194537</cust_order_number><cust_order_date>8/7/2007 21:11</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="84110" cust_quantity="1" cust_unit_sale_price="150.7"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,105228,195043,'<cust_order><cust_code>105228</cust_code><cust_order_number>195043</cust_order_number><cust_order_date>8/15/2007 12:50</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="145130" cust_quantity="1" cust_unit_sale_price="461.26"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,105258,195118,'<cust_order><cust_code>105258</cust_code><cust_order_number>195118</cust_order_number><cust_order_date>9/27/2007 13:05</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="4110" cust_quantity="1" cust_unit_sale_price="15.64"></cust_order_details1><cust_order_details2 product_number="98110" cust_quantity="1" cust_unit_sale_price="12.27"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,105262,195128,'<cust_order><cust_code>105262</cust_code><cust_order_number>195128</cust_order_number><cust_order_date>9/11/2007 11:19</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="49110" cust_quantity="1" cust_unit_sale_price="70.63"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,105279,195173,'<cust_order><cust_code>105279</cust_code><cust_order_number>195173</cust_order_number><cust_order_date>9/2/2007 9:07</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="125130" cust_quantity="1" cust_unit_sale_price="115.24"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,105433,195564,'<cust_order><cust_code>105433</cust_code><cust_order_number>195564</cust_order_number><cust_order_date>9/22/2007 0:05</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="14110" cust_quantity="1" cust_unit_sale_price="1190.07"></cust_order_details1><cust_order_details2 product_number="19110" cust_quantity="1" cust_unit_sale_price="389.59"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,105941,196867,'<cust_order><cust_code>105941</cust_code><cust_order_number>196867</cust_order_number><cust_order_date>10/19/2007 10:43</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="11110" cust_quantity="1" cust_unit_sale_price="584.08"></cust_order_details1><cust_order_details2 product_number="29110" cust_quantity="1" cust_unit_sale_price="135.21"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,106586,198538,'<cust_order><cust_code>106586</cust_code><cust_order_number>198538</cust_order_number><cust_order_date>11/29/2007 18:20</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="88110" cust_quantity="1" cust_unit_sale_price="21.8"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,107074,199790,'<cust_order><cust_code>107074</cust_code><cust_order_number>199790</cust_order_number><cust_order_date>12/3/2007 14:26</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="16110" cust_quantity="8" cust_unit_sale_price="3.36"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,107128,199932,'<cust_order><cust_code>107128</cust_code><cust_order_number>199932</cust_order_number><cust_order_date>12/3/2007 23:43</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="143140" cust_quantity="1" cust_unit_sale_price="80.65"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,107138,199961,'<cust_order><cust_code>107138</cust_code><cust_order_number>199961</cust_order_number><cust_order_date>12/28/2007 18:34</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="14110" cust_quantity="1" cust_unit_sale_price="1190.07"></cust_order_details1><cust_order_details2 product_number="19110" cust_quantity="1" cust_unit_sale_price="389.59"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,107157,200013,'<cust_order><cust_code>107157</cust_code><cust_order_number>200013</cust_order_number><cust_order_date>12/20/2007 11:20</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="127130" cust_quantity="1" cust_unit_sale_price="31.86"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,107183,200080,'<cust_order><cust_code>107183</cust_code><cust_order_number>200080</cust_order_number><cust_order_date>12/1/2007 8:23</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="79110" cust_quantity="1" cust_unit_sale_price="187.52"></cust_order_details1><cust_order_details2 product_number="95110" cust_quantity="1" cust_unit_sale_price="11.41"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,107208,200146,'<cust_order><cust_code>107208</cust_code><cust_order_number>200146</cust_order_number><cust_order_date>12/21/2007 11:12</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="43110" cust_quantity="1" cust_unit_sale_price="272.67"></cust_order_details1><cust_order_details2 product_number="21110" cust_quantity="1" cust_unit_sale_price="82.56"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,107212,200157,'<cust_order><cust_code>107212</cust_code><cust_order_number>200157</cust_order_number><cust_order_date>12/25/2007 15:02</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="46110" cust_quantity="1" cust_unit_sale_price="109.04"></cust_order_details1><cust_order_details2 product_number="47110" cust_quantity="1" cust_unit_sale_price="82.68"></cust_order_details2><cust_order_details3 product_number="48110" cust_quantity="1" cust_unit_sale_price="208.37"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,107439,200738,'<cust_order><cust_code>107439</cust_code><cust_order_number>200738</cust_order_number><cust_order_date>12/25/2007 11:02</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="113110" cust_quantity="1" cust_unit_sale_price="27.03"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,107782,201645,'<cust_order><cust_code>107782</cust_code><cust_order_number>201645</cust_order_number><cust_order_date>12/31/2007 12:32</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="84110" cust_quantity="1" cust_unit_sale_price="150.7"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,107820,201737,'<cust_order><cust_code>107820</cust_code><cust_order_number>201737</cust_order_number><cust_order_date>12/22/2007 8:13</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="124150" cust_quantity="1" cust_unit_sale_price="42.77"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,107962,202088,'<cust_order><cust_code>107962</cust_code><cust_order_number>202088</cust_order_number><cust_order_date>12/6/2007 19:09</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="122140" cust_quantity="1" cust_unit_sale_price="117.91"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,128342,174096,'<cust_order><cust_code>128342</cust_code><cust_order_number>174096</cust_order_number><cust_order_date>1/12/2007 12:53</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="29110" cust_quantity="1" cust_unit_sale_price="141.95"></cust_order_details1><cust_order_details2 product_number="18110" cust_quantity="1" cust_unit_sale_price="217.44"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,128630,174828,'<cust_order><cust_code>128630</cust_code><cust_order_number>174828</cust_order_number><cust_order_date>2/20/2007 21:43</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="106110" cust_quantity="1" cust_unit_sale_price="1217.3"></cust_order_details1><cust_order_details2 product_number="101110" cust_quantity="1" cust_unit_sale_price="954.47"></cust_order_details2><cust_order_details3 product_number="112110" cust_quantity="1" cust_unit_sale_price="28.7"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,128647,174872,'<cust_order><cust_code>128647</cust_code><cust_order_number>174872</cust_order_number><cust_order_date>2/24/2007 12:04</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="153110" cust_quantity="1" cust_unit_sale_price="307.78"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,128796,175259,'<cust_order><cust_code>128796</cust_code><cust_order_number>175259</cust_order_number><cust_order_date>2/20/2007 17:02</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="46110" cust_quantity="1" cust_unit_sale_price="90.78"></cust_order_details1><cust_order_details2 product_number="73110" cust_quantity="1" cust_unit_sale_price="19.75"></cust_order_details2><cust_order_details3 product_number="48110" cust_quantity="1" cust_unit_sale_price="206.71"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,128871,175443,'<cust_order><cust_code>128871</cust_code><cust_order_number>175443</cust_order_number><cust_order_date>2/14/2007 13:01</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="143150" cust_quantity="1" cust_unit_sale_price="77.89"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,128958,175659,'<cust_order><cust_code>128958</cust_code><cust_order_number>175659</cust_order_number><cust_order_date>2/28/2007 15:03</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="125160" cust_quantity="1" cust_unit_sale_price="114.17"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,129005,175785,'<cust_order><cust_code>129005</cust_code><cust_order_number>175785</cust_order_number><cust_order_date>2/17/2007 16:24</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="13110" cust_quantity="1" cust_unit_sale_price="744.74"></cust_order_details1><cust_order_details2 product_number="32110" cust_quantity="1" cust_unit_sale_price="47.69"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,129202,176314,'<cust_order><cust_code>129202</cust_code><cust_order_number>176314</cust_order_number><cust_order_date>2/26/2007 17:27</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="112110" cust_quantity="1" cust_unit_sale_price="29.48"></cust_order_details1><cust_order_details2 product_number="79110" cust_quantity="1" cust_unit_sale_price="167.63"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,129228,176382,'<cust_order><cust_code>129228</cust_code><cust_order_number>176382</cust_order_number><cust_order_date>2/25/2007 17:52</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="33110" cust_quantity="1" cust_unit_sale_price="42.28"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,129295,176546,'<cust_order><cust_code>129295</cust_code><cust_order_number>176546</cust_order_number><cust_order_date>3/29/2007 21:07</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="136140" cust_quantity="1" cust_unit_sale_price="77.85"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,129548,177200,'<cust_order><cust_code>129548</cust_code><cust_order_number>177200</cust_order_number><cust_order_date>3/5/2007 8:00</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="16110" cust_quantity="2" cust_unit_sale_price="3.51"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,129558,177226,'<cust_order><cust_code>129558</cust_code><cust_order_number>177226</cust_order_number><cust_order_date>3/11/2007 16:56</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="85110" cust_quantity="1" cust_unit_sale_price="710.74"></cust_order_details1><cust_order_details2 product_number="95110" cust_quantity="1" cust_unit_sale_price="12.49"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,129573,177268,'<cust_order><cust_code>129573</cust_code><cust_order_number>177268</cust_order_number><cust_order_date>3/29/2007 8:36</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="144170" cust_quantity="1" cust_unit_sale_price="325.58"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,129697,177599,'<cust_order><cust_code>129697</cust_code><cust_order_number>177599</cust_order_number><cust_order_date>3/30/2007 18:00</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="80110" cust_quantity="1" cust_unit_sale_price="378.14"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,129724,177670,'<cust_order><cust_code>129724</cust_code><cust_order_number>177670</cust_order_number><cust_order_date>3/27/2007 15:11</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="50110" cust_quantity="1" cust_unit_sale_price="9.01"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,129764,177769,'<cust_order><cust_code>129764</cust_code><cust_order_number>177769</cust_order_number><cust_order_date>3/10/2007 10:27</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="75110" cust_quantity="1" cust_unit_sale_price="200.61"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,129980,178315,'<cust_order><cust_code>129980</cust_code><cust_order_number>178315</cust_order_number><cust_order_date>4/15/2007 13:41</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="106110" cust_quantity="1" cust_unit_sale_price="1507.54"></cust_order_details1><cust_order_details2 product_number="101110" cust_quantity="1" cust_unit_sale_price="976.58"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,130006,178387,'<cust_order><cust_code>130006</cust_code><cust_order_number>178387</cust_order_number><cust_order_date>4/26/2007 16:39</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="145130" cust_quantity="1" cust_unit_sale_price="401.1"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,130053,178516,'<cust_order><cust_code>130053</cust_code><cust_order_number>178516</cust_order_number><cust_order_date>4/28/2007 18:27</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="67110" cust_quantity="1" cust_unit_sale_price="693.76"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,130143,178743,'<cust_order><cust_code>130143</cust_code><cust_order_number>178743</cust_order_number><cust_order_date>4/23/2007 17:51</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="23110" cust_quantity="1" cust_unit_sale_price="102.77"></cust_order_details1><cust_order_details2 product_number="22110" cust_quantity="1" cust_unit_sale_price="33.7"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,130167,178806,'<cust_order><cust_code>130167</cust_code><cust_order_number>178806</cust_order_number><cust_order_date>4/6/2007 17:39</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="27110" cust_quantity="1" cust_unit_sale_price="770.36"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,130180,178845,'<cust_order><cust_code>130180</cust_code><cust_order_number>178845</cust_order_number><cust_order_date>4/12/2007 18:13</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="48110" cust_quantity="2" cust_unit_sale_price="225.18"></cust_order_details1><cust_order_details2 product_number="98110" cust_quantity="1" cust_unit_sale_price="12.71"></cust_order_details2><cust_order_details3 product_number="73110" cust_quantity="1" cust_unit_sale_price="19.05"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,130232,178981,'<cust_order><cust_code>130232</cust_code><cust_order_number>178981</cust_order_number><cust_order_date>4/24/2007 20:24</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="50110" cust_quantity="2" cust_unit_sale_price="8.3"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,130297,179144,'<cust_order><cust_code>130297</cust_code><cust_order_number>179144</cust_order_number><cust_order_date>4/21/2007 22:34</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="125160" cust_quantity="1" cust_unit_sale_price="127.19"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,130523,179716,'<cust_order><cust_code>130523</cust_code><cust_order_number>179716</cust_order_number><cust_order_date>4/8/2007 14:37</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="113110" cust_quantity="1" cust_unit_sale_price="21.14"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,130834,180508,'<cust_order><cust_code>130834</cust_code><cust_order_number>180508</cust_order_number><cust_order_date>4/3/2007 17:07</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="106110" cust_quantity="1" cust_unit_sale_price="1467.86"></cust_order_details1><cust_order_details2 product_number="101110" cust_quantity="1" cust_unit_sale_price="950.88"></cust_order_details2><cust_order_details3 product_number="114110" cust_quantity="1" cust_unit_sale_price="570.44"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,130836,180515,'<cust_order><cust_code>130836</cust_code><cust_order_number>180515</cust_order_number><cust_order_date>4/1/2007 20:19</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="24110" cust_quantity="1" cust_unit_sale_price="107.35"></cust_order_details1><cust_order_details2 product_number="17110" cust_quantity="1" cust_unit_sale_price="112"></cust_order_details2><cust_order_details3 product_number="10110" cust_quantity="1" cust_unit_sale_price="36"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,130877,180617,'<cust_order><cust_code>130877</cust_code><cust_order_number>180617</cust_order_number><cust_order_date>4/29/2007 21:54</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="2110" cust_quantity="1" cust_unit_sale_price="28.77"></cust_order_details1><cust_order_details2 product_number="83110" cust_quantity="1" cust_unit_sale_price="175.33"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,131049,181055,'<cust_order><cust_code>131049</cust_code><cust_order_number>181055</cust_order_number><cust_order_date>4/2/2007 16:15</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="6110" cust_quantity="1" cust_unit_sale_price="186.34"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,131227,181516,'<cust_order><cust_code>131227</cust_code><cust_order_number>181516</cust_order_number><cust_order_date>4/10/2007 18:40</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="47110" cust_quantity="2" cust_unit_sale_price="87.48"></cust_order_details1><cust_order_details2 product_number="44110" cust_quantity="1" cust_unit_sale_price="554.61"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,131230,181526,'<cust_order><cust_code>131230</cust_code><cust_order_number>181526</cust_order_number><cust_order_date>4/17/2007 8:38</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="28110" cust_quantity="1" cust_unit_sale_price="65.06"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1223,131233,181532,'<cust_order><cust_code>131233</cust_code><cust_order_number>181532</cust_order_number><cust_order_date>4/11/2007 13:01</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="15110" cust_quantity="1" cust_unit_sale_price="1444.96"></cust_order_details1><cust_order_details2 product_number="33110" cust_quantity="1" cust_unit_sale_price="40.66"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,100125,181913,'<cust_order><cust_code>100125</cust_code><cust_order_number>181913</cust_order_number><cust_order_date>4/6/2007 13:29</cust_order_date><cust_unique_items>5</cust_unique_items><cust_order_details1 product_number="10110" cust_quantity="1" cust_unit_sale_price="36"></cust_order_details1><cust_order_details2 product_number="8110" cust_quantity="1" cust_unit_sale_price="264.2"></cust_order_details2><cust_order_details3 product_number="3110" cust_quantity="1" cust_unit_sale_price="36.87"></cust_order_details3><cust_order_details4 product_number="89110" cust_quantity="1" cust_unit_sale_price="19.84"></cust_order_details4><cust_order_details5 product_number="5110" cust_quantity="1" cust_unit_sale_price="75.06"></cust_order_details5></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,100139,181956,'<cust_order><cust_code>100139</cust_code><cust_order_number>181956</cust_order_number><cust_order_date>4/6/2007 16:46</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="53110" cust_quantity="1" cust_unit_sale_price="64.56"></cust_order_details1><cust_order_details2 product_number="72110" cust_quantity="1" cust_unit_sale_price="277.23"></cust_order_details2><cust_order_details3 product_number="55110" cust_quantity="1" cust_unit_sale_price="18.6"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,100562,183050,'<cust_order><cust_code>100562</cust_code><cust_order_number>183050</cust_order_number><cust_order_date>5/19/2007 4:39</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="143150" cust_quantity="1" cust_unit_sale_price="95.08"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,100626,183214,'<cust_order><cust_code>100626</cust_code><cust_order_number>183214</cust_order_number><cust_order_date>5/15/2007 9:38</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="42110" cust_quantity="1" cust_unit_sale_price="272.34"></cust_order_details1><cust_order_details2 product_number="73110" cust_quantity="1" cust_unit_sale_price="16.43"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,100827,183715,'<cust_order><cust_code>100827</cust_code><cust_order_number>183715</cust_order_number><cust_order_date>5/16/2007 2:32</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="27110" cust_quantity="1" cust_unit_sale_price="922.71"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,101274,184862,'<cust_order><cust_code>101274</cust_code><cust_order_number>184862</cust_order_number><cust_order_date>5/24/2007 16:52</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="15110" cust_quantity="1" cust_unit_sale_price="1416.82"></cust_order_details1><cust_order_details2 product_number="29110" cust_quantity="1" cust_unit_sale_price="126.99"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,101502,185470,'<cust_order><cust_code>101502</cust_code><cust_order_number>185470</cust_order_number><cust_order_date>5/14/2007 15:47</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="52110" cust_quantity="1" cust_unit_sale_price="65.34"></cust_order_details1><cust_order_details2 product_number="50110" cust_quantity="1" cust_unit_sale_price="6.59"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,101744,186099,'<cust_order><cust_code>101744</cust_code><cust_order_number>186099</cust_order_number><cust_order_date>5/2/2007 5:46</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="25110" cust_quantity="1" cust_unit_sale_price="435.11"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,101853,186376,'<cust_order><cust_code>101853</cust_code><cust_order_number>186376</cust_order_number><cust_order_date>6/5/2007 11:13</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="14110" cust_quantity="1" cust_unit_sale_price="1026.29"></cust_order_details1><cust_order_details2 product_number="35110" cust_quantity="1" cust_unit_sale_price="38.09"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,101928,186570,'<cust_order><cust_code>101928</cust_code><cust_order_number>186570</cust_order_number><cust_order_date>6/24/2007 4:57</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="47110" cust_quantity="1" cust_unit_sale_price="82.91"></cust_order_details1><cust_order_details2 product_number="45110" cust_quantity="1" cust_unit_sale_price="892.11"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,102758,188675,'<cust_order><cust_code>102758</cust_code><cust_order_number>188675</cust_order_number><cust_order_date>6/20/2007 6:36</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="94110" cust_quantity="1" cust_unit_sale_price="15.02"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,102864,188948,'<cust_order><cust_code>102864</cust_code><cust_order_number>188948</cust_order_number><cust_order_date>6/11/2007 2:31</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="111110" cust_quantity="1" cust_unit_sale_price="384.62"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,103072,189483,'<cust_order><cust_code>103072</cust_code><cust_order_number>189483</cust_order_number><cust_order_date>6/19/2007 10:08</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="28110" cust_quantity="1" cust_unit_sale_price="65.16"></cust_order_details1><cust_order_details2 product_number="3110" cust_quantity="1" cust_unit_sale_price="30.06"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,103143,189660,'<cust_order><cust_code>103143</cust_code><cust_order_number>189660</cust_order_number><cust_order_date>6/16/2007 6:39</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="11110" cust_quantity="1" cust_unit_sale_price="477.28"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,103379,190272,'<cust_order><cust_code>103379</cust_code><cust_order_number>190272</cust_order_number><cust_order_date>6/18/2007 2:26</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="47110" cust_quantity="1" cust_unit_sale_price="81.21"></cust_order_details1><cust_order_details2 product_number="42110" cust_quantity="1" cust_unit_sale_price="267.76"></cust_order_details2><cust_order_details3 product_number="43110" cust_quantity="1" cust_unit_sale_price="269.5"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,103463,190489,'<cust_order><cust_code>103463</cust_code><cust_order_number>190489</cust_order_number><cust_order_date>7/18/2007 0:41</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="145180" cust_quantity="1" cust_unit_sale_price="492.78"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,103839,191474,'<cust_order><cust_code>103839</cust_code><cust_order_number>191474</cust_order_number><cust_order_date>7/3/2007 13:21</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="111110" cust_quantity="1" cust_unit_sale_price="373.73"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,104057,192022,'<cust_order><cust_code>104057</cust_code><cust_order_number>192022</cust_order_number><cust_order_date>7/17/2007 12:25</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="82110" cust_quantity="1" cust_unit_sale_price="59.55"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,104381,192875,'<cust_order><cust_code>104381</cust_code><cust_order_number>192875</cust_order_number><cust_order_date>8/25/2007 4:11</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="27110" cust_quantity="1" cust_unit_sale_price="770.36"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,104458,193072,'<cust_order><cust_code>104458</cust_code><cust_order_number>193072</cust_order_number><cust_order_date>8/8/2007 7:25</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="78110" cust_quantity="1" cust_unit_sale_price="151.67"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,104663,193588,'<cust_order><cust_code>104663</cust_code><cust_order_number>193588</cust_order_number><cust_order_date>8/5/2007 4:04</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="153110" cust_quantity="1" cust_unit_sale_price="390.09"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,104976,194382,'<cust_order><cust_code>104976</cust_code><cust_order_number>194382</cust_order_number><cust_order_date>8/23/2007 5:36</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="29110" cust_quantity="1" cust_unit_sale_price="135.21"></cust_order_details1><cust_order_details2 product_number="22110" cust_quantity="1" cust_unit_sale_price="37.98"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,105055,194591,'<cust_order><cust_code>105055</cust_code><cust_order_number>194591</cust_order_number><cust_order_date>8/29/2007 3:23</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="135120" cust_quantity="1" cust_unit_sale_price="382.64"></cust_order_details1><cust_order_details2 product_number="94110" cust_quantity="1" cust_unit_sale_price="12.25"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,105387,195447,'<cust_order><cust_code>105387</cust_code><cust_order_number>195447</cust_order_number><cust_order_date>9/28/2007 4:11</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="50110" cust_quantity="2" cust_unit_sale_price="7.57"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,105607,196009,'<cust_order><cust_code>105607</cust_code><cust_order_number>196009</cust_order_number><cust_order_date>9/17/2007 10:54</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="33110" cust_quantity="1" cust_unit_sale_price="46.86"></cust_order_details1><cust_order_details2 product_number="15110" cust_quantity="1" cust_unit_sale_price="1173.4"></cust_order_details2><cust_order_details3 product_number="16110" cust_quantity="10" cust_unit_sale_price="3.36"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,105661,196142,'<cust_order><cust_code>105661</cust_code><cust_order_number>196142</cust_order_number><cust_order_date>9/9/2007 5:58</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="19110" cust_quantity="2" cust_unit_sale_price="389.59"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,105759,196386,'<cust_order><cust_code>105759</cust_code><cust_order_number>196386</cust_order_number><cust_order_date>9/30/2007 16:03</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="106110" cust_quantity="1" cust_unit_sale_price="1386.27"></cust_order_details1><cust_order_details2 product_number="112110" cust_quantity="1" cust_unit_sale_price="29.93"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,106192,197510,'<cust_order><cust_code>106192</cust_code><cust_order_number>197510</cust_order_number><cust_order_date>11/3/2007 15:37</cust_order_date><cust_unique_items>4</cust_unique_items><cust_order_details1 product_number="127140" cust_quantity="1" cust_unit_sale_price="36.71"></cust_order_details1><cust_order_details2 product_number="106110" cust_quantity="1" cust_unit_sale_price="1349.79"></cust_order_details2><cust_order_details3 product_number="109110" cust_quantity="1" cust_unit_sale_price="137.43"></cust_order_details3><cust_order_details4 product_number="101110" cust_quantity="1" cust_unit_sale_price="992.72"></cust_order_details4></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,106208,197555,'<cust_order><cust_code>106208</cust_code><cust_order_number>197555</cust_order_number><cust_order_date>11/18/2007 6:45</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="43110" cust_quantity="1" cust_unit_sale_price="267.08"></cust_order_details1><cust_order_details2 product_number="11110" cust_quantity="1" cust_unit_sale_price="568.71"></cust_order_details2><cust_order_details3 product_number="17110" cust_quantity="1" cust_unit_sale_price="133.14"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,106624,198635,'<cust_order><cust_code>106624</cust_code><cust_order_number>198635</cust_order_number><cust_order_date>11/10/2007 0:45</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="148110" cust_quantity="1" cust_unit_sale_price="78.74"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,106625,198637,'<cust_order><cust_code>106625</cust_code><cust_order_number>198637</cust_order_number><cust_order_date>11/20/2007 13:50</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="68220" cust_quantity="1" cust_unit_sale_price="133.76"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,106748,198953,'<cust_order><cust_code>106748</cust_code><cust_order_number>198953</cust_order_number><cust_order_date>11/23/2007 8:29</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="48110" cust_quantity="1" cust_unit_sale_price="219.64"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,106924,199414,'<cust_order><cust_code>106924</cust_code><cust_order_number>199414</cust_order_number><cust_order_date>11/22/2007 12:14</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="48110" cust_quantity="1" cust_unit_sale_price="208.37"></cust_order_details1><cust_order_details2 product_number="43110" cust_quantity="1" cust_unit_sale_price="267.08"></cust_order_details2><cust_order_details3 product_number="45110" cust_quantity="1" cust_unit_sale_price="728.01"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,107037,199693,'<cust_order><cust_code>107037</cust_code><cust_order_number>199693</cust_order_number><cust_order_date>11/13/2007 9:59</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="59110" cust_quantity="2" cust_unit_sale_price="86.73"></cust_order_details1><cust_order_details2 product_number="28110" cust_quantity="1" cust_unit_sale_price="57.97"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,107187,200090,'<cust_order><cust_code>107187</cust_code><cust_order_number>200090</cust_order_number><cust_order_date>12/8/2007 1:31</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="20110" cust_quantity="4" cust_unit_sale_price="281.51"></cust_order_details1><cust_order_details2 product_number="101110" cust_quantity="1" cust_unit_sale_price="992.72"></cust_order_details2><cust_order_details3 product_number="109110" cust_quantity="1" cust_unit_sale_price="137.43"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,107252,200264,'<cust_order><cust_code>107252</cust_code><cust_order_number>200264</cust_order_number><cust_order_date>12/9/2007 14:46</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="12110" cust_quantity="1" cust_unit_sale_price="927.58"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,107310,200416,'<cust_order><cust_code>107310</cust_code><cust_order_number>200416</cust_order_number><cust_order_date>12/29/2007 13:53</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="30110" cust_quantity="1" cust_unit_sale_price="32.55"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,107544,201022,'<cust_order><cust_code>107544</cust_code><cust_order_number>201022</cust_order_number><cust_order_date>12/13/2007 10:16</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="11110" cust_quantity="1" cust_unit_sale_price="584.08"></cust_order_details1><cust_order_details2 product_number="17110" cust_quantity="1" cust_unit_sale_price="136.73"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,107758,201581,'<cust_order><cust_code>107758</cust_code><cust_order_number>201581</cust_order_number><cust_order_date>12/14/2007 8:27</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="32110" cust_quantity="1" cust_unit_sale_price="40.35"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,128176,173673,'<cust_order><cust_code>128176</cust_code><cust_order_number>173673</cust_order_number><cust_order_date>1/14/2007 1:32</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="122110" cust_quantity="1" cust_unit_sale_price="123.05"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,128441,174348,'<cust_order><cust_code>128441</cust_code><cust_order_number>174348</cust_order_number><cust_order_date>1/9/2007 5:30</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="146140" cust_quantity="1" cust_unit_sale_price="202.26"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,128524,174550,'<cust_order><cust_code>128524</cust_code><cust_order_number>174550</cust_order_number><cust_order_date>1/20/2007 16:10</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="135120" cust_quantity="1" cust_unit_sale_price="335.19"></cust_order_details1><cust_order_details2 product_number="18110" cust_quantity="4" cust_unit_sale_price="211.71"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,128684,174970,'<cust_order><cust_code>128684</cust_code><cust_order_number>174970</cust_order_number><cust_order_date>3/2/2007 0:51</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="105110" cust_quantity="1" cust_unit_sale_price="2377.86"></cust_order_details1><cust_order_details2 product_number="113110" cust_quantity="1" cust_unit_sale_price="22.26"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,128888,175485,'<cust_order><cust_code>128888</cust_code><cust_order_number>175485</cust_order_number><cust_order_date>2/11/2007 16:33</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="80110" cust_quantity="1" cust_unit_sale_price="361.21"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,129186,176269,'<cust_order><cust_code>129186</cust_code><cust_order_number>176269</cust_order_number><cust_order_date>2/22/2007 1:18</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="106110" cust_quantity="1" cust_unit_sale_price="1250.2"></cust_order_details1><cust_order_details2 product_number="81110" cust_quantity="1" cust_unit_sale_price="151.78"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,129250,176435,'<cust_order><cust_code>129250</cust_code><cust_order_number>176435</cust_order_number><cust_order_date>3/4/2007 14:37</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="122140" cust_quantity="1" cust_unit_sale_price="131.6"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,129596,177328,'<cust_order><cust_code>129596</cust_code><cust_order_number>177328</cust_order_number><cust_order_date>3/15/2007 3:31</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="122140" cust_quantity="1" cust_unit_sale_price="131.6"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,129915,178154,'<cust_order><cust_code>129915</cust_code><cust_order_number>178154</cust_order_number><cust_order_date>4/24/2007 11:37</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="7110" cust_quantity="1" cust_unit_sale_price="101.18"></cust_order_details1><cust_order_details2 product_number="9110" cust_quantity="1" cust_unit_sale_price="35.51"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,129919,178167,'<cust_order><cust_code>129919</cust_code><cust_order_number>178167</cust_order_number><cust_order_date>4/25/2007 5:21</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="74110" cust_quantity="1" cust_unit_sale_price="24.71"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,130235,178989,'<cust_order><cust_code>130235</cust_code><cust_order_number>178989</cust_order_number><cust_order_date>4/8/2007 8:58</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="14110" cust_quantity="1" cust_unit_sale_price="1247.97"></cust_order_details1><cust_order_details2 product_number="85110" cust_quantity="1" cust_unit_sale_price="648.77"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,130690,180142,'<cust_order><cust_code>130690</cust_code><cust_order_number>180142</cust_order_number><cust_order_date>4/21/2007 10:21</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="39110" cust_quantity="1" cust_unit_sale_price="97.44"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,130712,180190,'<cust_order><cust_code>130712</cust_code><cust_order_number>180190</cust_order_number><cust_order_date>4/25/2007 2:37</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="19110" cust_quantity="1" cust_unit_sale_price="524.57"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,130778,180363,'<cust_order><cust_code>130778</cust_code><cust_order_number>180363</cust_order_number><cust_order_date>4/15/2007 6:52</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="60110" cust_quantity="1" cust_unit_sale_price="34.54"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,130988,180906,'<cust_order><cust_code>130988</cust_code><cust_order_number>180906</cust_order_number><cust_order_date>4/7/2007 5:09</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="81110" cust_quantity="1" cust_unit_sale_price="162.55"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1349,131244,181560,'<cust_order><cust_code>131244</cust_code><cust_order_number>181560</cust_order_number><cust_order_date>4/24/2007 0:36</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="12110" cust_quantity="1" cust_unit_sale_price="1042.11"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,100803,183659,'<cust_order><cust_code>100803</cust_code><cust_order_number>183659</cust_order_number><cust_order_date>5/3/2007 4:26</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="80110" cust_quantity="1" cust_unit_sale_price="317.32"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,100812,183681,'<cust_order><cust_code>100812</cust_code><cust_order_number>183681</cust_order_number><cust_order_date>5/11/2007 12:41</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="102110" cust_quantity="1" cust_unit_sale_price="1591.05"></cust_order_details1><cust_order_details2 product_number="105110" cust_quantity="1" cust_unit_sale_price="2266.28"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,101377,185136,'<cust_order><cust_code>101377</cust_code><cust_order_number>185136</cust_order_number><cust_order_date>5/11/2007 23:46</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="107110" cust_quantity="1" cust_unit_sale_price="2677.77"></cust_order_details1><cust_order_details2 product_number="109110" cust_quantity="1" cust_unit_sale_price="151.75"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,101522,185522,'<cust_order><cust_code>101522</cust_code><cust_order_number>185522</cust_order_number><cust_order_date>5/26/2007 5:03</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="32110" cust_quantity="1" cust_unit_sale_price="47.78"></cust_order_details1><cust_order_details2 product_number="13110" cust_quantity="1" cust_unit_sale_price="899.66"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,101565,185625,'<cust_order><cust_code>101565</cust_code><cust_order_number>185625</cust_order_number><cust_order_date>5/2/2007 9:25</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="25110" cust_quantity="1" cust_unit_sale_price="435.11"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,101634,185807,'<cust_order><cust_code>101634</cust_code><cust_order_number>185807</cust_order_number><cust_order_date>5/11/2007 7:55</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="105110" cust_quantity="1" cust_unit_sale_price="2266.28"></cust_order_details1><cust_order_details2 product_number="113110" cust_quantity="1" cust_unit_sale_price="24.67"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,101740,186088,'<cust_order><cust_code>101740</cust_code><cust_order_number>186088</cust_order_number><cust_order_date>5/29/2007 6:40</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="109110" cust_quantity="1" cust_unit_sale_price="147.76"></cust_order_details1><cust_order_details2 product_number="101110" cust_quantity="1" cust_unit_sale_price="1021.16"></cust_order_details2><cust_order_details3 product_number="106110" cust_quantity="1" cust_unit_sale_price="1427.17"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,101748,186111,'<cust_order><cust_code>101748</cust_code><cust_order_number>186111</cust_order_number><cust_order_date>5/31/2007 7:13</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="81110" cust_quantity="1" cust_unit_sale_price="185.4"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,102036,186834,'<cust_order><cust_code>102036</cust_code><cust_order_number>186834</cust_order_number><cust_order_date>6/28/2007 6:06</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="26110" cust_quantity="1" cust_unit_sale_price="658.13"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,102102,186997,'<cust_order><cust_code>102102</cust_code><cust_order_number>186997</cust_order_number><cust_order_date>6/1/2007 5:46</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="7110" cust_quantity="1" cust_unit_sale_price="83.98"></cust_order_details1><cust_order_details2 product_number="9110" cust_quantity="1" cust_unit_sale_price="29.66"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,102229,187323,'<cust_order><cust_code>102229</cust_code><cust_order_number>187323</cust_order_number><cust_order_date>6/2/2007 21:59</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="28110" cust_quantity="1" cust_unit_sale_price="65.16"></cust_order_details1><cust_order_details2 product_number="3110" cust_quantity="1" cust_unit_sale_price="30.06"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,102502,188015,'<cust_order><cust_code>102502</cust_code><cust_order_number>188015</cust_order_number><cust_order_date>6/9/2007 6:03</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="110110" cust_quantity="1" cust_unit_sale_price="168.13"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,102608,188279,'<cust_order><cust_code>102608</cust_code><cust_order_number>188279</cust_order_number><cust_order_date>6/2/2007 9:26</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="80110" cust_quantity="1" cust_unit_sale_price="348.08"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,102678,188466,'<cust_order><cust_code>102678</cust_code><cust_order_number>188466</cust_order_number><cust_order_date>6/8/2007 22:53</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="147120" cust_quantity="1" cust_unit_sale_price="50.27"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,102721,188576,'<cust_order><cust_code>102721</cust_code><cust_order_number>188576</cust_order_number><cust_order_date>6/7/2007 1:12</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="125130" cust_quantity="1" cust_unit_sale_price="115.24"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,102950,189172,'<cust_order><cust_code>102950</cust_code><cust_order_number>189172</cust_order_number><cust_order_date>6/13/2007 11:00</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="11110" cust_quantity="1" cust_unit_sale_price="465.35"></cust_order_details1><cust_order_details2 product_number="17110" cust_quantity="1" cust_unit_sale_price="129.67"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,103401,190331,'<cust_order><cust_code>103401</cust_code><cust_order_number>190331</cust_order_number><cust_order_date>6/26/2007 7:39</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="56110" cust_quantity="2" cust_unit_sale_price="30.46"></cust_order_details1><cust_order_details2 product_number="13110" cust_quantity="1" cust_unit_sale_price="822.44"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,103421,190378,'<cust_order><cust_code>103421</cust_code><cust_order_number>190378</cust_order_number><cust_order_date>7/14/2007 3:25</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="57110" cust_quantity="1" cust_unit_sale_price="183.03"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,103713,191144,'<cust_order><cust_code>103713</cust_code><cust_order_number>191144</cust_order_number><cust_order_date>7/11/2007 2:24</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="79110" cust_quantity="1" cust_unit_sale_price="192.33"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,103751,191240,'<cust_order><cust_code>103751</cust_code><cust_order_number>191240</cust_order_number><cust_order_date>7/17/2007 22:42</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="127120" cust_quantity="1" cust_unit_sale_price="38"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,104287,192623,'<cust_order><cust_code>104287</cust_code><cust_order_number>192623</cust_order_number><cust_order_date>7/13/2007 10:56</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="13110" cust_quantity="1" cust_unit_sale_price="907.33"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,104360,192822,'<cust_order><cust_code>104360</cust_code><cust_order_number>192822</cust_order_number><cust_order_date>8/12/2007 3:00</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="26110" cust_quantity="1" cust_unit_sale_price="605.95"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,104629,193501,'<cust_order><cust_code>104629</cust_code><cust_order_number>193501</cust_order_number><cust_order_date>8/13/2007 8:21</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="122130" cust_quantity="1" cust_unit_sale_price="119.65"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,104814,193957,'<cust_order><cust_code>104814</cust_code><cust_order_number>193957</cust_order_number><cust_order_date>8/22/2007 12:48</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="71110" cust_quantity="1" cust_unit_sale_price="191.87"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,105382,195437,'<cust_order><cust_code>105382</cust_code><cust_order_number>195437</cust_order_number><cust_order_date>9/28/2007 5:32</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="25110" cust_quantity="1" cust_unit_sale_price="420.77"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,105511,195764,'<cust_order><cust_code>105511</cust_code><cust_order_number>195764</cust_order_number><cust_order_date>9/21/2007 7:13</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="12110" cust_quantity="1" cust_unit_sale_price="927.58"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,105557,195890,'<cust_order><cust_code>105557</cust_code><cust_order_number>195890</cust_order_number><cust_order_date>9/16/2007 5:02</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="11110" cust_quantity="1" cust_unit_sale_price="599.45"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,105657,196133,'<cust_order><cust_code>105657</cust_code><cust_order_number>196133</cust_order_number><cust_order_date>9/2/2007 7:44</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="136150" cust_quantity="1" cust_unit_sale_price="81.9"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,105909,196783,'<cust_order><cust_code>105909</cust_code><cust_order_number>196783</cust_order_number><cust_order_date>10/16/2007 2:17</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="22110" cust_quantity="3" cust_unit_sale_price="36.98"></cust_order_details1><cust_order_details2 product_number="106110" cust_quantity="1" cust_unit_sale_price="1349.79"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,106188,197499,'<cust_order><cust_code>106188</cust_code><cust_order_number>197499</cust_order_number><cust_order_date>11/12/2007 23:12</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="80110" cust_quantity="1" cust_unit_sale_price="349.46"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,106202,197540,'<cust_order><cust_code>106202</cust_code><cust_order_number>197540</cust_order_number><cust_order_date>11/29/2007 7:40</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="70110" cust_quantity="1" cust_unit_sale_price="253.54"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,106958,199495,'<cust_order><cust_code>106958</cust_code><cust_order_number>199495</cust_order_number><cust_order_date>11/4/2007 22:43</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="122140" cust_quantity="1" cust_unit_sale_price="117.91"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,107034,199682,'<cust_order><cust_code>107034</cust_code><cust_order_number>199682</cust_order_number><cust_order_date>11/7/2007 22:11</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="36110" cust_quantity="1" cust_unit_sale_price="61.31"></cust_order_details1><cust_order_details2 product_number="45110" cust_quantity="1" cust_unit_sale_price="743.25"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,107485,200865,'<cust_order><cust_code>107485</cust_code><cust_order_number>200865</cust_order_number><cust_order_date>12/15/2007 21:34</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="48110" cust_quantity="1" cust_unit_sale_price="219.64"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,107504,200920,'<cust_order><cust_code>107504</cust_code><cust_order_number>200920</cust_order_number><cust_order_date>12/3/2007 10:10</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="46110" cust_quantity="2" cust_unit_sale_price="109.04"></cust_order_details1><cust_order_details2 product_number="47110" cust_quantity="1" cust_unit_sale_price="82.68"></cust_order_details2><cust_order_details3 product_number="48110" cust_quantity="1" cust_unit_sale_price="208.37"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,107604,201177,'<cust_order><cust_code>107604</cust_code><cust_order_number>201177</cust_order_number><cust_order_date>12/26/2007 4:38</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="125150" cust_quantity="1" cust_unit_sale_price="133.61"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,107627,201234,'<cust_order><cust_code>107627</cust_code><cust_order_number>201234</cust_order_number><cust_order_date>12/8/2007 10:22</cust_order_date><cust_unique_items>4</cust_unique_items><cust_order_details1 product_number="18110" cust_quantity="1" cust_unit_sale_price="211.25"></cust_order_details1><cust_order_details2 product_number="15110" cust_quantity="1" cust_unit_sale_price="1173.4"></cust_order_details2><cust_order_details3 product_number="42110" cust_quantity="1" cust_unit_sale_price="236.55"></cust_order_details3><cust_order_details4 product_number="16110" cust_quantity="2" cust_unit_sale_price="3.36"></cust_order_details4></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,107666,201333,'<cust_order><cust_code>107666</cust_code><cust_order_number>201333</cust_order_number><cust_order_date>12/15/2007 4:14</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="47110" cust_quantity="1" cust_unit_sale_price="82.68"></cust_order_details1><cust_order_details2 product_number="70120" cust_quantity="1" cust_unit_sale_price="210.5"></cust_order_details2><cust_order_details3 product_number="43110" cust_quantity="1" cust_unit_sale_price="267.08"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,107681,201379,'<cust_order><cust_code>107681</cust_code><cust_order_number>201379</cust_order_number><cust_order_date>12/5/2007 23:14</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="39110" cust_quantity="2" cust_unit_sale_price="95.88"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,107842,201793,'<cust_order><cust_code>107842</cust_code><cust_order_number>201793</cust_order_number><cust_order_date>12/13/2007 21:41</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="122140" cust_quantity="1" cust_unit_sale_price="117.91"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,128123,173531,'<cust_order><cust_code>128123</cust_code><cust_order_number>173531</cust_order_number><cust_order_date>1/7/2007 10:03</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="12110" cust_quantity="1" cust_unit_sale_price="1063.13"></cust_order_details1><cust_order_details2 product_number="94110" cust_quantity="1" cust_unit_sale_price="14.08"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,128254,173878,'<cust_order><cust_code>128254</cust_code><cust_order_number>173878</cust_order_number><cust_order_date>1/5/2007 10:19</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="31110" cust_quantity="1" cust_unit_sale_price="38.33"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,128285,173954,'<cust_order><cust_code>128285</cust_code><cust_order_number>173954</cust_order_number><cust_order_date>1/13/2007 7:34</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="35110" cust_quantity="2" cust_unit_sale_price="40.79"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,128392,174224,'<cust_order><cust_code>128392</cust_code><cust_order_number>174224</cust_order_number><cust_order_date>1/8/2007 22:47</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="122150" cust_quantity="1" cust_unit_sale_price="117.28"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,128732,175095,'<cust_order><cust_code>128732</cust_code><cust_order_number>175095</cust_order_number><cust_order_date>2/26/2007 9:15</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="122140" cust_quantity="1" cust_unit_sale_price="111.88"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,128917,175556,'<cust_order><cust_code>128917</cust_code><cust_order_number>175556</cust_order_number><cust_order_date>2/7/2007 22:27</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="73110" cust_quantity="1" cust_unit_sale_price="20.82"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,128936,175603,'<cust_order><cust_code>128936</cust_code><cust_order_number>175603</cust_order_number><cust_order_date>2/3/2007 10:33</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="10110" cust_quantity="1" cust_unit_sale_price="32.23"></cust_order_details1><cust_order_details2 product_number="100110" cust_quantity="1" cust_unit_sale_price="11.28"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,128968,175683,'<cust_order><cust_code>128968</cust_code><cust_order_number>175683</cust_order_number><cust_order_date>2/2/2007 10:11</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="122150" cust_quantity="1" cust_unit_sale_price="117.28"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,129093,176017,'<cust_order><cust_code>129093</cust_code><cust_order_number>176017</cust_order_number><cust_order_date>2/3/2007 10:54</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="69110" cust_quantity="1" cust_unit_sale_price="257.37"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,129227,176379,'<cust_order><cust_code>129227</cust_code><cust_order_number>176379</cust_order_number><cust_order_date>2/8/2007 3:19</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="13110" cust_quantity="1" cust_unit_sale_price="729.47"></cust_order_details1><cust_order_details2 product_number="32110" cust_quantity="2" cust_unit_sale_price="46.44"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,129311,176588,'<cust_order><cust_code>129311</cust_code><cust_order_number>176588</cust_order_number><cust_order_date>3/18/2007 9:05</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="61110" cust_quantity="1" cust_unit_sale_price="84.8"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,129411,176841,'<cust_order><cust_code>129411</cust_code><cust_order_number>176841</cust_order_number><cust_order_date>3/30/2007 2:10</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="122140" cust_quantity="1" cust_unit_sale_price="131.6"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,129861,178021,'<cust_order><cust_code>129861</cust_code><cust_order_number>178021</cust_order_number><cust_order_date>3/5/2007 5:59</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="101110" cust_quantity="1" cust_unit_sale_price="788.4"></cust_order_details1><cust_order_details2 product_number="106110" cust_quantity="1" cust_unit_sale_price="1188.24"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,130017,178414,'<cust_order><cust_code>130017</cust_code><cust_order_number>178414</cust_order_number><cust_order_date>4/12/2007 1:37</cust_order_date><cust_unique_items>3</cust_unique_items><cust_order_details1 product_number="101110" cust_quantity="1" cust_unit_sale_price="950.88"></cust_order_details1><cust_order_details2 product_number="106110" cust_quantity="1" cust_unit_sale_price="1467.86"></cust_order_details2><cust_order_details3 product_number="110110" cust_quantity="1" cust_unit_sale_price="175.43"></cust_order_details3></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,130044,178491,'<cust_order><cust_code>130044</cust_code><cust_order_number>178491</cust_order_number><cust_order_date>4/6/2007 20:02</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="124120" cust_quantity="1" cust_unit_sale_price="42.62"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,130068,178555,'<cust_order><cust_code>130068</cust_code><cust_order_number>178555</cust_order_number><cust_order_date>4/17/2007 8:26</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="105110" cust_quantity="1" cust_unit_sale_price="2705.22"></cust_order_details1><cust_order_details2 product_number="127140" cust_quantity="1" cust_unit_sale_price="30.89"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,130148,178757,'<cust_order><cust_code>130148</cust_code><cust_order_number>178757</cust_order_number><cust_order_date>4/2/2007 0:48</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="123140" cust_quantity="1" cust_unit_sale_price="57.13"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,130182,178851,'<cust_order><cust_code>130182</cust_code><cust_order_number>178851</cust_order_number><cust_order_date>4/13/2007 12:00</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="25110" cust_quantity="1" cust_unit_sale_price="502.24"></cust_order_details1><cust_order_details2 product_number="11110" cust_quantity="1" cust_unit_sale_price="542.45"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,130301,179153,'<cust_order><cust_code>130301</cust_code><cust_order_number>179153</cust_order_number><cust_order_date>4/29/2007 12:01</cust_order_date><cust_unique_items>2</cust_unique_items><cust_order_details1 product_number="91110" cust_quantity="1" cust_unit_sale_price="11.97"></cust_order_details1><cust_order_details2 product_number="10110" cust_quantity="1" cust_unit_sale_price="36.97"></cust_order_details2></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,130402,179414,'<cust_order><cust_code>130402</cust_code><cust_order_number>179414</cust_order_number><cust_order_date>4/17/2007 10:44</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="11110" cust_quantity="1" cust_unit_sale_price="556.73"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,130617,179945,'<cust_order><cust_code>130617</cust_code><cust_order_number>179945</cust_order_number><cust_order_date>4/26/2007 0:22</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="79110" cust_quantity="1" cust_unit_sale_price="176.6"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,130794,180403,'<cust_order><cust_code>130794</cust_code><cust_order_number>180403</cust_order_number><cust_order_date>4/2/2007 4:52</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="124190" cust_quantity="1" cust_unit_sale_price="65.91"></cust_order_details1></cust_order>') ~
INSERT INTO GOSALESCT.PTNR_ACTIVITY ( PTNR_CODE, CUST_CODE, CUST_ORDER_NUMBER, PTNR_CUST_ORDER ) VALUES ( 1515,131176,181375,'<cust_order><cust_code>131176</cust_code><cust_order_number>181375</cust_order_number><cust_order_date>4/5/2007 22:36</cust_order_date><cust_unique_items>1</cust_unique_items><cust_order_details1 product_number="29110" cust_quantity="1" cust_unit_sale_price="115.5"></cust_order_details1></cust_order>') ~


--GRANT PRIVILEGES TO USER GOSALES
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.BRANCH TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.CONVERSION_RATE TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.COUNTRY TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.CURRENCY_LOOKUP TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.EURO_CONVERSION TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.INVENTORY_LEVELS TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.ORDER_DETAILS TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.ORDER_HEADER TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.ORDER_METHOD TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.PRODUCT TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.PRODUCT_BRAND TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.PRODUCT_COLOR_LOOKUP TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.PRODUCT_FORECAST TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.PRODUCT_LINE TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.PRODUCT_NAME_LOOKUP TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.PRODUCT_SIZE_LOOKUP TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.PRODUCT_TYPE TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.RETURN_REASON TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.RETURNED_ITEM TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.SALES_REGION TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.SALES_TARGET TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.TIME_DIMENSION TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALES.TIME_QUARTER_LOOKUP TO USER GOSALES 
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.DEPARTMENT_LOOKUP TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.EMPLOYEE TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.EMPLOYEE_EXPENSE_DETAIL TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.EMPLOYEE_EXPENSE_PLAN TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.EMPLOYEE_HISTORY TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.EMPLOYEE_SUMMARY TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.EMPLOYEE_SURVEY_RESULTS TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.EMPLOYEE_SURVEY_TARGETS TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.EMPLOYEE_SURVEY_TOPIC TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.EXPENSE_GROUP TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.EXPENSE_TYPE TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.EXPENSE_UNIT TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.GENDER_LOOKUP TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.ORGANIZATION TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.POSITION_DEPARTMENT TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.POSITION_LOOKUP TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.POSITION_SUMMARY TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.RANKING TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.RANKING_RESULTS TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.RECRUITMENT TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.RECRUITMENT_MEDIUM TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.RECRUITMENT_TYPE TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.SATISFACTION_INDEX TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.SUCCESSION_DETAILS TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.SUCCESSOR_STATUS TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.TERMINATION_LOOKUP TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.TRAINING TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESHR.TRAINING_DETAILS TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESMR.PRODUCT_SURVEY_RESULTS TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESMR.PRODUCT_SURVEY_TARGETS TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESMR.PRODUCT_SURVEY_TOPIC TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESMR.PROMOTION_BUNDLE_GROUP TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESMR.PROMOTION_CAMPAIGN TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESMR.PROMOTION_PLAN TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESMR.PROMOTIONS TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESMR.RETAILER_SURVEY_RESULTS TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESMR.RETAILER_SURVEY_TARGETS TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESMR.RETAILER_SURVEY_TOPIC TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESRT.ACTIVITY_STATUS_LOOKUP TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESRT.RETAILER TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESRT.RETAILER_ACTIVITY TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESRT.RETAILER_CONTACT TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESRT.RETAILER_SITE TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESRT.RETAILER_SITE_MB TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESRT.RETAILER_TYPE TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESCT.CUST_CRDT_CARD TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESCT.CUST_CRDT_CHECK TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESCT.CUST_CUSTOMER TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESCT.CUST_INTEREST TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESCT.CUST_INTEREST_LOOKUP TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESCT.CUST_MARITAL_STATUS TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESCT.CUST_ORDER_DETAIL TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESCT.CUST_ORDER_HEADER TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESCT.CUST_ORDER_STATUS TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESCT.CUST_PRICE TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESCT.CUST_PROFESSION TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESCT.GO_CRDT_METHOD TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESCT.GO_SALES_TAX TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESCT.PTNR_ACTIVITY TO USER GOSALES
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESCT.PTNR_CONTACT TO USER GOSALES
~


--ADD G5 CONSTRAINTS
ALTER TABLE gosales.BRANCH  		
	ADD CONSTRAINT FK_BRANCH_762330 FOREIGN KEY	
	(	
		COUNTRY_CODE
	) REFERENCES gosales.COUNTRY (	
		COUNTRY_CODE
	)	
~		
		
ALTER TABLE gosales.CONVERSION_RATE  		
	ADD CONSTRAINT FK_CONVER_529569 FOREIGN KEY	
	(	
		COUNTRY_CODE
	) REFERENCES gosales.COUNTRY (	
		COUNTRY_CODE
	)	
~		
		
ALTER TABLE gosales.COUNTRY  		
	ADD CONSTRAINT FK_COUNTR_633816 FOREIGN KEY	
	(	
		SALES_REGION_CODE
	) REFERENCES gosales.SALES_REGION (	
		SALES_REGION_CODE
	)	
~		
		
ALTER TABLE gosales.CURRENCY_LOOKUP  		
	ADD CONSTRAINT FK_CURREN_709782 FOREIGN KEY	
	(	
		COUNTRY_CODE
	) REFERENCES gosales.COUNTRY (	
		COUNTRY_CODE
	)	
~		
		
ALTER TABLE gosaleshr.EMPLOYEE  		
	ADD CONSTRAINT FK_EMPLOY_380936 FOREIGN KEY	
	(	
		GENDER_CODE
	) REFERENCES gosaleshr.GENDER_LOOKUP (	
		GENDER_CODE
	)	
	ADD CONSTRAINT FK_EMPLOY_330983 FOREIGN KEY	
	(	
		TERMINATION_CODE
	) REFERENCES gosaleshr.TERMINATION_LOOKUP (	
		TERMINATION_CODE
	)	
~		
		
ALTER TABLE gosaleshr.EMPLOYEE_EXPENSE_DETAIL  		
	ADD CONSTRAINT FK_EMPLOY_912800 FOREIGN KEY	
	(	
		EXPENSE_TYPE_CODE
	) REFERENCES gosaleshr.EXPENSE_TYPE (	
		EXPENSE_TYPE_CODE
	)	
~		
		
ALTER TABLE gosaleshr.EMPLOYEE_EXPENSE_PLAN  		
	ADD CONSTRAINT FK_EMPLOY_694509 FOREIGN KEY	
	(	
		EXPENSE_TYPE_CODE
	) REFERENCES gosaleshr.EXPENSE_TYPE (	
		EXPENSE_TYPE_CODE
	)	
	ADD CONSTRAINT FK_EMPLOY_703614 FOREIGN KEY	
	(	
		ORGANIZATION_CODE
	) REFERENCES gosaleshr.ORGANIZATION (	
		ORGANIZATION_CODE
	)	
~		
		
ALTER TABLE gosaleshr.EMPLOYEE_HISTORY  		
	ADD CONSTRAINT FK_EMPLOY_334386 FOREIGN KEY	
	(	
		BRANCH_CODE
	) REFERENCES gosales.BRANCH (	
		BRANCH_CODE
	)	
	ADD CONSTRAINT FK_EMPLOY_586606 FOREIGN KEY	
	(	
		EMPLOYEE_CODE
	) REFERENCES gosaleshr.EMPLOYEE (	
		EMPLOYEE_CODE
	)	
	ADD CONSTRAINT FK_EMPLOY_875544 FOREIGN KEY	
	(	
		ORGANIZATION_CODE
	) REFERENCES gosaleshr.ORGANIZATION (	
		ORGANIZATION_CODE
	)	
	ADD CONSTRAINT FK_EMPLOY_440475 FOREIGN KEY	
	(	
		POSITION_CODE
	) REFERENCES gosaleshr.POSITION_DEPARTMENT (	
		POSITION_CODE
	)	
	ADD CONSTRAINT FK_EMPLOY_529596 FOREIGN KEY	
	(	
		POSITION_CODE
	) REFERENCES gosaleshr.POSITION_LOOKUP (	
		POSITION_CODE
	)	
~		
		
ALTER TABLE gosaleshr.EMPLOYEE_SURVEY_RESULTS  		
	ADD CONSTRAINT FK_EMPLOY_253305 FOREIGN KEY	
	(	
		EMPLOYEE_TOPIC_CODE
	) REFERENCES gosaleshr.EMPLOYEE_SURVEY_TOPIC (	
		EMPLOYEE_TOPIC_CODE
	)	
	ADD CONSTRAINT FK_EMPLOY_824130 FOREIGN KEY	
	(	
		ORGANIZATION_CODE
	) REFERENCES gosaleshr.ORGANIZATION (	
		ORGANIZATION_CODE
	)	
	ADD CONSTRAINT FK_EMPLOY_904462 FOREIGN KEY	
	(	
		POSITION_CODE
	) REFERENCES gosaleshr.POSITION_DEPARTMENT (	
		POSITION_CODE
	)	
	ADD CONSTRAINT FK_EMPLOY_346412 FOREIGN KEY	
	(	
		SATISFACTION_CODE
	) REFERENCES gosaleshr.SATISFACTION_INDEX (	
		SATISFACTION_CODE
	)	
~		
		
ALTER TABLE gosaleshr.EMPLOYEE_SURVEY_TARGETS  		
	ADD CONSTRAINT FK_EMPLOY_202366 FOREIGN KEY	
	(	
		EMPLOYEE_TOPIC_CODE
	) REFERENCES gosaleshr.EMPLOYEE_SURVEY_TOPIC (	
		EMPLOYEE_TOPIC_CODE
	)	
~		
		
ALTER TABLE gosales.EURO_CONVERSION  		
	ADD CONSTRAINT FK_EURO_C_490991 FOREIGN KEY	
	(	
		COUNTRY_CODE
	) REFERENCES gosales.COUNTRY (	
		COUNTRY_CODE
	)	
~		
		
ALTER TABLE gosaleshr.EXPENSE_TYPE  		
	ADD CONSTRAINT FK_EXPENS_442944 FOREIGN KEY	
	(	
		EXPENSE_GROUP_CODE
	) REFERENCES gosaleshr.EXPENSE_GROUP (	
		EXPENSE_GROUP_CODE
	)	
	ADD CONSTRAINT FK_EXPENS_236239 FOREIGN KEY	
	(	
		EXPENSE_UNIT_CODE
	) REFERENCES gosaleshr.EXPENSE_UNIT (	
		EXPENSE_UNIT_CODE
	)	
~		
		
ALTER TABLE gosales.INVENTORY_LEVELS  		
	ADD CONSTRAINT FK_INVENT_826026 FOREIGN KEY	
	(	
		WAREHOUSE_BRANCH_CODE
	) REFERENCES gosales.BRANCH (	
		BRANCH_CODE
	)	
	ADD CONSTRAINT FK_INVENT_448551 FOREIGN KEY	
	(	
		PRODUCT_NUMBER
	) REFERENCES gosales.PRODUCT (	
		PRODUCT_NUMBER
	)	
~		
		
ALTER TABLE gosales.ORDER_DETAILS  		
	ADD CONSTRAINT FK_ORDER__808894 FOREIGN KEY	
	(	
		ORDER_NUMBER
	) REFERENCES gosales.ORDER_HEADER (	
		ORDER_NUMBER
	)	
	ADD CONSTRAINT FK_ORDER__493867 FOREIGN KEY	
	(	
		PRODUCT_NUMBER
	) REFERENCES gosales.PRODUCT (	
		PRODUCT_NUMBER
	)	
~		
		
ALTER TABLE gosales.ORDER_HEADER  		
	ADD CONSTRAINT FK_ORDER__145064 FOREIGN KEY	
	(	
		SALES_BRANCH_CODE
	) REFERENCES gosales.BRANCH (	
		BRANCH_CODE
	)	
	ADD CONSTRAINT FK_ORDER__495714 FOREIGN KEY	
	(	
		ORDER_METHOD_CODE
	) REFERENCES gosales.ORDER_METHOD (	
		ORDER_METHOD_CODE
	)	
	ADD CONSTRAINT FK_ORDER__889102 FOREIGN KEY	
	(	
		RETAILER_CONTACT_CODE
	) REFERENCES gosalesrt.RETAILER_CONTACT (	
		RETAILER_CONTACT_CODE
	)	
	ADD CONSTRAINT FK_ORDER__846456 FOREIGN KEY	
	(	
		RETAILER_SITE_CODE
	) REFERENCES gosalesrt.RETAILER_SITE (	
		RETAILER_SITE_CODE
	)	
	ADD CONSTRAINT FK_ORDER__530657 FOREIGN KEY	
	(	
		RETAILER_SITE_CODE
	) REFERENCES gosalesrt.RETAILER_SITE_MB (	
		RETAILER_SITE_CODE
	)	
~		
		
ALTER TABLE gosaleshr.POSITION_DEPARTMENT  		
	ADD CONSTRAINT FK_POSITI_703492 FOREIGN KEY	
	(	
		DEPARTMENT_CODE
	) REFERENCES gosaleshr.DEPARTMENT_LOOKUP (	
		DEPARTMENT_CODE
	)	
	ADD CONSTRAINT FK_POSITI_379352 FOREIGN KEY	
	(	
		POSITION_CODE
	) REFERENCES gosaleshr.POSITION_LOOKUP (	
		POSITION_CODE
	)	
~		
		
ALTER TABLE gosaleshr.POSITION_SUMMARY  		
	ADD CONSTRAINT FK_POSITI_225800 FOREIGN KEY	
	(	
		ORGANIZATION_CODE
	) REFERENCES gosaleshr.ORGANIZATION (	
		ORGANIZATION_CODE
	)	
	ADD CONSTRAINT FK_POSITI_430244 FOREIGN KEY	
	(	
		POSITION_CODE
	) REFERENCES gosaleshr.POSITION_DEPARTMENT (	
		POSITION_CODE
	)	
~		
		
ALTER TABLE gosales.PRODUCT  		
	ADD CONSTRAINT FK_PRODUC_485977 FOREIGN KEY	
	(	
		PRODUCT_BRAND_CODE
	) REFERENCES gosales.PRODUCT_BRAND (	
		PRODUCT_BRAND_CODE
	)	
	ADD CONSTRAINT FK_PRODUC_287390 FOREIGN KEY	
	(	
		PRODUCT_COLOR_CODE
	) REFERENCES gosales.PRODUCT_COLOR_LOOKUP (	
		PRODUCT_COLOR_CODE
	)	
	ADD CONSTRAINT FK_PRODUC_847323 FOREIGN KEY	
	(	
		PRODUCT_SIZE_CODE
	) REFERENCES gosales.PRODUCT_SIZE_LOOKUP (	
		PRODUCT_SIZE_CODE
	)	
	ADD CONSTRAINT FK_PRODUC_136547 FOREIGN KEY	
	(	
		PRODUCT_TYPE_CODE
	) REFERENCES gosales.PRODUCT_TYPE (	
		PRODUCT_TYPE_CODE
	)	
~		
		
ALTER TABLE gosales.PRODUCT_FORECAST  		
	ADD CONSTRAINT FK_PRODUC_805968 FOREIGN KEY	
	(	
		BRANCH_CODE
	) REFERENCES gosales.BRANCH (	
		BRANCH_CODE
	)	
~		
		
ALTER TABLE gosales.PRODUCT_NAME_LOOKUP  		
	ADD CONSTRAINT FK_PRODUC_245020 FOREIGN KEY	
	(	
		PRODUCT_NUMBER
	) REFERENCES gosales.PRODUCT (	
		PRODUCT_NUMBER
	)	
~		
		
ALTER TABLE gosalesmr.PRODUCT_SURVEY_RESULTS  		
	ADD CONSTRAINT FK_PRODUC_430299 FOREIGN KEY	
	(	
		SALES_BRANCH_CODE
	) REFERENCES gosales.BRANCH (	
		BRANCH_CODE
	)	
	ADD CONSTRAINT FK_PRODUC_450702 FOREIGN KEY	
	(	
		COUNTRY_CODE_RETAILER
	) REFERENCES gosales.COUNTRY (	
		COUNTRY_CODE
	)	
	ADD CONSTRAINT FK_PRODUC_878082 FOREIGN KEY	
	(	
		ORGANIZATION_CODE
	) REFERENCES gosaleshr.ORGANIZATION (	
		ORGANIZATION_CODE
	)	
	ADD CONSTRAINT FK_PRODUC_701387 FOREIGN KEY	
	(	
		PRODUCT_NUMBER
	) REFERENCES gosales.PRODUCT (	
		PRODUCT_NUMBER
	)	
	ADD CONSTRAINT FK_PRODUC_532923 FOREIGN KEY	
	(	
		PRODUCT_TOPIC_CODE
	) REFERENCES gosalesmr.PRODUCT_SURVEY_TOPIC (	
		PRODUCT_TOPIC_CODE
	)	
~		
		
ALTER TABLE gosalesmr.PRODUCT_SURVEY_TARGETS  		
	ADD CONSTRAINT FK_PRODUC_341026 FOREIGN KEY	
	(	
		PRODUCT_NUMBER
	) REFERENCES gosales.PRODUCT (	
		PRODUCT_NUMBER
	)	
	ADD CONSTRAINT FK_PRODUC_579210 FOREIGN KEY	
	(	
		PRODUCT_TOPIC_CODE
	) REFERENCES gosalesmr.PRODUCT_SURVEY_TOPIC (	
		PRODUCT_TOPIC_CODE
	)	
~		
		
ALTER TABLE gosales.PRODUCT_TYPE  		
	ADD CONSTRAINT FK_PRODUC_740979 FOREIGN KEY	
	(	
		PRODUCT_LINE_CODE
	) REFERENCES gosales.PRODUCT_LINE (	
		PRODUCT_LINE_CODE
	)	
~		
		
ALTER TABLE gosalesmr.PROMOTIONS  		
	ADD CONSTRAINT FK_PROMOT_820489 FOREIGN KEY	
	(	
		BUNDLE_GROUP_CODE
	) REFERENCES gosalesmr.PROMOTION_BUNDLE_GROUP (	
		BUNDLE_GROUP_CODE
	)	
	ADD CONSTRAINT FK_PROMOT_737649 FOREIGN KEY	
	(	
		CAMPAIGN_CODE
	) REFERENCES gosalesmr.PROMOTION_CAMPAIGN (	
		CAMPAIGN_CODE
	)	
~		
		
ALTER TABLE gosalesmr.PROMOTION_PLAN  		
	ADD CONSTRAINT FK_PROMOT_647376 FOREIGN KEY	
	(	
		SALES_BRANCH_CODE
	) REFERENCES gosales.BRANCH (	
		BRANCH_CODE
	)	
	ADD CONSTRAINT FK_PROMOT_579766 FOREIGN KEY	
	(	
		COUNTRY_CODE_RETAILER
	) REFERENCES gosales.COUNTRY (	
		COUNTRY_CODE
	)	
	ADD CONSTRAINT FK_PROMOT_204103 FOREIGN KEY	
	(	
		ORGANIZATION_CODE
	) REFERENCES gosaleshr.ORGANIZATION (	
		ORGANIZATION_CODE
	)	
	ADD CONSTRAINT FK_PROMOT_204881 FOREIGN KEY	
	(	
		PRODUCT_NUMBER
	) REFERENCES gosales.PRODUCT (	
		PRODUCT_NUMBER
	)	
	ADD CONSTRAINT FK_PROMOT_936653 FOREIGN KEY	
	(	
		PROMOTION_CODE
	) REFERENCES gosalesmr.PROMOTIONS (	
		PROMOTION_CODE
	)	
~		
		
ALTER TABLE gosaleshr.RANKING_RESULTS  		
	ADD CONSTRAINT FK_RANKIN_133874 FOREIGN KEY	
	(	
		RANKING_CODE
	) REFERENCES gosaleshr.RANKING (	
		RANKING_CODE
	)	
~		
		
ALTER TABLE gosaleshr.RECRUITMENT  		
	ADD CONSTRAINT FK_RECRUI_866580 FOREIGN KEY	
	(	
		BRANCH_CODE
	) REFERENCES gosales.BRANCH (	
		BRANCH_CODE
	)	
	ADD CONSTRAINT FK_RECRUI_364137 FOREIGN KEY	
	(	
		ORGANIZATION_CODE
	) REFERENCES gosaleshr.ORGANIZATION (	
		ORGANIZATION_CODE
	)	
	ADD CONSTRAINT FK_RECRUI_707910 FOREIGN KEY	
	(	
		POSITION_CODE
	) REFERENCES gosaleshr.POSITION_DEPARTMENT (	
		POSITION_CODE
	)	
	ADD CONSTRAINT FK_RECRUI_467546 FOREIGN KEY	
	(	
		RECRUITMENT_MEDIUM_CODE
	) REFERENCES gosaleshr.RECRUITMENT_MEDIUM (	
		RECRUITMENT_MEDIUM_CODE
	)	
~		
		
ALTER TABLE gosalesrt.RETAILER  		
	ADD CONSTRAINT FK_RETAIL_996582 FOREIGN KEY	
	(	
		RETAILER_TYPE_CODE
	) REFERENCES gosalesrt.RETAILER_TYPE (	
		RETAILER_TYPE_CODE
	)	
~		
		
ALTER TABLE gosalesrt.RETAILER_CONTACT  		
	ADD CONSTRAINT FK_RETAIL_925472 FOREIGN KEY	
	(	
		GENDER_CODE
	) REFERENCES gosaleshr.GENDER_LOOKUP (	
		GENDER_CODE
	)	
	ADD CONSTRAINT FK_RETAIL_563251 FOREIGN KEY	
	(	
		RETAILER_SITE_CODE
	) REFERENCES gosalesrt.RETAILER_SITE (	
		RETAILER_SITE_CODE
	)	
	ADD CONSTRAINT FK_RETAIL_300440 FOREIGN KEY	
	(	
		RETAILER_SITE_CODE
	) REFERENCES gosalesrt.RETAILER_SITE_MB (	
		RETAILER_SITE_CODE
	)	
~		
		
ALTER TABLE gosalesrt.RETAILER_SITE  		
	ADD CONSTRAINT FK_RETAIL_653881 FOREIGN KEY	
	(	
		RTL_COUNTRY_CODE
	) REFERENCES gosales.COUNTRY (	
		COUNTRY_CODE
	)	
	ADD CONSTRAINT FK_RETAIL_828681 FOREIGN KEY	
	(	
		RETAILER_CODE
	) REFERENCES gosalesrt.RETAILER (	
		RETAILER_CODE
	)	
~		
		
ALTER TABLE gosalesrt.RETAILER_SITE_MB  		
	ADD CONSTRAINT FK_RETAIL_744284 FOREIGN KEY	
	(	
		RTL_COUNTRY_CODE
	) REFERENCES gosales.COUNTRY (	
		COUNTRY_CODE
	)	
	ADD CONSTRAINT FK_RETAIL_113066 FOREIGN KEY	
	(	
		RETAILER_CODE
	) REFERENCES gosalesrt.RETAILER (	
		RETAILER_CODE
	)	
~		
		
ALTER TABLE gosalesmr.RETAILER_SURVEY_RESULTS  		
	ADD CONSTRAINT FK_RETAIL_444187 FOREIGN KEY	
	(	
		SALES_BRANCH_CODE
	) REFERENCES gosales.BRANCH (	
		BRANCH_CODE
	)	
	ADD CONSTRAINT FK_RETAIL_105761 FOREIGN KEY	
	(	
		COUNTRY_CODE_RETAILER
	) REFERENCES gosales.COUNTRY (	
		COUNTRY_CODE
	)	
	ADD CONSTRAINT FK_RETAIL_626086 FOREIGN KEY	
	(	
		ORGANIZATION_CODE
	) REFERENCES gosaleshr.ORGANIZATION (	
		ORGANIZATION_CODE
	)	
	ADD CONSTRAINT FK_RETAIL_256822 FOREIGN KEY	
	(	
		RETAILER_CODE
	) REFERENCES gosalesrt.RETAILER (	
		RETAILER_CODE
	)	
	ADD CONSTRAINT FK_RETAIL_163544 FOREIGN KEY	
	(	
		RETAILER_TOPIC_CODE
	) REFERENCES gosalesmr.RETAILER_SURVEY_TOPIC (	
		RETAILER_TOPIC_CODE
	)	
~		
		
ALTER TABLE gosalesmr.RETAILER_SURVEY_TARGETS  		
	ADD CONSTRAINT FK_RETAIL_415938 FOREIGN KEY	
	(	
		RETAILER_TOPIC_CODE
	) REFERENCES gosalesmr.RETAILER_SURVEY_TOPIC (	
		RETAILER_TOPIC_CODE
	)	
~		
		
ALTER TABLE gosales.RETURNED_ITEM  		
	ADD CONSTRAINT FK_RETURN_442469 FOREIGN KEY	
	(	
		ORDER_DETAIL_CODE
	) REFERENCES gosales.ORDER_DETAILS (	
		ORDER_DETAIL_CODE
	)	
	ADD CONSTRAINT FK_RETURN_611388 FOREIGN KEY	
	(	
		RETURN_REASON_CODE
	) REFERENCES gosales.RETURN_REASON (	
		RETURN_REASON_CODE
	)	
~		
		
ALTER TABLE gosales.SALES_TARGET  		
	ADD CONSTRAINT FK_SALES__796460 FOREIGN KEY	
	(	
		COUNTRY_CODE_RETAILER
	) REFERENCES gosales.COUNTRY (	
		COUNTRY_CODE
	)	
	ADD CONSTRAINT FK_SALES__628427 FOREIGN KEY	
	(	
		PRODUCT_BRAND_CODE
	) REFERENCES gosales.PRODUCT_BRAND (	
		PRODUCT_BRAND_CODE
	)	
	ADD CONSTRAINT FK_SALES__737318 FOREIGN KEY	
	(	
		PRODUCT_TYPE_CODE
	) REFERENCES gosales.PRODUCT_TYPE (	
		PRODUCT_TYPE_CODE
	)	
	ADD CONSTRAINT FK_SALES__670744 FOREIGN KEY	
	(	
		RETAILER_CODE
	) REFERENCES gosalesrt.RETAILER (	
		RETAILER_CODE
	)	
~		
		
ALTER TABLE gosaleshr.SUCCESSION_DETAILS  		
	ADD CONSTRAINT FK_SUCCES_741261 FOREIGN KEY	
	(	
		POSITION_CODE
	) REFERENCES gosaleshr.POSITION_DEPARTMENT (	
		POSITION_CODE
	)	
	ADD CONSTRAINT FK_SUCCES_390394 FOREIGN KEY	
	(	
		SUCCESSOR_STATUS_CODE
	) REFERENCES gosaleshr.SUCCESSOR_STATUS (	
		SUCCESSOR_STATUS_CODE
	)	
~		
		
ALTER TABLE gosales.TIME_DIMENSION  		
	ADD CONSTRAINT FK_TIME_D_145187 FOREIGN KEY	
	(	
		QUARTER_KEY
	) REFERENCES gosales.TIME_QUARTER_LOOKUP (	
		QUARTER_KEY
	)	
~		
		
ALTER TABLE gosaleshr.TRAINING_DETAILS  		
	ADD CONSTRAINT FK_TRAINI_532036 FOREIGN KEY	
	(	
		COURSE_CODE
	) REFERENCES gosaleshr.TRAINING (	
		COURSE_CODE
	)	
~		

-- DDL Statements for foreign keys on Table "GOSALESCT"."CUST_ORDER_DETAIL" ********************************************

ALTER TABLE "GOSALESCT"."CUST_ORDER_DETAIL" 
	ADD CONSTRAINT "FK_116195464" FOREIGN KEY
		("CUST_ORDER_NUMBER")
	REFERENCES "GOSALESCT"."CUST_ORDER_HEADER"
		("CUST_ORDER_NUMBER")
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	NOT ENFORCED
	ENABLE QUERY OPTIMIZATION
~

ALTER TABLE "GOSALESCT"."CUST_ORDER_DETAIL" 
	ADD CONSTRAINT "FK_980198542" FOREIGN KEY
		("PRODUCT_NUMBER")
	REFERENCES "GOSALES "."PRODUCT"
		("PRODUCT_NUMBER")
~


-- DDL Statements for foreign keys on Table "GOSALESCT"."CUST_ORDER_HEADER"

ALTER TABLE "GOSALESCT"."CUST_ORDER_HEADER" 
	ADD CONSTRAINT "FK_1028198713" FOREIGN KEY
		("ORDER_METHOD_CODE")
	REFERENCES "GOSALES "."ORDER_METHOD"
		("ORDER_METHOD_CODE")
~

ALTER TABLE "GOSALESCT"."CUST_ORDER_HEADER" 
	ADD CONSTRAINT "FK_1140199112" FOREIGN KEY
		("CUST_CODE")
	REFERENCES "GOSALESCT"."CUST_CUSTOMER"
		("CUST_CODE")
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	ENFORCED
	ENABLE QUERY OPTIMIZATION
~

ALTER TABLE "GOSALESCT"."CUST_ORDER_HEADER" 
	ADD CONSTRAINT "FK_132195521" FOREIGN KEY
		("CUST_CC_ID")
	REFERENCES "GOSALESCT"."CUST_CRDT_CARD"
		("CUST_CC_ID")
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	ENFORCED
	ENABLE QUERY OPTIMIZATION
~

-- DDL Statements for foreign keys on Table "GOSALESCT"."PTNR_ACTIVITY"

ALTER TABLE "GOSALESCT"."PTNR_ACTIVITY" 
	ADD CONSTRAINT "FK_1124199055" FOREIGN KEY
		("CUST_CODE")
	REFERENCES "GOSALESCT"."CUST_CUSTOMER"
		("CUST_CODE")
~

ALTER TABLE "GOSALESCT"."PTNR_ACTIVITY" 
	ADD CONSTRAINT "FK_212195806" FOREIGN KEY
		("CUST_ORDER_NUMBER")
	REFERENCES "GOSALESCT"."CUST_ORDER_HEADER"
		("CUST_ORDER_NUMBER")
~

ALTER TABLE "GOSALESCT"."PTNR_ACTIVITY" 
	ADD CONSTRAINT "FK_215105846" FOREIGN KEY 
		("PTNR_CODE") 
	REFERENCES "GOSALESCT"."PTNR_CONTACT"
		 ("PTNR_CODE")
~


-- DDL Statements for foreign keys on Table "GOSALESCT"."PTNR_CONTACT"

ALTER TABLE "GOSALESCT"."PTNR_CONTACT" 
	ADD CONSTRAINT "FK_5424592378" FOREIGN KEY
		("PTNR_COUNTRY_CODE")
	REFERENCES "GOSALESCT"."CUST_COUNTRY"
		("COUNTRY_CODE")
~


-- DDL Statements for foreign keys on Table "GOSALESCT"."CUST_CRDT_CARD"

ALTER TABLE "GOSALESCT"."CUST_CRDT_CARD" 
	ADD CONSTRAINT "FK_1204199340" FOREIGN KEY
		("CUST_CODE")
	REFERENCES "GOSALESCT"."CUST_CUSTOMER"
		("CUST_CODE")
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	ENFORCED
	ENABLE QUERY OPTIMIZATION
~

-- DDL Statements for foreign keys on Table "GOSALESCT"."CUST_PRICE"

ALTER TABLE "GOSALESCT"."CUST_PRICE"
	ADD CONSTRAINT "FK_7314115361" FOREIGN KEY
		("PRODUCT_NUMBER")
	REFERENCES "GOSALES"."PRODUCT"
		("PRODUCT_NUMBER")
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	ENFORCED
	ENABLE QUERY OPTIMIZATION
~

-- DDL Statements for foreign keys on Table "GOSALESCT"."CUST_CRDT_CHECK"

ALTER TABLE "GOSALESCT"."CUST_CRDT_CHECK" 
	ADD CONSTRAINT "FK_1324109617" FOREIGN KEY
		("CUST_CODE")
	REFERENCES "GOSALESCT"."CUST_CUSTOMER"
		("CUST_CODE")
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	ENFORCED
	ENABLE QUERY OPTIMIZATION
~


-- DDL Statements for foreign keys on Table "GOSALESCT"."CUST_CUSTOMER"

ALTER TABLE "GOSALESCT"."CUST_CUSTOMER" 
	ADD CONSTRAINT "FK_1092198941" FOREIGN KEY
		("CUST_COUNTRY_CODE")
	REFERENCES "GOSALESCT"."CUST_COUNTRY"
		("COUNTRY_CODE")
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	ENFORCED
	ENABLE QUERY OPTIMIZATION
~



-- DDL Statements for foreign keys on Table "GOSALESCT"."CUST_INTEREST"

ALTER TABLE "GOSALESCT"."CUST_INTEREST" 
	ADD CONSTRAINT "FK_1172199226" FOREIGN KEY
		("CUST_CODE")
	REFERENCES "GOSALESCT"."CUST_CUSTOMER"
		("CUST_CODE")
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	ENFORCED
	ENABLE QUERY OPTIMIZATION
~


-- CREATE VIEWS FOR CUSTOMER SCHEMA

CREATE VIEW gosalesct.VIEW_CUSTOMER_INFO_DE
AS
SELECT     CUST.CUST_CODE, CUST.CUST_FIRST_NAME, CUST.CUST_LAST_NAME, CUST.CUST_ADDRESS1, CUST.CUST_ADDRESS2, CUST.CUST_CITY, 
                      CUST.CUST_PROV_STATE, CUST.CUST_PROV_STATE_CODE, CUST.CUST_POSTAL_ZONE, CUST.CUST_COUNTRY_CODE, 
                      CUST.CUST_PHONE_NUMBER, CUST.CUST_EMAIL, CUST.CUST_INFO, GENDER_LOOKUP.GENDER_DE AS GENDER, CUST.CUST_AGE, 
                      CASE WHEN CUST_AGE IS NULL THEN NULL WHEN CUST_AGE < 19 THEN '< 19' WHEN CUST_AGE >= 19 AND 
                      CUST_AGE < 30 THEN '19 - 29' WHEN CUST_AGE >= 30 AND CUST_AGE < 40 THEN '30 - 39' WHEN CUST_AGE >= 40 AND 
                      CUST_AGE < 50 THEN '40 - 49' WHEN CUST_AGE >= 50 THEN '50 +' END AS AGE_RANGE, MARITAL.MARITAL_STATUS, 
                      PROF_LOOKUP.CUST_PROFESSION, INTEREST_LOOKUP.CUST_INTEREST
FROM         gosalesct.CUST_CUSTOMER CUST INNER JOIN
                      gosalesct.CUST_MARITAL_STATUS MARITAL ON CUST.MARITAL_STATUS_CODE = MARITAL.MARITAL_STATUS_CODE INNER JOIN
                      gosalesct.CUST_PROFESSION PROF_LOOKUP ON CUST.CUST_PROFESSION_CODE = PROF_LOOKUP.CUST_PROFESSION_CODE INNER JOIN
                      gosaleshr.GENDER_LOOKUP GENDER_LOOKUP ON CUST.GENDER_CODE = GENDER_LOOKUP.GENDER_CODE INNER JOIN
                      gosalesct.CUST_INTEREST INTEREST ON CUST.CUST_CODE = INTEREST.CUST_CODE INNER JOIN
                      gosalesct.CUST_INTEREST_LOOKUP INTEREST_LOOKUP ON 
                      INTEREST.CUST_INTEREST_CODE = INTEREST_LOOKUP.CUST_INTEREST_CODE
WHERE     (MARITAL.MARITAL_STATUS_LANGUAGE = N'DE') AND (PROF_LOOKUP.CUST_PROFESSION_LANGUAGE = N'DE') AND 
                      (INTEREST.CUST_INTEREST_RANK = 1) AND (INTEREST_LOOKUP.CUST_INTEREST_LANGUAGE = N'DE')
~

CREATE VIEW gosalesct.VIEW_CUSTOMER_INFO_EN
AS
SELECT     CUST.CUST_CODE, CUST.CUST_FIRST_NAME, CUST.CUST_LAST_NAME, CUST.CUST_ADDRESS1, CUST.CUST_ADDRESS2, CUST.CUST_CITY, 
                      CUST.CUST_PROV_STATE, CUST.CUST_PROV_STATE_CODE, CUST.CUST_POSTAL_ZONE, CUST.CUST_COUNTRY_CODE, 
                      CUST.CUST_PHONE_NUMBER, CUST.CUST_EMAIL, CUST.CUST_INFO, GENDER_LOOKUP.GENDER_EN AS GENDER, CUST.CUST_AGE, 
                      CASE WHEN CUST_AGE IS NULL THEN NULL WHEN CUST_AGE < 19 THEN '< 19' WHEN CUST_AGE >= 19 AND 
                      CUST_AGE < 30 THEN '19 - 29' WHEN CUST_AGE >= 30 AND CUST_AGE < 40 THEN '30 - 39' WHEN CUST_AGE >= 40 AND 
                      CUST_AGE < 50 THEN '40 - 49' WHEN CUST_AGE >= 50 THEN '50 +' END AS AGE_RANGE, MARITAL.MARITAL_STATUS, 
                      PROF_LOOKUP.CUST_PROFESSION, INTEREST_LOOKUP.CUST_INTEREST
FROM         gosalesct.CUST_CUSTOMER CUST INNER JOIN
                      gosalesct.CUST_MARITAL_STATUS MARITAL ON CUST.MARITAL_STATUS_CODE = MARITAL.MARITAL_STATUS_CODE INNER JOIN
                      gosalesct.CUST_PROFESSION PROF_LOOKUP ON CUST.CUST_PROFESSION_CODE = PROF_LOOKUP.CUST_PROFESSION_CODE INNER JOIN
                      gosaleshr.GENDER_LOOKUP GENDER_LOOKUP ON CUST.GENDER_CODE = GENDER_LOOKUP.GENDER_CODE INNER JOIN
                      gosalesct.CUST_INTEREST INTEREST ON CUST.CUST_CODE = INTEREST.CUST_CODE INNER JOIN
                      gosalesct.CUST_INTEREST_LOOKUP INTEREST_LOOKUP ON 
                      INTEREST.CUST_INTEREST_CODE = INTEREST_LOOKUP.CUST_INTEREST_CODE
WHERE     (MARITAL.MARITAL_STATUS_LANGUAGE = N'EN') AND (PROF_LOOKUP.CUST_PROFESSION_LANGUAGE = N'EN') AND 
                      (INTEREST.CUST_INTEREST_RANK = 1) AND (INTEREST_LOOKUP.CUST_INTEREST_LANGUAGE = N'EN')
~

CREATE VIEW gosalesct.VIEW_CUSTOMER_INFO_ES
AS
SELECT     CUST.CUST_CODE, CUST.CUST_FIRST_NAME, CUST.CUST_LAST_NAME, CUST.CUST_ADDRESS1, CUST.CUST_ADDRESS2, CUST.CUST_CITY, 
                      CUST.CUST_PROV_STATE, CUST.CUST_PROV_STATE_CODE, CUST.CUST_POSTAL_ZONE, CUST.CUST_COUNTRY_CODE, 
                      CUST.CUST_PHONE_NUMBER, CUST.CUST_EMAIL, CUST.CUST_INFO, GENDER_LOOKUP.GENDER_ES AS GENDER, CUST.CUST_AGE, 
                      CASE WHEN CUST_AGE IS NULL THEN NULL WHEN CUST_AGE < 19 THEN '< 19' WHEN CUST_AGE >= 19 AND 
                      CUST_AGE < 30 THEN '19 - 29' WHEN CUST_AGE >= 30 AND CUST_AGE < 40 THEN '30 - 39' WHEN CUST_AGE >= 40 AND 
                      CUST_AGE < 50 THEN '40 - 49' WHEN CUST_AGE >= 50 THEN '50 +' END AS AGE_RANGE, MARITAL.MARITAL_STATUS, 
                      PROF_LOOKUP.CUST_PROFESSION, INTEREST_LOOKUP.CUST_INTEREST
FROM         gosalesct.CUST_CUSTOMER CUST INNER JOIN
                      gosalesct.CUST_MARITAL_STATUS MARITAL ON CUST.MARITAL_STATUS_CODE = MARITAL.MARITAL_STATUS_CODE INNER JOIN
                      gosalesct.CUST_PROFESSION PROF_LOOKUP ON CUST.CUST_PROFESSION_CODE = PROF_LOOKUP.CUST_PROFESSION_CODE INNER JOIN
                      gosaleshr.GENDER_LOOKUP GENDER_LOOKUP ON CUST.GENDER_CODE = GENDER_LOOKUP.GENDER_CODE INNER JOIN
                      gosalesct.CUST_INTEREST INTEREST ON CUST.CUST_CODE = INTEREST.CUST_CODE INNER JOIN
                      gosalesct.CUST_INTEREST_LOOKUP INTEREST_LOOKUP ON 
                      INTEREST.CUST_INTEREST_CODE = INTEREST_LOOKUP.CUST_INTEREST_CODE
WHERE     (MARITAL.MARITAL_STATUS_LANGUAGE = N'ES') AND (PROF_LOOKUP.CUST_PROFESSION_LANGUAGE = N'ES') AND 
                      (INTEREST.CUST_INTEREST_RANK = 1) AND (INTEREST_LOOKUP.CUST_INTEREST_LANGUAGE = N'ES')
~

CREATE VIEW gosalesct.VIEW_CUSTOMER_INFO_FR
AS
SELECT     CUST.CUST_CODE, CUST.CUST_FIRST_NAME, CUST.CUST_LAST_NAME, CUST.CUST_ADDRESS1, CUST.CUST_ADDRESS2, CUST.CUST_CITY, 
                      CUST.CUST_PROV_STATE, CUST.CUST_PROV_STATE_CODE, CUST.CUST_POSTAL_ZONE, CUST.CUST_COUNTRY_CODE, 
                      CUST.CUST_PHONE_NUMBER, CUST.CUST_EMAIL, CUST.CUST_INFO, GENDER_LOOKUP.GENDER_FR AS GENDER, CUST.CUST_AGE, 
                      CASE WHEN CUST_AGE IS NULL THEN NULL WHEN CUST_AGE < 19 THEN '< 19' WHEN CUST_AGE >= 19 AND 
                      CUST_AGE < 30 THEN '19 - 29' WHEN CUST_AGE >= 30 AND CUST_AGE < 40 THEN '30 - 39' WHEN CUST_AGE >= 40 AND 
                      CUST_AGE < 50 THEN '40 - 49' WHEN CUST_AGE >= 50 THEN '50 +' END AS AGE_RANGE, MARITAL.MARITAL_STATUS, 
                      PROF_LOOKUP.CUST_PROFESSION, INTEREST_LOOKUP.CUST_INTEREST
FROM         gosalesct.CUST_CUSTOMER CUST INNER JOIN
                      gosalesct.CUST_MARITAL_STATUS MARITAL ON CUST.MARITAL_STATUS_CODE = MARITAL.MARITAL_STATUS_CODE INNER JOIN
                      gosalesct.CUST_PROFESSION PROF_LOOKUP ON CUST.CUST_PROFESSION_CODE = PROF_LOOKUP.CUST_PROFESSION_CODE INNER JOIN
                      gosaleshr.GENDER_LOOKUP GENDER_LOOKUP ON CUST.GENDER_CODE = GENDER_LOOKUP.GENDER_CODE INNER JOIN
                      gosalesct.CUST_INTEREST INTEREST ON CUST.CUST_CODE = INTEREST.CUST_CODE INNER JOIN
                      gosalesct.CUST_INTEREST_LOOKUP INTEREST_LOOKUP ON 
                      INTEREST.CUST_INTEREST_CODE = INTEREST_LOOKUP.CUST_INTEREST_CODE
WHERE     (MARITAL.MARITAL_STATUS_LANGUAGE = N'FR') AND (PROF_LOOKUP.CUST_PROFESSION_LANGUAGE = N'FR') AND 
                      (INTEREST.CUST_INTEREST_RANK = 1) AND (INTEREST_LOOKUP.CUST_INTEREST_LANGUAGE = N'FR')
~

CREATE VIEW gosalesct.VIEW_CUSTOMER_INFO_IT
AS
SELECT     CUST.CUST_CODE, CUST.CUST_FIRST_NAME, CUST.CUST_LAST_NAME, CUST.CUST_ADDRESS1, CUST.CUST_ADDRESS2, CUST.CUST_CITY, 
                      CUST.CUST_PROV_STATE, CUST.CUST_PROV_STATE_CODE, CUST.CUST_POSTAL_ZONE, CUST.CUST_COUNTRY_CODE, 
                      CUST.CUST_PHONE_NUMBER, CUST.CUST_EMAIL, CUST.CUST_INFO, GENDER_LOOKUP.GENDER_IT AS GENDER, CUST.CUST_AGE, 
                      CASE WHEN CUST_AGE IS NULL THEN NULL WHEN CUST_AGE < 19 THEN '< 19' WHEN CUST_AGE >= 19 AND 
                      CUST_AGE < 30 THEN '19 - 29' WHEN CUST_AGE >= 30 AND CUST_AGE < 40 THEN '30 - 39' WHEN CUST_AGE >= 40 AND 
                      CUST_AGE < 50 THEN '40 - 49' WHEN CUST_AGE >= 50 THEN '50 +' END AS AGE_RANGE, MARITAL.MARITAL_STATUS, 
                      PROF_LOOKUP.CUST_PROFESSION, INTEREST_LOOKUP.CUST_INTEREST
FROM         gosalesct.CUST_CUSTOMER CUST INNER JOIN
                      gosalesct.CUST_MARITAL_STATUS MARITAL ON CUST.MARITAL_STATUS_CODE = MARITAL.MARITAL_STATUS_CODE INNER JOIN
                      gosalesct.CUST_PROFESSION PROF_LOOKUP ON CUST.CUST_PROFESSION_CODE = PROF_LOOKUP.CUST_PROFESSION_CODE INNER JOIN
                      gosaleshr.GENDER_LOOKUP GENDER_LOOKUP ON CUST.GENDER_CODE = GENDER_LOOKUP.GENDER_CODE INNER JOIN
                      gosalesct.CUST_INTEREST INTEREST ON CUST.CUST_CODE = INTEREST.CUST_CODE INNER JOIN
                      gosalesct.CUST_INTEREST_LOOKUP INTEREST_LOOKUP ON 
                      INTEREST.CUST_INTEREST_CODE = INTEREST_LOOKUP.CUST_INTEREST_CODE
WHERE     (MARITAL.MARITAL_STATUS_LANGUAGE = N'IT') AND (PROF_LOOKUP.CUST_PROFESSION_LANGUAGE = N'IT') AND 
                      (INTEREST.CUST_INTEREST_RANK = 1) AND (INTEREST_LOOKUP.CUST_INTEREST_LANGUAGE = N'IT')
~

CREATE VIEW gosalesct.VIEW_CUSTOMER_INFO_JA
AS
SELECT     CUST.CUST_CODE, CUST.CUST_FIRST_NAME, CUST.CUST_LAST_NAME, CUST.CUST_ADDRESS1, CUST.CUST_ADDRESS2, CUST.CUST_CITY, 
                      CUST.CUST_PROV_STATE, CUST.CUST_PROV_STATE_CODE, CUST.CUST_POSTAL_ZONE, CUST.CUST_COUNTRY_CODE, 
                      CUST.CUST_PHONE_NUMBER, CUST.CUST_EMAIL, CUST.CUST_INFO, GENDER_LOOKUP.GENDER_JA AS GENDER, CUST.CUST_AGE, 
                      CASE WHEN CUST_AGE IS NULL THEN NULL WHEN CUST_AGE < 19 THEN '< 19' WHEN CUST_AGE >= 19 AND 
                      CUST_AGE < 30 THEN '19 - 29' WHEN CUST_AGE >= 30 AND CUST_AGE < 40 THEN '30 - 39' WHEN CUST_AGE >= 40 AND 
                      CUST_AGE < 50 THEN '40 - 49' WHEN CUST_AGE >= 50 THEN '50 +' END AS AGE_RANGE, MARITAL.MARITAL_STATUS, 
                      PROF_LOOKUP.CUST_PROFESSION, INTEREST_LOOKUP.CUST_INTEREST
FROM         gosalesct.CUST_CUSTOMER CUST INNER JOIN
                      gosalesct.CUST_MARITAL_STATUS MARITAL ON CUST.MARITAL_STATUS_CODE = MARITAL.MARITAL_STATUS_CODE INNER JOIN
                      gosalesct.CUST_PROFESSION PROF_LOOKUP ON CUST.CUST_PROFESSION_CODE = PROF_LOOKUP.CUST_PROFESSION_CODE INNER JOIN
                      gosaleshr.GENDER_LOOKUP GENDER_LOOKUP ON CUST.GENDER_CODE = GENDER_LOOKUP.GENDER_CODE INNER JOIN
                      gosalesct.CUST_INTEREST INTEREST ON CUST.CUST_CODE = INTEREST.CUST_CODE INNER JOIN
                      gosalesct.CUST_INTEREST_LOOKUP INTEREST_LOOKUP ON 
                      INTEREST.CUST_INTEREST_CODE = INTEREST_LOOKUP.CUST_INTEREST_CODE
WHERE     (MARITAL.MARITAL_STATUS_LANGUAGE = N'JA') AND (PROF_LOOKUP.CUST_PROFESSION_LANGUAGE = N'JA') AND 
                      (INTEREST.CUST_INTEREST_RANK = 1) AND (INTEREST_LOOKUP.CUST_INTEREST_LANGUAGE = N'JA')
~

CREATE VIEW gosalesct.VIEW_CUSTOMER_INFO_KO
AS
SELECT     CUST.CUST_CODE, CUST.CUST_FIRST_NAME, CUST.CUST_LAST_NAME, CUST.CUST_ADDRESS1, CUST.CUST_ADDRESS2, CUST.CUST_CITY, 
                      CUST.CUST_PROV_STATE, CUST.CUST_PROV_STATE_CODE, CUST.CUST_POSTAL_ZONE, CUST.CUST_COUNTRY_CODE, 
                      CUST.CUST_PHONE_NUMBER, CUST.CUST_EMAIL, CUST.CUST_INFO, GENDER_LOOKUP.GENDER_KO AS GENDER, CUST.CUST_AGE, 
                      CASE WHEN CUST_AGE IS NULL THEN NULL WHEN CUST_AGE < 19 THEN '< 19' WHEN CUST_AGE >= 19 AND 
                      CUST_AGE < 30 THEN '19 - 29' WHEN CUST_AGE >= 30 AND CUST_AGE < 40 THEN '30 - 39' WHEN CUST_AGE >= 40 AND 
                      CUST_AGE < 50 THEN '40 - 49' WHEN CUST_AGE >= 50 THEN '50 +' END AS AGE_RANGE, MARITAL.MARITAL_STATUS, 
                      PROF_LOOKUP.CUST_PROFESSION, INTEREST_LOOKUP.CUST_INTEREST
FROM         gosalesct.CUST_CUSTOMER CUST INNER JOIN
                      gosalesct.CUST_MARITAL_STATUS MARITAL ON CUST.MARITAL_STATUS_CODE = MARITAL.MARITAL_STATUS_CODE INNER JOIN
                      gosalesct.CUST_PROFESSION PROF_LOOKUP ON CUST.CUST_PROFESSION_CODE = PROF_LOOKUP.CUST_PROFESSION_CODE INNER JOIN
                      gosaleshr.GENDER_LOOKUP GENDER_LOOKUP ON CUST.GENDER_CODE = GENDER_LOOKUP.GENDER_CODE INNER JOIN
                      gosalesct.CUST_INTEREST INTEREST ON CUST.CUST_CODE = INTEREST.CUST_CODE INNER JOIN
                      gosalesct.CUST_INTEREST_LOOKUP INTEREST_LOOKUP ON 
                      INTEREST.CUST_INTEREST_CODE = INTEREST_LOOKUP.CUST_INTEREST_CODE
WHERE     (MARITAL.MARITAL_STATUS_LANGUAGE = N'KO') AND (PROF_LOOKUP.CUST_PROFESSION_LANGUAGE = N'KO') AND 
                      (INTEREST.CUST_INTEREST_RANK = 1) AND (INTEREST_LOOKUP.CUST_INTEREST_LANGUAGE = N'KO')
~

CREATE VIEW gosalesct.VIEW_CUSTOMER_INFO_PT
AS
SELECT     CUST.CUST_CODE, CUST.CUST_FIRST_NAME, CUST.CUST_LAST_NAME, CUST.CUST_ADDRESS1, CUST.CUST_ADDRESS2, CUST.CUST_CITY, 
                      CUST.CUST_PROV_STATE, CUST.CUST_PROV_STATE_CODE, CUST.CUST_POSTAL_ZONE, CUST.CUST_COUNTRY_CODE, 
                      CUST.CUST_PHONE_NUMBER, CUST.CUST_EMAIL, CUST.CUST_INFO, GENDER_LOOKUP.GENDER_PT AS GENDER, CUST.CUST_AGE, 
                      CASE WHEN CUST_AGE IS NULL THEN NULL WHEN CUST_AGE < 19 THEN '< 19' WHEN CUST_AGE >= 19 AND 
                      CUST_AGE < 30 THEN '19 - 29' WHEN CUST_AGE >= 30 AND CUST_AGE < 40 THEN '30 - 39' WHEN CUST_AGE >= 40 AND 
                      CUST_AGE < 50 THEN '40 - 49' WHEN CUST_AGE >= 50 THEN '50 +' END AS AGE_RANGE, MARITAL.MARITAL_STATUS, 
                      PROF_LOOKUP.CUST_PROFESSION, INTEREST_LOOKUP.CUST_INTEREST
FROM         gosalesct.CUST_CUSTOMER CUST INNER JOIN
                      gosalesct.CUST_MARITAL_STATUS MARITAL ON CUST.MARITAL_STATUS_CODE = MARITAL.MARITAL_STATUS_CODE INNER JOIN
                      gosalesct.CUST_PROFESSION PROF_LOOKUP ON CUST.CUST_PROFESSION_CODE = PROF_LOOKUP.CUST_PROFESSION_CODE INNER JOIN
                      gosaleshr.GENDER_LOOKUP GENDER_LOOKUP ON CUST.GENDER_CODE = GENDER_LOOKUP.GENDER_CODE INNER JOIN
                      gosalesct.CUST_INTEREST INTEREST ON CUST.CUST_CODE = INTEREST.CUST_CODE INNER JOIN
                      gosalesct.CUST_INTEREST_LOOKUP INTEREST_LOOKUP ON 
                      INTEREST.CUST_INTEREST_CODE = INTEREST_LOOKUP.CUST_INTEREST_CODE
WHERE     (MARITAL.MARITAL_STATUS_LANGUAGE = N'PT') AND (PROF_LOOKUP.CUST_PROFESSION_LANGUAGE = N'PT') AND 
                      (INTEREST.CUST_INTEREST_RANK = 1) AND (INTEREST_LOOKUP.CUST_INTEREST_LANGUAGE = N'PT')
~

CREATE VIEW gosalesct.VIEW_CUSTOMER_INFO_RU
AS
SELECT     CUST.CUST_CODE, CUST.CUST_FIRST_NAME, CUST.CUST_LAST_NAME, CUST.CUST_ADDRESS1, CUST.CUST_ADDRESS2, CUST.CUST_CITY, 
                      CUST.CUST_PROV_STATE, CUST.CUST_PROV_STATE_CODE, CUST.CUST_POSTAL_ZONE, CUST.CUST_COUNTRY_CODE, 
                      CUST.CUST_PHONE_NUMBER, CUST.CUST_EMAIL, CUST.CUST_INFO, GENDER_LOOKUP.GENDER_RU AS GENDER, CUST.CUST_AGE, 
                      CASE WHEN CUST_AGE IS NULL THEN NULL WHEN CUST_AGE < 19 THEN '< 19' WHEN CUST_AGE >= 19 AND 
                      CUST_AGE < 30 THEN '19 - 29' WHEN CUST_AGE >= 30 AND CUST_AGE < 40 THEN '30 - 39' WHEN CUST_AGE >= 40 AND 
                      CUST_AGE < 50 THEN '40 - 49' WHEN CUST_AGE >= 50 THEN '50 +' END AS AGE_RANGE, MARITAL.MARITAL_STATUS, 
                      PROF_LOOKUP.CUST_PROFESSION, INTEREST_LOOKUP.CUST_INTEREST
FROM         gosalesct.CUST_CUSTOMER CUST INNER JOIN
                      gosalesct.CUST_MARITAL_STATUS MARITAL ON CUST.MARITAL_STATUS_CODE = MARITAL.MARITAL_STATUS_CODE INNER JOIN
                      gosalesct.CUST_PROFESSION PROF_LOOKUP ON CUST.CUST_PROFESSION_CODE = PROF_LOOKUP.CUST_PROFESSION_CODE INNER JOIN
                      gosaleshr.GENDER_LOOKUP GENDER_LOOKUP ON CUST.GENDER_CODE = GENDER_LOOKUP.GENDER_CODE INNER JOIN
                      gosalesct.CUST_INTEREST INTEREST ON CUST.CUST_CODE = INTEREST.CUST_CODE INNER JOIN
                      gosalesct.CUST_INTEREST_LOOKUP INTEREST_LOOKUP ON 
                      INTEREST.CUST_INTEREST_CODE = INTEREST_LOOKUP.CUST_INTEREST_CODE
WHERE     (MARITAL.MARITAL_STATUS_LANGUAGE = N'RU') AND (PROF_LOOKUP.CUST_PROFESSION_LANGUAGE = N'RU') AND 
                      (INTEREST.CUST_INTEREST_RANK = 1) AND (INTEREST_LOOKUP.CUST_INTEREST_LANGUAGE = N'RU')
~

CREATE VIEW gosalesct.VIEW_CUSTOMER_INFO_SC
AS
SELECT     CUST.CUST_CODE, CUST.CUST_FIRST_NAME, CUST.CUST_LAST_NAME, CUST.CUST_ADDRESS1, CUST.CUST_ADDRESS2, CUST.CUST_CITY, 
                      CUST.CUST_PROV_STATE, CUST.CUST_PROV_STATE_CODE, CUST.CUST_POSTAL_ZONE, CUST.CUST_COUNTRY_CODE, 
                      CUST.CUST_PHONE_NUMBER, CUST.CUST_EMAIL, CUST.CUST_INFO, GENDER_LOOKUP.GENDER_SC AS GENDER, CUST.CUST_AGE, 
                      CASE WHEN CUST_AGE IS NULL THEN NULL WHEN CUST_AGE < 19 THEN '< 19' WHEN CUST_AGE >= 19 AND 
                      CUST_AGE < 30 THEN '19 - 29' WHEN CUST_AGE >= 30 AND CUST_AGE < 40 THEN '30 - 39' WHEN CUST_AGE >= 40 AND 
                      CUST_AGE < 50 THEN '40 - 49' WHEN CUST_AGE >= 50 THEN '50 +' END AS AGE_RANGE, MARITAL.MARITAL_STATUS, 
                      PROF_LOOKUP.CUST_PROFESSION, INTEREST_LOOKUP.CUST_INTEREST
FROM         gosalesct.CUST_CUSTOMER CUST INNER JOIN
                      gosalesct.CUST_MARITAL_STATUS MARITAL ON CUST.MARITAL_STATUS_CODE = MARITAL.MARITAL_STATUS_CODE INNER JOIN
                      gosalesct.CUST_PROFESSION PROF_LOOKUP ON CUST.CUST_PROFESSION_CODE = PROF_LOOKUP.CUST_PROFESSION_CODE INNER JOIN
                      gosaleshr.GENDER_LOOKUP GENDER_LOOKUP ON CUST.GENDER_CODE = GENDER_LOOKUP.GENDER_CODE INNER JOIN
                      gosalesct.CUST_INTEREST INTEREST ON CUST.CUST_CODE = INTEREST.CUST_CODE INNER JOIN
                      gosalesct.CUST_INTEREST_LOOKUP INTEREST_LOOKUP ON 
                      INTEREST.CUST_INTEREST_CODE = INTEREST_LOOKUP.CUST_INTEREST_CODE
WHERE     (MARITAL.MARITAL_STATUS_LANGUAGE = N'SC') AND (PROF_LOOKUP.CUST_PROFESSION_LANGUAGE = N'SC') AND 
                      (INTEREST.CUST_INTEREST_RANK = 1) AND (INTEREST_LOOKUP.CUST_INTEREST_LANGUAGE = N'SC')
~

CREATE VIEW gosalesct.VIEW_CUSTOMER_INFO_TC
AS
SELECT     CUST.CUST_CODE, CUST.CUST_FIRST_NAME, CUST.CUST_LAST_NAME, CUST.CUST_ADDRESS1, CUST.CUST_ADDRESS2, CUST.CUST_CITY, 
                      CUST.CUST_PROV_STATE, CUST.CUST_PROV_STATE_CODE, CUST.CUST_POSTAL_ZONE, CUST.CUST_COUNTRY_CODE, 
                      CUST.CUST_PHONE_NUMBER, CUST.CUST_EMAIL, CUST.CUST_INFO, GENDER_LOOKUP.GENDER_TC AS GENDER, CUST.CUST_AGE, 
                      CASE WHEN CUST_AGE IS NULL THEN NULL WHEN CUST_AGE < 19 THEN '< 19' WHEN CUST_AGE >= 19 AND 
                      CUST_AGE < 30 THEN '19 - 29' WHEN CUST_AGE >= 30 AND CUST_AGE < 40 THEN '30 - 39' WHEN CUST_AGE >= 40 AND 
                      CUST_AGE < 50 THEN '40 - 49' WHEN CUST_AGE >= 50 THEN '50 +' END AS AGE_RANGE, MARITAL.MARITAL_STATUS, 
                      PROF_LOOKUP.CUST_PROFESSION, INTEREST_LOOKUP.CUST_INTEREST
FROM         gosalesct.CUST_CUSTOMER CUST INNER JOIN
                      gosalesct.CUST_MARITAL_STATUS MARITAL ON CUST.MARITAL_STATUS_CODE = MARITAL.MARITAL_STATUS_CODE INNER JOIN
                      gosalesct.CUST_PROFESSION PROF_LOOKUP ON CUST.CUST_PROFESSION_CODE = PROF_LOOKUP.CUST_PROFESSION_CODE INNER JOIN
                      gosaleshr.GENDER_LOOKUP GENDER_LOOKUP ON CUST.GENDER_CODE = GENDER_LOOKUP.GENDER_CODE INNER JOIN
                      gosalesct.CUST_INTEREST INTEREST ON CUST.CUST_CODE = INTEREST.CUST_CODE INNER JOIN
                      gosalesct.CUST_INTEREST_LOOKUP INTEREST_LOOKUP ON 
                      INTEREST.CUST_INTEREST_CODE = INTEREST_LOOKUP.CUST_INTEREST_CODE
WHERE     (MARITAL.MARITAL_STATUS_LANGUAGE = N'TC') AND (PROF_LOOKUP.CUST_PROFESSION_LANGUAGE = N'TC') AND 
                      (INTEREST.CUST_INTEREST_RANK = 1) AND (INTEREST_LOOKUP.CUST_INTEREST_LANGUAGE = N'TC')
~

CREATE VIEW gosales.VIEW_PRODUCT_DETAILS_DE
AS
SELECT     gosales.PRODUCT.PRODUCT_NUMBER AS PRODUCT_NUMBER, gosales.PRODUCT.BASE_PRODUCT_NUMBER AS BASE_PRODUCT_NUMBER, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NAME AS PRODUCT_NAME, gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_DE AS COLOR, 
                      gosales.PRODUCT_BRAND.PRODUCT_BRAND_DE AS BRAND, gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_DE AS PRODUCT_SIZE, 
                      gosales.PRODUCT_TYPE.PRODUCT_TYPE_DE AS PRODUCT_TYPE, gosales.PRODUCT_LINE.PRODUCT_LINE_DE AS PRODUCT_LINE, 
                      gosales.PRODUCT_LINE.PRODUCT_LINE_CODE AS PRODUCT_LINE_CODE, gosales.PRODUCT.PRODUCT_TYPE_CODE AS PRODUCT_TYPE_CODE, 
                      gosales.PRODUCT.PRODUCT_BRAND_CODE AS PRODUCT_BRAND_CODE, 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE AS PRODUCT_COLOR_CODE, gosales.PRODUCT.PRODUCT_SIZE_CODE AS PRODUCT_SIZE_CODE, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_DESCRIPTION AS PRODUCT_DESCRIPTION, 
                      gosales.PRODUCT.INTRODUCTION_DATE AS INTRODUCTION_DATE, gosales.PRODUCT.DISCONTINUED_DATE AS DISCONTINUED_DATE
FROM         gosales.PRODUCT INNER JOIN
                      gosales.PRODUCT_NAME_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_NUMBER = gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NUMBER INNER JOIN
                      gosales.PRODUCT_COLOR_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE = gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_CODE INNER JOIN
                      gosales.PRODUCT_BRAND ON gosales.PRODUCT.PRODUCT_BRAND_CODE = gosales.PRODUCT_BRAND.PRODUCT_BRAND_CODE INNER JOIN
                      gosales.PRODUCT_SIZE_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_SIZE_CODE = gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_CODE INNER JOIN
                      gosales.PRODUCT_TYPE ON gosales.PRODUCT.PRODUCT_TYPE_CODE = gosales.PRODUCT_TYPE.PRODUCT_TYPE_CODE INNER JOIN
                      gosales.PRODUCT_LINE ON gosales.PRODUCT_TYPE.PRODUCT_LINE_CODE = gosales.PRODUCT_LINE.PRODUCT_LINE_CODE
WHERE     (gosales.PRODUCT_NAME_LOOKUP.PRODUCT_LANGUAGE = N'DE')
~

CREATE VIEW gosales.VIEW_PRODUCT_DETAILS_EN
AS
SELECT     gosales.PRODUCT.PRODUCT_NUMBER AS PRODUCT_NUMBER, gosales.PRODUCT.BASE_PRODUCT_NUMBER AS BASE_PRODUCT_NUMBER, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NAME AS PRODUCT_NAME, gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_EN AS COLOR, 
                      gosales.PRODUCT_BRAND.PRODUCT_BRAND_EN AS BRAND, gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_EN AS PRODUCT_SIZE, 
                      gosales.PRODUCT_TYPE.PRODUCT_TYPE_EN AS PRODUCT_TYPE, gosales.PRODUCT_LINE.PRODUCT_LINE_EN AS PRODUCT_LINE, 
                      gosales.PRODUCT_LINE.PRODUCT_LINE_CODE AS PRODUCT_LINE_CODE, gosales.PRODUCT.PRODUCT_TYPE_CODE AS PRODUCT_TYPE_CODE, 
                      gosales.PRODUCT.PRODUCT_BRAND_CODE AS PRODUCT_BRAND_CODE, 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE AS PRODUCT_COLOR_CODE, gosales.PRODUCT.PRODUCT_SIZE_CODE AS PRODUCT_SIZE_CODE, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_DESCRIPTION AS PRODUCT_DESCRIPTION, 
                      gosales.PRODUCT.INTRODUCTION_DATE AS INTRODUCTION_DATE, gosales.PRODUCT.DISCONTINUED_DATE AS DISCONTINUED_DATE
FROM         gosales.PRODUCT INNER JOIN
                      gosales.PRODUCT_NAME_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_NUMBER = gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NUMBER INNER JOIN
                      gosales.PRODUCT_COLOR_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE = gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_CODE INNER JOIN
                      gosales.PRODUCT_BRAND ON gosales.PRODUCT.PRODUCT_BRAND_CODE = gosales.PRODUCT_BRAND.PRODUCT_BRAND_CODE INNER JOIN
                      gosales.PRODUCT_SIZE_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_SIZE_CODE = gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_CODE INNER JOIN
                      gosales.PRODUCT_TYPE ON gosales.PRODUCT.PRODUCT_TYPE_CODE = gosales.PRODUCT_TYPE.PRODUCT_TYPE_CODE INNER JOIN
                      gosales.PRODUCT_LINE ON gosales.PRODUCT_TYPE.PRODUCT_LINE_CODE = gosales.PRODUCT_LINE.PRODUCT_LINE_CODE
WHERE     (gosales.PRODUCT_NAME_LOOKUP.PRODUCT_LANGUAGE = N'EN')
~

CREATE VIEW gosales.VIEW_PRODUCT_DETAILS_ES
AS
SELECT     gosales.PRODUCT.PRODUCT_NUMBER AS PRODUCT_NUMBER, gosales.PRODUCT.BASE_PRODUCT_NUMBER AS BASE_PRODUCT_NUMBER, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NAME AS PRODUCT_NAME, gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_ES AS COLOR, 
                      gosales.PRODUCT_BRAND.PRODUCT_BRAND_ES AS BRAND, gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_ES AS PRODUCT_SIZE, 
                      gosales.PRODUCT_TYPE.PRODUCT_TYPE_ES AS PRODUCT_TYPE, gosales.PRODUCT_LINE.PRODUCT_LINE_ES AS PRODUCT_LINE, 
                      gosales.PRODUCT_LINE.PRODUCT_LINE_CODE AS PRODUCT_LINE_CODE, gosales.PRODUCT.PRODUCT_TYPE_CODE AS PRODUCT_TYPE_CODE, 
                      gosales.PRODUCT.PRODUCT_BRAND_CODE AS PRODUCT_BRAND_CODE, 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE AS PRODUCT_COLOR_CODE, gosales.PRODUCT.PRODUCT_SIZE_CODE AS PRODUCT_SIZE_CODE, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_DESCRIPTION AS PRODUCT_DESCRIPTION, 
                      gosales.PRODUCT.INTRODUCTION_DATE AS INTRODUCTION_DATE, gosales.PRODUCT.DISCONTINUED_DATE AS DISCONTINUED_DATE
FROM         gosales.PRODUCT INNER JOIN
                      gosales.PRODUCT_NAME_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_NUMBER = gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NUMBER INNER JOIN
                      gosales.PRODUCT_COLOR_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE = gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_CODE INNER JOIN
                      gosales.PRODUCT_BRAND ON gosales.PRODUCT.PRODUCT_BRAND_CODE = gosales.PRODUCT_BRAND.PRODUCT_BRAND_CODE INNER JOIN
                      gosales.PRODUCT_SIZE_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_SIZE_CODE = gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_CODE INNER JOIN
                      gosales.PRODUCT_TYPE ON gosales.PRODUCT.PRODUCT_TYPE_CODE = gosales.PRODUCT_TYPE.PRODUCT_TYPE_CODE INNER JOIN
                      gosales.PRODUCT_LINE ON gosales.PRODUCT_TYPE.PRODUCT_LINE_CODE = gosales.PRODUCT_LINE.PRODUCT_LINE_CODE
WHERE     (gosales.PRODUCT_NAME_LOOKUP.PRODUCT_LANGUAGE = N'ES')
~

CREATE VIEW gosales.VIEW_PRODUCT_DETAILS_FR
AS
SELECT     gosales.PRODUCT.PRODUCT_NUMBER AS PRODUCT_NUMBER, gosales.PRODUCT.BASE_PRODUCT_NUMBER AS BASE_PRODUCT_NUMBER, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NAME AS PRODUCT_NAME, gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_FR AS COLOR, 
                      gosales.PRODUCT_BRAND.PRODUCT_BRAND_FR AS BRAND, gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_FR AS PRODUCT_SIZE, 
                      gosales.PRODUCT_TYPE.PRODUCT_TYPE_FR AS PRODUCT_TYPE, gosales.PRODUCT_LINE.PRODUCT_LINE_FR AS PRODUCT_LINE, 
                      gosales.PRODUCT_LINE.PRODUCT_LINE_CODE AS PRODUCT_LINE_CODE, gosales.PRODUCT.PRODUCT_TYPE_CODE AS PRODUCT_TYPE_CODE, 
                      gosales.PRODUCT.PRODUCT_BRAND_CODE AS PRODUCT_BRAND_CODE, 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE AS PRODUCT_COLOR_CODE, gosales.PRODUCT.PRODUCT_SIZE_CODE AS PRODUCT_SIZE_CODE, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_DESCRIPTION AS PRODUCT_DESCRIPTION, 
                      gosales.PRODUCT.INTRODUCTION_DATE AS INTRODUCTION_DATE, gosales.PRODUCT.DISCONTINUED_DATE AS DISCONTINUED_DATE
FROM         gosales.PRODUCT INNER JOIN
                      gosales.PRODUCT_NAME_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_NUMBER = gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NUMBER INNER JOIN
                      gosales.PRODUCT_COLOR_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE = gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_CODE INNER JOIN
                      gosales.PRODUCT_BRAND ON gosales.PRODUCT.PRODUCT_BRAND_CODE = gosales.PRODUCT_BRAND.PRODUCT_BRAND_CODE INNER JOIN
                      gosales.PRODUCT_SIZE_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_SIZE_CODE = gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_CODE INNER JOIN
                      gosales.PRODUCT_TYPE ON gosales.PRODUCT.PRODUCT_TYPE_CODE = gosales.PRODUCT_TYPE.PRODUCT_TYPE_CODE INNER JOIN
                      gosales.PRODUCT_LINE ON gosales.PRODUCT_TYPE.PRODUCT_LINE_CODE = gosales.PRODUCT_LINE.PRODUCT_LINE_CODE
WHERE     (gosales.PRODUCT_NAME_LOOKUP.PRODUCT_LANGUAGE = N'FR')
~

CREATE VIEW gosales.VIEW_PRODUCT_DETAILS_IT
AS
SELECT     gosales.PRODUCT.PRODUCT_NUMBER AS PRODUCT_NUMBER, gosales.PRODUCT.BASE_PRODUCT_NUMBER AS BASE_PRODUCT_NUMBER, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NAME AS PRODUCT_NAME, gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_IT AS COLOR, 
                      gosales.PRODUCT_BRAND.PRODUCT_BRAND_IT AS BRAND, gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_IT AS PRODUCT_SIZE, 
                      gosales.PRODUCT_TYPE.PRODUCT_TYPE_IT AS PRODUCT_TYPE, gosales.PRODUCT_LINE.PRODUCT_LINE_IT AS PRODUCT_LINE, 
                      gosales.PRODUCT_LINE.PRODUCT_LINE_CODE AS PRODUCT_LINE_CODE, gosales.PRODUCT.PRODUCT_TYPE_CODE AS PRODUCT_TYPE_CODE, 
                      gosales.PRODUCT.PRODUCT_BRAND_CODE AS PRODUCT_BRAND_CODE, 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE AS PRODUCT_COLOR_CODE, gosales.PRODUCT.PRODUCT_SIZE_CODE AS PRODUCT_SIZE_CODE, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_DESCRIPTION AS PRODUCT_DESCRIPTION, 
                      gosales.PRODUCT.INTRODUCTION_DATE AS INTRODUCTION_DATE, gosales.PRODUCT.DISCONTINUED_DATE AS DISCONTINUED_DATE
FROM         gosales.PRODUCT INNER JOIN
                      gosales.PRODUCT_NAME_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_NUMBER = gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NUMBER INNER JOIN
                      gosales.PRODUCT_COLOR_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE = gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_CODE INNER JOIN
                      gosales.PRODUCT_BRAND ON gosales.PRODUCT.PRODUCT_BRAND_CODE = gosales.PRODUCT_BRAND.PRODUCT_BRAND_CODE INNER JOIN
                      gosales.PRODUCT_SIZE_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_SIZE_CODE = gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_CODE INNER JOIN
                      gosales.PRODUCT_TYPE ON gosales.PRODUCT.PRODUCT_TYPE_CODE = gosales.PRODUCT_TYPE.PRODUCT_TYPE_CODE INNER JOIN
                      gosales.PRODUCT_LINE ON gosales.PRODUCT_TYPE.PRODUCT_LINE_CODE = gosales.PRODUCT_LINE.PRODUCT_LINE_CODE
WHERE     (gosales.PRODUCT_NAME_LOOKUP.PRODUCT_LANGUAGE = N'IT')
~

CREATE VIEW gosales.VIEW_PRODUCT_DETAILS_JA
AS
SELECT     gosales.PRODUCT.PRODUCT_NUMBER AS PRODUCT_NUMBER, gosales.PRODUCT.BASE_PRODUCT_NUMBER AS BASE_PRODUCT_NUMBER, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NAME AS PRODUCT_NAME, gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_JA AS COLOR, 
                      gosales.PRODUCT_BRAND.PRODUCT_BRAND_JA AS BRAND, gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_JA AS PRODUCT_SIZE, 
                      gosales.PRODUCT_TYPE.PRODUCT_TYPE_JA AS PRODUCT_TYPE, gosales.PRODUCT_LINE.PRODUCT_LINE_JA AS PRODUCT_LINE, 
                      gosales.PRODUCT_LINE.PRODUCT_LINE_CODE AS PRODUCT_LINE_CODE, gosales.PRODUCT.PRODUCT_TYPE_CODE AS PRODUCT_TYPE_CODE, 
                      gosales.PRODUCT.PRODUCT_BRAND_CODE AS PRODUCT_BRAND_CODE, 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE AS PRODUCT_COLOR_CODE, gosales.PRODUCT.PRODUCT_SIZE_CODE AS PRODUCT_SIZE_CODE, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_DESCRIPTION AS PRODUCT_DESCRIPTION, 
                      gosales.PRODUCT.INTRODUCTION_DATE AS INTRODUCTION_DATE, gosales.PRODUCT.DISCONTINUED_DATE AS DISCONTINUED_DATE
FROM         gosales.PRODUCT INNER JOIN
                      gosales.PRODUCT_NAME_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_NUMBER = gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NUMBER INNER JOIN
                      gosales.PRODUCT_COLOR_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE = gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_CODE INNER JOIN
                      gosales.PRODUCT_BRAND ON gosales.PRODUCT.PRODUCT_BRAND_CODE = gosales.PRODUCT_BRAND.PRODUCT_BRAND_CODE INNER JOIN
                      gosales.PRODUCT_SIZE_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_SIZE_CODE = gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_CODE INNER JOIN
                      gosales.PRODUCT_TYPE ON gosales.PRODUCT.PRODUCT_TYPE_CODE = gosales.PRODUCT_TYPE.PRODUCT_TYPE_CODE INNER JOIN
                      gosales.PRODUCT_LINE ON gosales.PRODUCT_TYPE.PRODUCT_LINE_CODE = gosales.PRODUCT_LINE.PRODUCT_LINE_CODE
WHERE     (gosales.PRODUCT_NAME_LOOKUP.PRODUCT_LANGUAGE = N'JA')
~

CREATE VIEW gosales.VIEW_PRODUCT_DETAILS_KO
AS
SELECT     gosales.PRODUCT.PRODUCT_NUMBER AS PRODUCT_NUMBER, gosales.PRODUCT.BASE_PRODUCT_NUMBER AS BASE_PRODUCT_NUMBER, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NAME AS PRODUCT_NAME, gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_KO AS COLOR, 
                      gosales.PRODUCT_BRAND.PRODUCT_BRAND_KO AS BRAND, gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_KO AS PRODUCT_SIZE, 
                      gosales.PRODUCT_TYPE.PRODUCT_TYPE_KO AS PRODUCT_TYPE, gosales.PRODUCT_LINE.PRODUCT_LINE_KO AS PRODUCT_LINE, 
                      gosales.PRODUCT_LINE.PRODUCT_LINE_CODE AS PRODUCT_LINE_CODE, gosales.PRODUCT.PRODUCT_TYPE_CODE AS PRODUCT_TYPE_CODE, 
                      gosales.PRODUCT.PRODUCT_BRAND_CODE AS PRODUCT_BRAND_CODE, 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE AS PRODUCT_COLOR_CODE, gosales.PRODUCT.PRODUCT_SIZE_CODE AS PRODUCT_SIZE_CODE, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_DESCRIPTION AS PRODUCT_DESCRIPTION, 
                      gosales.PRODUCT.INTRODUCTION_DATE AS INTRODUCTION_DATE, gosales.PRODUCT.DISCONTINUED_DATE AS DISCONTINUED_DATE
FROM         gosales.PRODUCT INNER JOIN
                      gosales.PRODUCT_NAME_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_NUMBER = gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NUMBER INNER JOIN
                      gosales.PRODUCT_COLOR_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE = gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_CODE INNER JOIN
                      gosales.PRODUCT_BRAND ON gosales.PRODUCT.PRODUCT_BRAND_CODE = gosales.PRODUCT_BRAND.PRODUCT_BRAND_CODE INNER JOIN
                      gosales.PRODUCT_SIZE_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_SIZE_CODE = gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_CODE INNER JOIN
                      gosales.PRODUCT_TYPE ON gosales.PRODUCT.PRODUCT_TYPE_CODE = gosales.PRODUCT_TYPE.PRODUCT_TYPE_CODE INNER JOIN
                      gosales.PRODUCT_LINE ON gosales.PRODUCT_TYPE.PRODUCT_LINE_CODE = gosales.PRODUCT_LINE.PRODUCT_LINE_CODE
WHERE     (gosales.PRODUCT_NAME_LOOKUP.PRODUCT_LANGUAGE = N'KO')
~

CREATE VIEW gosales.VIEW_PRODUCT_DETAILS_PT
AS
SELECT     gosales.PRODUCT.PRODUCT_NUMBER AS PRODUCT_NUMBER, gosales.PRODUCT.BASE_PRODUCT_NUMBER AS BASE_PRODUCT_NUMBER, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NAME AS PRODUCT_NAME, gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_PT AS COLOR, 
                      gosales.PRODUCT_BRAND.PRODUCT_BRAND_PT AS BRAND, gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_PT AS PRODUCT_SIZE, 
                      gosales.PRODUCT_TYPE.PRODUCT_TYPE_PT AS PRODUCT_TYPE, gosales.PRODUCT_LINE.PRODUCT_LINE_PT AS PRODUCT_LINE, 
                      gosales.PRODUCT_LINE.PRODUCT_LINE_CODE AS PRODUCT_LINE_CODE, gosales.PRODUCT.PRODUCT_TYPE_CODE AS PRODUCT_TYPE_CODE, 
                      gosales.PRODUCT.PRODUCT_BRAND_CODE AS PRODUCT_BRAND_CODE, 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE AS PRODUCT_COLOR_CODE, gosales.PRODUCT.PRODUCT_SIZE_CODE AS PRODUCT_SIZE_CODE, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_DESCRIPTION AS PRODUCT_DESCRIPTION, 
                      gosales.PRODUCT.INTRODUCTION_DATE AS INTRODUCTION_DATE, gosales.PRODUCT.DISCONTINUED_DATE AS DISCONTINUED_DATE
FROM         gosales.PRODUCT INNER JOIN
                      gosales.PRODUCT_NAME_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_NUMBER = gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NUMBER INNER JOIN
                      gosales.PRODUCT_COLOR_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE = gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_CODE INNER JOIN
                      gosales.PRODUCT_BRAND ON gosales.PRODUCT.PRODUCT_BRAND_CODE = gosales.PRODUCT_BRAND.PRODUCT_BRAND_CODE INNER JOIN
                      gosales.PRODUCT_SIZE_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_SIZE_CODE = gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_CODE INNER JOIN
                      gosales.PRODUCT_TYPE ON gosales.PRODUCT.PRODUCT_TYPE_CODE = gosales.PRODUCT_TYPE.PRODUCT_TYPE_CODE INNER JOIN
                      gosales.PRODUCT_LINE ON gosales.PRODUCT_TYPE.PRODUCT_LINE_CODE = gosales.PRODUCT_LINE.PRODUCT_LINE_CODE
WHERE     (gosales.PRODUCT_NAME_LOOKUP.PRODUCT_LANGUAGE = N'PT')
~

CREATE VIEW gosales.VIEW_PRODUCT_DETAILS_RU
AS
SELECT     gosales.PRODUCT.PRODUCT_NUMBER AS PRODUCT_NUMBER, gosales.PRODUCT.BASE_PRODUCT_NUMBER AS BASE_PRODUCT_NUMBER, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NAME AS PRODUCT_NAME, gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_RU AS COLOR, 
                      gosales.PRODUCT_BRAND.PRODUCT_BRAND_RU AS BRAND, gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_RU AS PRODUCT_SIZE, 
                      gosales.PRODUCT_TYPE.PRODUCT_TYPE_RU AS PRODUCT_TYPE, gosales.PRODUCT_LINE.PRODUCT_LINE_RU AS PRODUCT_LINE, 
                      gosales.PRODUCT_LINE.PRODUCT_LINE_CODE AS PRODUCT_LINE_CODE, gosales.PRODUCT.PRODUCT_TYPE_CODE AS PRODUCT_TYPE_CODE, 
                      gosales.PRODUCT.PRODUCT_BRAND_CODE AS PRODUCT_BRAND_CODE, 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE AS PRODUCT_COLOR_CODE, gosales.PRODUCT.PRODUCT_SIZE_CODE AS PRODUCT_SIZE_CODE, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_DESCRIPTION AS PRODUCT_DESCRIPTION, 
                      gosales.PRODUCT.INTRODUCTION_DATE AS INTRODUCTION_DATE, gosales.PRODUCT.DISCONTINUED_DATE AS DISCONTINUED_DATE
FROM         gosales.PRODUCT INNER JOIN
                      gosales.PRODUCT_NAME_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_NUMBER = gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NUMBER INNER JOIN
                      gosales.PRODUCT_COLOR_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE = gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_CODE INNER JOIN
                      gosales.PRODUCT_BRAND ON gosales.PRODUCT.PRODUCT_BRAND_CODE = gosales.PRODUCT_BRAND.PRODUCT_BRAND_CODE INNER JOIN
                      gosales.PRODUCT_SIZE_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_SIZE_CODE = gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_CODE INNER JOIN
                      gosales.PRODUCT_TYPE ON gosales.PRODUCT.PRODUCT_TYPE_CODE = gosales.PRODUCT_TYPE.PRODUCT_TYPE_CODE INNER JOIN
                      gosales.PRODUCT_LINE ON gosales.PRODUCT_TYPE.PRODUCT_LINE_CODE = gosales.PRODUCT_LINE.PRODUCT_LINE_CODE
WHERE     (gosales.PRODUCT_NAME_LOOKUP.PRODUCT_LANGUAGE = N'RU')
~

CREATE VIEW gosales.VIEW_PRODUCT_DETAILS_SC
AS
SELECT     gosales.PRODUCT.PRODUCT_NUMBER AS PRODUCT_NUMBER, gosales.PRODUCT.BASE_PRODUCT_NUMBER AS BASE_PRODUCT_NUMBER, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NAME AS PRODUCT_NAME, gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_SC AS COLOR, 
                      gosales.PRODUCT_BRAND.PRODUCT_BRAND_SC AS BRAND, gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_SC AS PRODUCT_SIZE, 
                      gosales.PRODUCT_TYPE.PRODUCT_TYPE_SC AS PRODUCT_TYPE, gosales.PRODUCT_LINE.PRODUCT_LINE_SC AS PRODUCT_LINE, 
                      gosales.PRODUCT_LINE.PRODUCT_LINE_CODE AS PRODUCT_LINE_CODE, gosales.PRODUCT.PRODUCT_TYPE_CODE AS PRODUCT_TYPE_CODE, 
                      gosales.PRODUCT.PRODUCT_BRAND_CODE AS PRODUCT_BRAND_CODE, 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE AS PRODUCT_COLOR_CODE, gosales.PRODUCT.PRODUCT_SIZE_CODE AS PRODUCT_SIZE_CODE, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_DESCRIPTION AS PRODUCT_DESCRIPTION, 
                      gosales.PRODUCT.INTRODUCTION_DATE AS INTRODUCTION_DATE, gosales.PRODUCT.DISCONTINUED_DATE AS DISCONTINUED_DATE
FROM         gosales.PRODUCT INNER JOIN
                      gosales.PRODUCT_NAME_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_NUMBER = gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NUMBER INNER JOIN
                      gosales.PRODUCT_COLOR_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE = gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_CODE INNER JOIN
                      gosales.PRODUCT_BRAND ON gosales.PRODUCT.PRODUCT_BRAND_CODE = gosales.PRODUCT_BRAND.PRODUCT_BRAND_CODE INNER JOIN
                      gosales.PRODUCT_SIZE_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_SIZE_CODE = gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_CODE INNER JOIN
                      gosales.PRODUCT_TYPE ON gosales.PRODUCT.PRODUCT_TYPE_CODE = gosales.PRODUCT_TYPE.PRODUCT_TYPE_CODE INNER JOIN
                      gosales.PRODUCT_LINE ON gosales.PRODUCT_TYPE.PRODUCT_LINE_CODE = gosales.PRODUCT_LINE.PRODUCT_LINE_CODE
WHERE     (gosales.PRODUCT_NAME_LOOKUP.PRODUCT_LANGUAGE = N'SC')
~

CREATE VIEW gosales.VIEW_PRODUCT_DETAILS_TC
AS
SELECT     gosales.PRODUCT.PRODUCT_NUMBER AS PRODUCT_NUMBER, gosales.PRODUCT.BASE_PRODUCT_NUMBER AS BASE_PRODUCT_NUMBER, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NAME AS PRODUCT_NAME, gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_TC AS COLOR, 
                      gosales.PRODUCT_BRAND.PRODUCT_BRAND_TC AS BRAND, gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_TC AS PRODUCT_SIZE, 
                      gosales.PRODUCT_TYPE.PRODUCT_TYPE_TC AS PRODUCT_TYPE, gosales.PRODUCT_LINE.PRODUCT_LINE_TC AS PRODUCT_LINE, 
                      gosales.PRODUCT_LINE.PRODUCT_LINE_CODE AS PRODUCT_LINE_CODE, gosales.PRODUCT.PRODUCT_TYPE_CODE AS PRODUCT_TYPE_CODE, 
                      gosales.PRODUCT.PRODUCT_BRAND_CODE AS PRODUCT_BRAND_CODE, 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE AS PRODUCT_COLOR_CODE, gosales.PRODUCT.PRODUCT_SIZE_CODE AS PRODUCT_SIZE_CODE, 
                      gosales.PRODUCT_NAME_LOOKUP.PRODUCT_DESCRIPTION AS PRODUCT_DESCRIPTION, 
                      gosales.PRODUCT.INTRODUCTION_DATE AS INTRODUCTION_DATE, gosales.PRODUCT.DISCONTINUED_DATE AS DISCONTINUED_DATE
FROM         gosales.PRODUCT INNER JOIN
                      gosales.PRODUCT_NAME_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_NUMBER = gosales.PRODUCT_NAME_LOOKUP.PRODUCT_NUMBER INNER JOIN
                      gosales.PRODUCT_COLOR_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_COLOR_CODE = gosales.PRODUCT_COLOR_LOOKUP.PRODUCT_COLOR_CODE INNER JOIN
                      gosales.PRODUCT_BRAND ON gosales.PRODUCT.PRODUCT_BRAND_CODE = gosales.PRODUCT_BRAND.PRODUCT_BRAND_CODE INNER JOIN
                      gosales.PRODUCT_SIZE_LOOKUP ON 
                      gosales.PRODUCT.PRODUCT_SIZE_CODE = gosales.PRODUCT_SIZE_LOOKUP.PRODUCT_SIZE_CODE INNER JOIN
                      gosales.PRODUCT_TYPE ON gosales.PRODUCT.PRODUCT_TYPE_CODE = gosales.PRODUCT_TYPE.PRODUCT_TYPE_CODE INNER JOIN
                      gosales.PRODUCT_LINE ON gosales.PRODUCT_TYPE.PRODUCT_LINE_CODE = gosales.PRODUCT_LINE.PRODUCT_LINE_CODE
WHERE     (gosales.PRODUCT_NAME_LOOKUP.PRODUCT_LANGUAGE = N'TC')
~

CREATE VIEW GOSALESCT.VW_CUST_ORDER_STATUS_DE
AS
SELECT  GOSALESCT.CUST_CUSTOMER.CUST_CODE, GOSALESCT.CUST_CUSTOMER.CUST_LAST_NAME, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_NUMBER, GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_DATE, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_TOTAL, GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS
FROM   GOSALESCT.CUST_CUSTOMER INNER JOIN
       GOSALESCT.CUST_ORDER_HEADER ON GOSALESCT.CUST_CUSTOMER.CUST_CODE = GOSALESCT.CUST_ORDER_HEADER.CUST_CODE INNER JOIN
       GOSALESCT.CUST_ORDER_STATUS ON 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_STATUS_CODE = GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_CODE
WHERE  (GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_LANGUAGE = 'DE')
~

CREATE VIEW GOSALESCT.VW_CUST_ORDER_STATUS_EN
AS
SELECT  GOSALESCT.CUST_CUSTOMER.CUST_CODE, GOSALESCT.CUST_CUSTOMER.CUST_LAST_NAME, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_NUMBER, GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_DATE, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_TOTAL, GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS
FROM   GOSALESCT.CUST_CUSTOMER INNER JOIN
       GOSALESCT.CUST_ORDER_HEADER ON GOSALESCT.CUST_CUSTOMER.CUST_CODE = GOSALESCT.CUST_ORDER_HEADER.CUST_CODE INNER JOIN
       GOSALESCT.CUST_ORDER_STATUS ON 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_STATUS_CODE = GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_CODE
WHERE  (GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_LANGUAGE = 'EN')
~


CREATE VIEW GOSALESCT.VW_CUST_ORDER_STATUS_ES
AS
SELECT  GOSALESCT.CUST_CUSTOMER.CUST_CODE, GOSALESCT.CUST_CUSTOMER.CUST_LAST_NAME, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_NUMBER, GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_DATE, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_TOTAL, GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS
FROM   GOSALESCT.CUST_CUSTOMER INNER JOIN
       GOSALESCT.CUST_ORDER_HEADER ON GOSALESCT.CUST_CUSTOMER.CUST_CODE = GOSALESCT.CUST_ORDER_HEADER.CUST_CODE INNER JOIN
       GOSALESCT.CUST_ORDER_STATUS ON 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_STATUS_CODE = GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_CODE
WHERE  (GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_LANGUAGE = 'ES')
~

CREATE VIEW GOSALESCT.VW_CUST_ORDER_STATUS_FR
AS
SELECT  GOSALESCT.CUST_CUSTOMER.CUST_CODE, GOSALESCT.CUST_CUSTOMER.CUST_LAST_NAME, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_NUMBER, GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_DATE, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_TOTAL, GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS
FROM   GOSALESCT.CUST_CUSTOMER INNER JOIN
       GOSALESCT.CUST_ORDER_HEADER ON GOSALESCT.CUST_CUSTOMER.CUST_CODE = GOSALESCT.CUST_ORDER_HEADER.CUST_CODE INNER JOIN
       GOSALESCT.CUST_ORDER_STATUS ON 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_STATUS_CODE = GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_CODE
WHERE  (GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_LANGUAGE = 'FR')
~

CREATE VIEW GOSALESCT.VW_CUST_ORDER_STATUS_IT
AS
SELECT  GOSALESCT.CUST_CUSTOMER.CUST_CODE, GOSALESCT.CUST_CUSTOMER.CUST_LAST_NAME, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_NUMBER, GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_DATE, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_TOTAL, GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS
FROM   GOSALESCT.CUST_CUSTOMER INNER JOIN
       GOSALESCT.CUST_ORDER_HEADER ON GOSALESCT.CUST_CUSTOMER.CUST_CODE = GOSALESCT.CUST_ORDER_HEADER.CUST_CODE INNER JOIN
       GOSALESCT.CUST_ORDER_STATUS ON 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_STATUS_CODE = GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_CODE
WHERE  (GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_LANGUAGE = 'IT')
~

CREATE VIEW GOSALESCT.VW_CUST_ORDER_STATUS_JA
AS
SELECT  GOSALESCT.CUST_CUSTOMER.CUST_CODE, GOSALESCT.CUST_CUSTOMER.CUST_LAST_NAME, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_NUMBER, GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_DATE, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_TOTAL, GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS
FROM   GOSALESCT.CUST_CUSTOMER INNER JOIN
       GOSALESCT.CUST_ORDER_HEADER ON GOSALESCT.CUST_CUSTOMER.CUST_CODE = GOSALESCT.CUST_ORDER_HEADER.CUST_CODE INNER JOIN
       GOSALESCT.CUST_ORDER_STATUS ON 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_STATUS_CODE = GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_CODE
WHERE  (GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_LANGUAGE = 'JA')
~

CREATE VIEW GOSALESCT.VW_CUST_ORDER_STATUS_KO
AS
SELECT  GOSALESCT.CUST_CUSTOMER.CUST_CODE, GOSALESCT.CUST_CUSTOMER.CUST_LAST_NAME, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_NUMBER, GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_DATE, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_TOTAL, GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS
FROM   GOSALESCT.CUST_CUSTOMER INNER JOIN
       GOSALESCT.CUST_ORDER_HEADER ON GOSALESCT.CUST_CUSTOMER.CUST_CODE = GOSALESCT.CUST_ORDER_HEADER.CUST_CODE INNER JOIN
       GOSALESCT.CUST_ORDER_STATUS ON 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_STATUS_CODE = GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_CODE
WHERE  (GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_LANGUAGE = 'KO')
~

CREATE VIEW GOSALESCT.VW_CUST_ORDER_STATUS_PT
AS
SELECT  GOSALESCT.CUST_CUSTOMER.CUST_CODE, GOSALESCT.CUST_CUSTOMER.CUST_LAST_NAME, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_NUMBER, GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_DATE, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_TOTAL, GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS
FROM   GOSALESCT.CUST_CUSTOMER INNER JOIN
       GOSALESCT.CUST_ORDER_HEADER ON GOSALESCT.CUST_CUSTOMER.CUST_CODE = GOSALESCT.CUST_ORDER_HEADER.CUST_CODE INNER JOIN
       GOSALESCT.CUST_ORDER_STATUS ON 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_STATUS_CODE = GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_CODE
WHERE  (GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_LANGUAGE = 'PT')
~

CREATE VIEW GOSALESCT.VW_CUST_ORDER_STATUS_RU
AS
SELECT  GOSALESCT.CUST_CUSTOMER.CUST_CODE, GOSALESCT.CUST_CUSTOMER.CUST_LAST_NAME, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_NUMBER, GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_DATE, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_TOTAL, GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS
FROM   GOSALESCT.CUST_CUSTOMER INNER JOIN
       GOSALESCT.CUST_ORDER_HEADER ON GOSALESCT.CUST_CUSTOMER.CUST_CODE = GOSALESCT.CUST_ORDER_HEADER.CUST_CODE INNER JOIN
       GOSALESCT.CUST_ORDER_STATUS ON 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_STATUS_CODE = GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_CODE
WHERE  (GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_LANGUAGE = 'RU')
~

CREATE VIEW GOSALESCT.VW_CUST_ORDER_STATUS_SC
AS
SELECT  GOSALESCT.CUST_CUSTOMER.CUST_CODE, GOSALESCT.CUST_CUSTOMER.CUST_LAST_NAME, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_NUMBER, GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_DATE, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_TOTAL, GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS
FROM   GOSALESCT.CUST_CUSTOMER INNER JOIN
       GOSALESCT.CUST_ORDER_HEADER ON GOSALESCT.CUST_CUSTOMER.CUST_CODE = GOSALESCT.CUST_ORDER_HEADER.CUST_CODE INNER JOIN
       GOSALESCT.CUST_ORDER_STATUS ON 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_STATUS_CODE = GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_CODE
WHERE  (GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_LANGUAGE = 'SC')
~

CREATE VIEW GOSALESCT.VW_CUST_ORDER_STATUS_TC
AS
SELECT  GOSALESCT.CUST_CUSTOMER.CUST_CODE, GOSALESCT.CUST_CUSTOMER.CUST_LAST_NAME, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_NUMBER, GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_DATE, 
       GOSALESCT.CUST_ORDER_HEADER.CUST_TOTAL, GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS
FROM   GOSALESCT.CUST_CUSTOMER INNER JOIN
       GOSALESCT.CUST_ORDER_HEADER ON GOSALESCT.CUST_CUSTOMER.CUST_CODE = GOSALESCT.CUST_ORDER_HEADER.CUST_CODE INNER JOIN
       GOSALESCT.CUST_ORDER_STATUS ON 
       GOSALESCT.CUST_ORDER_HEADER.CUST_ORDER_STATUS_CODE = GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_CODE
WHERE  (GOSALESCT.CUST_ORDER_STATUS.CUST_ORDER_STATUS_LANGUAGE = 'TC')
~

--GRANT PRIVILEGES TO USER GOSALES
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VIEW_CUSTOMER_INFO_DE TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VIEW_CUSTOMER_INFO_EN TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VIEW_CUSTOMER_INFO_ES TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VIEW_CUSTOMER_INFO_FR TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VIEW_CUSTOMER_INFO_IT TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VIEW_CUSTOMER_INFO_JA TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VIEW_CUSTOMER_INFO_KO TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VIEW_CUSTOMER_INFO_PT TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VIEW_CUSTOMER_INFO_RU TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VIEW_CUSTOMER_INFO_SC TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VIEW_CUSTOMER_INFO_TC TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALES.VIEW_PRODUCT_DETAILS_DE TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALES.VIEW_PRODUCT_DETAILS_EN TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALES.VIEW_PRODUCT_DETAILS_ES TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALES.VIEW_PRODUCT_DETAILS_FR TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALES.VIEW_PRODUCT_DETAILS_IT TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALES.VIEW_PRODUCT_DETAILS_JA TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALES.VIEW_PRODUCT_DETAILS_KO TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALES.VIEW_PRODUCT_DETAILS_PT TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALES.VIEW_PRODUCT_DETAILS_RU TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALES.VIEW_PRODUCT_DETAILS_SC TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALES.VIEW_PRODUCT_DETAILS_TC TO USER GOSALES
~	
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VW_CUST_ORDER_STATUS_DE TO USER GOSALES
~
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VW_CUST_ORDER_STATUS_EN TO USER GOSALES
~
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VW_CUST_ORDER_STATUS_ES TO USER GOSALES
~
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VW_CUST_ORDER_STATUS_FR TO USER GOSALES
~
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VW_CUST_ORDER_STATUS_IT TO USER GOSALES
~
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VW_CUST_ORDER_STATUS_JA TO USER GOSALES
~
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VW_CUST_ORDER_STATUS_KO TO USER GOSALES
~
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VW_CUST_ORDER_STATUS_PT TO USER GOSALES
~
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VW_CUST_ORDER_STATUS_RU TO USER GOSALES
~
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VW_CUST_ORDER_STATUS_SC TO USER GOSALES
~
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESCT.VW_CUST_ORDER_STATUS_TC TO USER GOSALES
~	

	
SET CURRENT SCHEMA = GOSALESDW
~

--GRANT AUTHORITIES TO USER GOSALESDW
GRANT  BINDADD,CONNECT,LOAD ON DATABASE  TO USER GOSALESDW
~

--GRANT PRIVILEGES TO USER GOSALESDW
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.DIST_INVENTORY_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.DIST_PRODUCT_FORECAST_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.DIST_RETURN_REASON_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.DIST_RETURNED_ITEMS_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_EMPLOYEE_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_EXPENSE_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_EXPENSE_PLAN_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_EXPENSE_TYPE_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_EXPENSE_UNIT_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_POSITION_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_POSITION_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_POSITION_SUMMARY_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_RANKING_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_RANKING_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_RECRUITMENT_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_RECRUITMENT_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_SUCCESSION_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_SUCCESSION_STATUS_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_SUMMARY_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_SURVEY_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_SURVEY_TARG_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_SURVEY_TOPIC_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_TERMINATION_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_TRAINING_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.EMP_TRAINING_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.FIN_ACCOUNT_CLASS_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.FIN_ACCOUNT_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.FIN_ACCOUNT_NAME_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.FIN_ACCOUNT_TYPE_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.FIN_FINANCE_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.FIN_SUBM_CURRENCY_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.FIN_SUBM_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.FIN_SUBM_TYPE_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.GO_BRANCH_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.GO_GENDER_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.GO_ORG_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.GO_ORG_NAME_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.GO_REGION_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.GO_SATISFACTION_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.GO_TIME_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.GO_TIME_QUARTER_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.MRK_ACTIVITY_STATUS_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.MRK_BUNDLE_GROUP_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.MRK_CAMPAIGN_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.MRK_PROD_SURVEY_TARG_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.MRK_PRODUCT_SURVEY_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.MRK_PRODUCT_SURVEY_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.MRK_PROMOTION_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.MRK_PROMOTION_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.MRK_PROMOTION_PLAN_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.MRK_RTL_SURVEY_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.MRK_RTL_SURVEY_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.MRK_RTL_SURVEY_TARG_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.SLS_ORDER_METHOD_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.SLS_PRODUCT_BRAND_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.SLS_PRODUCT_COLOR_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.SLS_PRODUCT_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.SLS_PRODUCT_LINE_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.SLS_PRODUCT_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.SLS_PRODUCT_SIZE_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.SLS_PRODUCT_TYPE_LOOKUP TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.SLS_RTL_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.SLS_SALES_FACT TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.SLS_SALES_ORDER_DIM TO USER GOSALESDW
~
GRANT SELECT,INSERT,UPDATE,DELETE,ALTER,INDEX,REFERENCES ON TABLE GOSALESDW.SLS_SALES_TARG_FACT TO USER GOSALESDW
~


--CREATE VIEWS IN GOSALESDW
CREATE VIEW gosalesdw.VIEW_ACCOUNT_DIM
AS
SELECT     gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_KEY, gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_LEVEL, gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_PARENT, 
                      gosalesdw.FIN_ACCOUNT_DIM.DEBIT_OR_CREDIT, gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_TYPE_CODE, 
                      gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CLASS_CODE, gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE1, 
                      gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE2, gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE3, 
                      gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE4, gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE5, 
                      gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE6, gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE7, 
                      gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE8, gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE9, 
                      gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE10, gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE11, 
                      gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE12, gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE13, 
                      gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE14, gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE15, 
                      gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE16, gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE, 
                      gosalesdw.FIN_ACCOUNT_DIM.AGGREGATION_SIGN, gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_EN, 
                      gosalesdw.FIN_ACCOUNT_TYPE_LOOKUP.ACCOUNT_TYPE_EN, gosalesdw.FIN_ACCOUNT_CLASS_LOOKUP.ACCOUNT_CLASS_EN, 
                      gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_DE, gosalesdw.FIN_ACCOUNT_TYPE_LOOKUP.ACCOUNT_TYPE_DE, 
                      gosalesdw.FIN_ACCOUNT_CLASS_LOOKUP.ACCOUNT_CLASS_DE, gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_ES, 
                      gosalesdw.FIN_ACCOUNT_TYPE_LOOKUP.ACCOUNT_TYPE_ES, gosalesdw.FIN_ACCOUNT_CLASS_LOOKUP.ACCOUNT_CLASS_ES, 
                      gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_FR, gosalesdw.FIN_ACCOUNT_TYPE_LOOKUP.ACCOUNT_TYPE_FR, 
                      gosalesdw.FIN_ACCOUNT_CLASS_LOOKUP.ACCOUNT_CLASS_FR, gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_IT, 
                      gosalesdw.FIN_ACCOUNT_TYPE_LOOKUP.ACCOUNT_TYPE_IT, gosalesdw.FIN_ACCOUNT_CLASS_LOOKUP.ACCOUNT_CLASS_IT, 
                      gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_JA, gosalesdw.FIN_ACCOUNT_TYPE_LOOKUP.ACCOUNT_TYPE_JA, 
                      gosalesdw.FIN_ACCOUNT_CLASS_LOOKUP.ACCOUNT_CLASS_JA, gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_KO, 
                      gosalesdw.FIN_ACCOUNT_TYPE_LOOKUP.ACCOUNT_TYPE_KO, gosalesdw.FIN_ACCOUNT_CLASS_LOOKUP.ACCOUNT_CLASS_KO, 
                      gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_PT, gosalesdw.FIN_ACCOUNT_TYPE_LOOKUP.ACCOUNT_TYPE_PT, 
                      gosalesdw.FIN_ACCOUNT_CLASS_LOOKUP.ACCOUNT_CLASS_PT, gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_RU, 
                      gosalesdw.FIN_ACCOUNT_TYPE_LOOKUP.ACCOUNT_TYPE_RU, gosalesdw.FIN_ACCOUNT_CLASS_LOOKUP.ACCOUNT_CLASS_RU, 
                      gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_SC, gosalesdw.FIN_ACCOUNT_TYPE_LOOKUP.ACCOUNT_TYPE_SC, 
                      gosalesdw.FIN_ACCOUNT_CLASS_LOOKUP.ACCOUNT_CLASS_SC, gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_TC, 
                      gosalesdw.FIN_ACCOUNT_TYPE_LOOKUP.ACCOUNT_TYPE_TC, gosalesdw.FIN_ACCOUNT_CLASS_LOOKUP.ACCOUNT_CLASS_TC
FROM         gosalesdw.FIN_ACCOUNT_DIM INNER JOIN
                      gosalesdw.FIN_ACCOUNT_CLASS_LOOKUP ON 
                      gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CLASS_CODE = gosalesdw.FIN_ACCOUNT_CLASS_LOOKUP.ACCOUNT_CLASS_CODE INNER JOIN
                      gosalesdw.FIN_ACCOUNT_NAME_LOOKUP ON 
                      gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE = gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_CODE INNER JOIN
                      gosalesdw.FIN_ACCOUNT_TYPE_LOOKUP ON 
                      gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_TYPE_CODE = gosalesdw.FIN_ACCOUNT_TYPE_LOOKUP.ACCOUNT_TYPE_CODE
~

CREATE VIEW gosalesdw.VIEW_BALANCED_ORG_DIM
AS
SELECT     gosalesdw.GO_ORG_DIM.ORGANIZATION_KEY, GO_ORG_DIM_1.ORGANIZATION_PARENT AS ORGANIZATION_CODE1, 
                      gosalesdw.GO_ORG_DIM.ORGANIZATION_PARENT AS ORGANIZATION_CODE2, gosalesdw.GO_ORG_DIM.ORGANIZATION_CODE
FROM         gosalesdw.GO_ORG_DIM INNER JOIN
                      gosalesdw.GO_ORG_DIM GO_ORG_DIM_1 ON gosalesdw.GO_ORG_DIM.ORGANIZATION_PARENT = GO_ORG_DIM_1.ORGANIZATION_CODE
WHERE     (gosalesdw.GO_ORG_DIM.ORGANIZATION_CODE BETWEEN N'006' AND N'8820')
~

CREATE VIEW gosalesdw.VIEW_ORG_DIM
AS
SELECT     gosalesdw.GO_ORG_DIM.ORGANIZATION_KEY, gosalesdw.GO_ORG_DIM.ORGANIZATION_CODE1, gosalesdw.GO_ORG_DIM.ORGANIZATION_CODE2, 
                      gosalesdw.GO_ORG_DIM.ORGANIZATION_CODE3, gosalesdw.GO_ORG_DIM.ORGANIZATION_CODE4, 
                      gosalesdw.GO_ORG_DIM.ORGANIZATION_CODE, SUBSTR(gosalesdw.GO_ORG_DIM.ORGANIZATION_PARENT, 1, 5) AS ORGANIZATION_PARENT, 
                      gosalesdw.GO_ORG_NAME_LOOKUP.ORGANIZATION_NAME_EN, gosalesdw.GO_ORG_NAME_LOOKUP.ORGANIZATION_NAME_DE, 
                      gosalesdw.GO_ORG_NAME_LOOKUP.ORGANIZATION_NAME_ES, gosalesdw.GO_ORG_NAME_LOOKUP.ORGANIZATION_NAME_FR, 
                      gosalesdw.GO_ORG_NAME_LOOKUP.ORGANIZATION_NAME_IT, gosalesdw.GO_ORG_NAME_LOOKUP.ORGANIZATION_NAME_JA, 
                      gosalesdw.GO_ORG_NAME_LOOKUP.ORGANIZATION_NAME_KO, gosalesdw.GO_ORG_NAME_LOOKUP.ORGANIZATION_NAME_PT, 
                      gosalesdw.GO_ORG_NAME_LOOKUP.ORGANIZATION_NAME_RU, gosalesdw.GO_ORG_NAME_LOOKUP.ORGANIZATION_NAME_SC, 
                      gosalesdw.GO_ORG_NAME_LOOKUP.ORGANIZATION_NAME_TC, gosalesdw.GO_ORG_DIM.ORGANIZATION_LEVEL
FROM         gosalesdw.GO_ORG_DIM INNER JOIN
                      gosalesdw.GO_ORG_NAME_LOOKUP ON 
                      gosalesdw.GO_ORG_DIM.ORGANIZATION_CODE = gosalesdw.GO_ORG_NAME_LOOKUP.ORGANIZATION_CODE
~

CREATE VIEW gosalesdw.VIEW_PRODUCT_NAME
AS
SELECT     PRODUCT_NUMBER, MIN(CASE PRODUCT_LANGUAGE WHEN N'EN' THEN PRODUCT_NAME ELSE NULL END) AS PRODUCT_EN, 
                      MIN(CASE PRODUCT_LANGUAGE WHEN N'DE' THEN PRODUCT_NAME ELSE NULL END) AS PRODUCT_DE, 
                      MIN(CASE PRODUCT_LANGUAGE WHEN N'ES' THEN PRODUCT_NAME ELSE NULL END) AS PRODUCT_ES, 
                      MIN(CASE PRODUCT_LANGUAGE WHEN N'FR' THEN PRODUCT_NAME ELSE NULL END) AS PRODUCT_FR, 
                      MIN(CASE PRODUCT_LANGUAGE WHEN N'IT' THEN PRODUCT_NAME ELSE NULL END) AS PRODUCT_IT, 
                      MIN(CASE PRODUCT_LANGUAGE WHEN N'JA' THEN PRODUCT_NAME ELSE NULL END) AS PRODUCT_JA, 
                      MIN(CASE PRODUCT_LANGUAGE WHEN N'KO' THEN PRODUCT_NAME ELSE NULL END) AS PRODUCT_KO, 
                      MIN(CASE PRODUCT_LANGUAGE WHEN N'PT' THEN PRODUCT_NAME ELSE NULL END) AS PRODUCT_PT, 
                      MIN(CASE PRODUCT_LANGUAGE WHEN N'RU' THEN PRODUCT_NAME ELSE NULL END) AS PRODUCT_RU, 
                      MIN(CASE PRODUCT_LANGUAGE WHEN N'SC' THEN PRODUCT_NAME ELSE NULL END) AS PRODUCT_SC, 
                      MIN(CASE PRODUCT_LANGUAGE WHEN N'TC' THEN PRODUCT_NAME ELSE NULL END) AS PRODUCT_TC
FROM         gosalesdw.SLS_PRODUCT_LOOKUP
GROUP BY PRODUCT_NUMBER
~

CREATE VIEW gosalesdw.VIEW_SUBMISSION_DIM
AS
SELECT     gosalesdw.FIN_SUBM_DIM.SUBMISSION_KEY, gosalesdw.FIN_SUBM_DIM.SUBMISSION_CODE, 
                      gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_EN, gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_DE, 
                      gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_ES, gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_FR, 
                      gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_IT, gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_JA, 
                      gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_KO, gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_PT, 
                      gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_RU, gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_SC, 
                      gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_TC, gosalesdw.FIN_SUBM_TYPE_LOOKUP.SUBMISSION_TYPE_CODE, 
                      gosalesdw.FIN_SUBM_TYPE_LOOKUP.SUBMISSION_TYPE_EN, gosalesdw.FIN_SUBM_TYPE_LOOKUP.SUBMISSION_TYPE_DE, 
                      gosalesdw.FIN_SUBM_TYPE_LOOKUP.SUBMISSION_TYPE_ES, gosalesdw.FIN_SUBM_TYPE_LOOKUP.SUBMISSION_TYPE_FR, 
                      gosalesdw.FIN_SUBM_TYPE_LOOKUP.SUBMISSION_TYPE_IT, gosalesdw.FIN_SUBM_TYPE_LOOKUP.SUBMISSION_TYPE_JA, 
                      gosalesdw.FIN_SUBM_TYPE_LOOKUP.SUBMISSION_TYPE_KO, gosalesdw.FIN_SUBM_TYPE_LOOKUP.SUBMISSION_TYPE_PT, 
                      gosalesdw.FIN_SUBM_TYPE_LOOKUP.SUBMISSION_TYPE_RU, gosalesdw.FIN_SUBM_TYPE_LOOKUP.SUBMISSION_TYPE_SC, 
                      gosalesdw.FIN_SUBM_TYPE_LOOKUP.SUBMISSION_TYPE_TC, gosalesdw.FIN_SUBM_CURRENCY_LOOKUP.SUBMISSION_CURRENCY_CODE, 
                      gosalesdw.FIN_SUBM_CURRENCY_LOOKUP.SUBMISSION_CURRENCY_EN, 
                      gosalesdw.FIN_SUBM_CURRENCY_LOOKUP.SUBMISSION_CURRENCY_DE, 
                      gosalesdw.FIN_SUBM_CURRENCY_LOOKUP.SUBMISSION_CURRENCY_ES, 
                      gosalesdw.FIN_SUBM_CURRENCY_LOOKUP.SUBMISSION_CURRENCY_FR, 
                      gosalesdw.FIN_SUBM_CURRENCY_LOOKUP.SUBMISSION_CURRENCY_IT, 
                      gosalesdw.FIN_SUBM_CURRENCY_LOOKUP.SUBMISSION_CURRENCY_JA, 
                      gosalesdw.FIN_SUBM_CURRENCY_LOOKUP.SUBMISSION_CURRENCY_KO, 
                      gosalesdw.FIN_SUBM_CURRENCY_LOOKUP.SUBMISSION_CURRENCY_PT, 
                      gosalesdw.FIN_SUBM_CURRENCY_LOOKUP.SUBMISSION_CURRENCY_RU, 
                      gosalesdw.FIN_SUBM_CURRENCY_LOOKUP.SUBMISSION_CURRENCY_TC, 
                      gosalesdw.FIN_SUBM_CURRENCY_LOOKUP.SUBMISSION_CURRENCY_SC, gosalesdw.FIN_SUBM_DIM.SUBMISSION_YEAR
FROM         gosalesdw.FIN_SUBM_CURRENCY_LOOKUP INNER JOIN
                      gosalesdw.FIN_SUBM_DIM ON 
                      gosalesdw.FIN_SUBM_CURRENCY_LOOKUP.SUBMISSION_CURRENCY_CODE = gosalesdw.FIN_SUBM_DIM.SUBMISSION_CURRENCY_CODE INNER JOIN
                      gosalesdw.FIN_SUBM_TYPE_LOOKUP ON 
                      gosalesdw.FIN_SUBM_DIM.SUBMISSION_TYPE_CODE = gosalesdw.FIN_SUBM_TYPE_LOOKUP.SUBMISSION_TYPE_CODE
~

CREATE VIEW gosalesdw.VIEW_TIME_MONTH_DIM
AS
SELECT     CURRENT_YEAR, QUARTER_KEY, CURRENT_QUARTER, MONTH_KEY, CURRENT_MONTH, DAYS_IN_MONTH, MONTH_EN, MONTH_DE, MONTH_ES, 
                      MONTH_FR, MONTH_IT, MONTH_JA, MONTH_KO, MONTH_PT, MONTH_RU, MONTH_SC, MONTH_TC
FROM         gosalesdw.GO_TIME_DIM
GROUP BY CURRENT_YEAR, QUARTER_KEY, CURRENT_QUARTER, MONTH_KEY, CURRENT_MONTH, DAYS_IN_MONTH, MONTH_EN, MONTH_DE, 
                      MONTH_FR, MONTH_JA, MONTH_RU, MONTH_SC, MONTH_ES, MONTH_IT, MONTH_KO, MONTH_PT, MONTH_TC
~

CREATE VIEW gosalesdw.VIEW_STATEMENT_FACT
AS
SELECT     gosalesdw.FIN_FINANCE_FACT.SUBMISSION_KEY, gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_EN, 
                      gosalesdw.FIN_FINANCE_FACT.ORGANIZATION_KEY, gosalesdw.GO_ORG_DIM.ORGANIZATION_PARENT, T1.MONTH_KEY, T1.MONTH_EN, 
                      gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_KEY, gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_PARENT, 
                      gosalesdw.FIN_ACCOUNT_DIM.DEBIT_OR_CREDIT, gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE, 
                      gosalesdw.FIN_ACCOUNT_DIM.AGGREGATION_SIGN, gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_EN, 
                      CASE gosalesdw.FIN_ACCOUNT_DIM.DEBIT_OR_CREDIT WHEN N'C' THEN gosalesdw.FIN_FINANCE_FACT.AMOUNT_MONTH * - 1 ELSE gosalesdw.FIN_FINANCE_FACT.AMOUNT_MONTH
                       * 1 END AS STMT_MONTH, 
                      CASE gosalesdw.FIN_ACCOUNT_DIM.DEBIT_OR_CREDIT WHEN N'C' THEN gosalesdw.FIN_FINANCE_FACT.AMOUNT_YEAR_TO_DATE * - 1 ELSE gosalesdw.FIN_FINANCE_FACT.AMOUNT_YEAR_TO_DATE
                       * 1 END AS STMT_YEAR, gosalesdw.FIN_FINANCE_FACT.AMOUNT_YEAR_TO_DATE, gosalesdw.FIN_FINANCE_FACT.AMOUNT_MONTH, 
                      gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_DE, gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_ES, 
                      gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_FR, gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_IT, 
                      gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_JA, gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_KO, 
                      gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_PT, gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_RU, 
                      gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_SC, gosalesdw.FIN_SUBM_DIM.SUBMISSION_NAME_TC, T1.MONTH_DE, T1.MONTH_ES, 
                      T1.MONTH_FR, T1.MONTH_IT, T1.MONTH_JA, T1.MONTH_KO, T1.MONTH_PT, T1.MONTH_RU, T1.MONTH_SC, T1.MONTH_TC, 
                      gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_DE, gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_ES, 
                      gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_FR, gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_IT, 
                      gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_JA, gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_KO, 
                      gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_PT, gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_RU, 
                      gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_SC, gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_NAME_TC
FROM         gosalesdw.FIN_FINANCE_FACT INNER JOIN
                          (SELECT     MONTH_KEY, MONTH_EN, MONTH_DE, MONTH_ES, MONTH_FR, MONTH_IT, MONTH_JA, MONTH_KO, MONTH_PT, MONTH_RU, 
                                                   MONTH_SC, MONTH_TC
                            FROM          gosalesdw.GO_TIME_DIM
                            GROUP BY MONTH_KEY, MONTH_EN, MONTH_DE, MONTH_ES, MONTH_FR, MONTH_IT, MONTH_JA, MONTH_KO, MONTH_PT, MONTH_RU, 
                                                   MONTH_SC, MONTH_TC) T1 ON gosalesdw.FIN_FINANCE_FACT.MONTH_KEY = T1.MONTH_KEY INNER JOIN
                      gosalesdw.FIN_SUBM_DIM ON gosalesdw.FIN_FINANCE_FACT.SUBMISSION_KEY = gosalesdw.FIN_SUBM_DIM.SUBMISSION_KEY INNER JOIN
                      gosalesdw.FIN_ACCOUNT_DIM ON gosalesdw.FIN_FINANCE_FACT.ACCOUNT_KEY = gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_KEY INNER JOIN
                      gosalesdw.FIN_ACCOUNT_NAME_LOOKUP ON 
                      gosalesdw.FIN_ACCOUNT_DIM.ACCOUNT_CODE = gosalesdw.FIN_ACCOUNT_NAME_LOOKUP.ACCOUNT_CODE INNER JOIN
                      gosalesdw.GO_ORG_DIM ON gosalesdw.FIN_FINANCE_FACT.ORGANIZATION_KEY = gosalesdw.GO_ORG_DIM.ORGANIZATION_KEY
WHERE     (gosalesdw.FIN_ACCOUNT_DIM.DEBIT_OR_CREDIT IN (N'C', N'D'))
~



CREATE VIEW gosalesdw.VW_ACTIVE_EMPLOYEE_DIM
AS
SELECT     *
FROM         gosalesdw.EMP_EMPLOYEE_DIM
WHERE     (ACTIVE_INDICATOR = 1)
~


--GRANT PRIVILEGES TO USER GOSALESDW
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESDW.VIEW_ACCOUNT_DIM TO USER GOSALESDW
~
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESDW.VIEW_BALANCED_ORG_DIM TO USER GOSALESDW
~
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESDW.VIEW_ORG_DIM TO USER GOSALESDW
~
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESDW.VIEW_PRODUCT_NAME TO USER GOSALESDW
~
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESDW.VIEW_STATEMENT_FACT TO USER GOSALESDW
~
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESDW.VIEW_SUBMISSION_DIM TO USER GOSALESDW
~
GRANT  SELECT,INSERT,DELETE,UPDATE ON GOSALESDW.VIEW_TIME_MONTH_DIM TO USER GOSALESDW
~
GRANT  SELECT,INSERT,DELETE,UPDATE ON gosalesdw.VW_ACTIVE_EMPLOYEE_DIM TO USER GOSALESDW
~


--SPECIFY CONSTRAINTS IN GOSALESDW
ALTER TABLE gosalesdw.DIST_INVENTORY_FACT  		
	ADD CONSTRAINT FK_DIST_I_481466 FOREIGN KEY	
	(	
		BRANCH_KEY
	) REFERENCES gosalesdw.GO_BRANCH_DIM (	
		BRANCH_KEY
	)	
	ADD CONSTRAINT FK_DIST_I_616884 FOREIGN KEY	
	(	
		PRODUCT_KEY
	) REFERENCES gosalesdw.SLS_PRODUCT_DIM (	
		PRODUCT_KEY
	)	
~		
		
ALTER TABLE gosalesdw.DIST_PRODUCT_FORECAST_FACT  		
	ADD CONSTRAINT FK_DIST_P_923668 FOREIGN KEY	
	(	
		BRANCH_KEY
	) REFERENCES gosalesdw.GO_BRANCH_DIM (	
		BRANCH_KEY
	)	
~		
		
ALTER TABLE gosalesdw.DIST_RETURNED_ITEMS_FACT  		
	ADD CONSTRAINT FK_DIST_R_387708 FOREIGN KEY	
	(	
		RETURN_REASON_KEY
	) REFERENCES gosalesdw.DIST_RETURN_REASON_DIM (	
		RETURN_REASON_KEY
	)	
	ADD CONSTRAINT FK_DIST_R_520030 FOREIGN KEY	
	(	
		EMPLOYEE_KEY
	) REFERENCES gosalesdw.EMP_EMPLOYEE_DIM (	
		EMPLOYEE_KEY
	)	
	ADD CONSTRAINT FK_DIST_R_847262 FOREIGN KEY	
	(	
		DAY_KEY
	) REFERENCES gosalesdw.GO_TIME_DIM (	
		DAY_KEY
	)	
	ADD CONSTRAINT FK_DIST_R_802934 FOREIGN KEY	
	(	
		ORDER_METHOD_KEY
	) REFERENCES gosalesdw.SLS_ORDER_METHOD_DIM (	
		ORDER_METHOD_KEY
	)	
	ADD CONSTRAINT FK_DIST_R_116676 FOREIGN KEY	
	(	
		PRODUCT_KEY
	) REFERENCES gosalesdw.SLS_PRODUCT_DIM (	
		PRODUCT_KEY
	)	
	ADD CONSTRAINT FK_DIST_R_171513 FOREIGN KEY	
	(	
		RETAILER_SITE_KEY
	) REFERENCES gosalesdw.SLS_RTL_DIM (	
		RETAILER_SITE_KEY
	)	
	ADD CONSTRAINT FK_DIST_R_878566 FOREIGN KEY	
	(	
		SALES_ORDER_KEY
	) REFERENCES gosalesdw.SLS_SALES_ORDER_DIM (	
		SALES_ORDER_KEY
	)	
~		
		
ALTER TABLE gosalesdw.EMP_EMPLOYEE_DIM  		
	ADD CONSTRAINT FK_EMP_EM_993846 FOREIGN KEY	
	(	
		GENDER_CODE
	) REFERENCES gosalesdw.GO_GENDER_LOOKUP (	
		GENDER_CODE
	)	
~		
		
ALTER TABLE gosalesdw.EMP_EXPENSE_FACT  		
	ADD CONSTRAINT FK_EMP_EX_135831 FOREIGN KEY	
	(	
		EMPLOYEE_KEY
	) REFERENCES gosalesdw.EMP_EMPLOYEE_DIM (	
		EMPLOYEE_KEY
	)	
	ADD CONSTRAINT FK_EMP_EX_116781 FOREIGN KEY	
	(	
		EXPENSE_TYPE_KEY
	) REFERENCES gosalesdw.EMP_EXPENSE_TYPE_DIM (	
		EXPENSE_TYPE_KEY
	)	
	ADD CONSTRAINT FK_EMP_EX_823340 FOREIGN KEY	
	(	
		POSITION_KEY
	) REFERENCES gosalesdw.EMP_POSITION_DIM (	
		POSITION_KEY
	)	
	ADD CONSTRAINT FK_EMP_EX_784828 FOREIGN KEY	
	(	
		ACCOUNT_KEY
	) REFERENCES gosalesdw.FIN_ACCOUNT_DIM (	
		ACCOUNT_KEY
	)	
	ADD CONSTRAINT FK_EMP_EX_844716 FOREIGN KEY	
	(	
		ORGANIZATION_KEY
	) REFERENCES gosalesdw.GO_ORG_DIM (	
		ORGANIZATION_KEY
	)	
	ADD CONSTRAINT FK_EMP_EX_338023 FOREIGN KEY	
	(	
		DAY_KEY
	) REFERENCES gosalesdw.GO_TIME_DIM (	
		DAY_KEY
	)	
~		
		
ALTER TABLE gosalesdw.EMP_EXPENSE_PLAN_FACT  		
	ADD CONSTRAINT FK_EMP_EX_485919 FOREIGN KEY	
	(	
		EXPENSE_TYPE_KEY
	) REFERENCES gosalesdw.EMP_EXPENSE_TYPE_DIM (	
		EXPENSE_TYPE_KEY
	)	
	ADD CONSTRAINT FK_EMP_EX_998315 FOREIGN KEY	
	(	
		ORGANIZATION_KEY
	) REFERENCES gosalesdw.GO_ORG_DIM (	
		ORGANIZATION_KEY
	)	
~		
		
ALTER TABLE gosalesdw.EMP_EXPENSE_TYPE_DIM  		
	ADD CONSTRAINT FK_EMP_EX_808847 FOREIGN KEY	
	(	
		EXPENSE_UNIT_CODE
	) REFERENCES gosalesdw.EMP_EXPENSE_UNIT_LOOKUP (	
		EXPENSE_UNIT_CODE
	)	
~		
		
ALTER TABLE gosalesdw.EMP_POSITION_DIM  		
	ADD CONSTRAINT FK_EMP_PO_675305 FOREIGN KEY	
	(	
		POSITION_CODE
	) REFERENCES gosalesdw.EMP_POSITION_LOOKUP (	
		POSITION_CODE
	)	
~		
		
ALTER TABLE gosalesdw.EMP_POSITION_SUMMARY_FACT  		
	ADD CONSTRAINT FK_EMP_PO_624870 FOREIGN KEY	
	(	
		POSITION_KEY
	) REFERENCES gosalesdw.EMP_POSITION_DIM (	
		POSITION_KEY
	)	
	ADD CONSTRAINT FK_EMP_PO_904103 FOREIGN KEY	
	(	
		ORGANIZATION_KEY
	) REFERENCES gosalesdw.GO_ORG_DIM (	
		ORGANIZATION_KEY
	)	
	ADD CONSTRAINT FK_EMP_PO_794449 FOREIGN KEY	
	(	
		DAY_KEY
	) REFERENCES gosalesdw.GO_TIME_DIM (	
		DAY_KEY
	)	
~		
		
ALTER TABLE gosalesdw.EMP_RANKING_FACT  		
	ADD CONSTRAINT FK_EMP_RA_210274 FOREIGN KEY	
	(	
		EMPLOYEE_KEY
	) REFERENCES gosalesdw.EMP_EMPLOYEE_DIM (	
		EMPLOYEE_KEY
	)	
	ADD CONSTRAINT FK_EMP_RA_201717 FOREIGN KEY	
	(	
		POSITION_KEY
	) REFERENCES gosalesdw.EMP_POSITION_DIM (	
		POSITION_KEY
	)	
	ADD CONSTRAINT FK_EMP_RA_266459 FOREIGN KEY	
	(	
		EMPLOYEE_RANKING_KEY
	) REFERENCES gosalesdw.EMP_RANKING_DIM (	
		EMPLOYEE_RANKING_KEY
	)	
	ADD CONSTRAINT FK_EMP_RA_188781 FOREIGN KEY	
	(	
		ORGANIZATION_KEY
	) REFERENCES gosalesdw.GO_ORG_DIM (	
		ORGANIZATION_KEY
	)	
	ADD CONSTRAINT FK_EMP_RA_422418 FOREIGN KEY	
	(	
		DAY_KEY
	) REFERENCES gosalesdw.GO_TIME_DIM (	
		DAY_KEY
	)	
~		
		
ALTER TABLE gosalesdw.EMP_RECRUITMENT_FACT  		
	ADD CONSTRAINT FK_EMP_RE_755539 FOREIGN KEY	
	(	
		POSITION_KEY
	) REFERENCES gosalesdw.EMP_POSITION_DIM (	
		POSITION_KEY
	)	
	ADD CONSTRAINT FK_EMP_RE_628359 FOREIGN KEY	
	(	
		RECRUITMENT_MEDIUM_KEY
	) REFERENCES gosalesdw.EMP_RECRUITMENT_DIM (	
		RECRUITMENT_MEDIUM_KEY
	)	
	ADD CONSTRAINT FK_EMP_RE_196459 FOREIGN KEY	
	(	
		BRANCH_KEY
	) REFERENCES gosalesdw.GO_BRANCH_DIM (	
		BRANCH_KEY
	)	
	ADD CONSTRAINT FK_EMP_RE_693834 FOREIGN KEY	
	(	
		ORGANIZATION_KEY
	) REFERENCES gosalesdw.GO_ORG_DIM (	
		ORGANIZATION_KEY
	)	
	ADD CONSTRAINT FK_EMP_RE_235231 FOREIGN KEY	
	(	
		POST_DAY_KEY
	) REFERENCES gosalesdw.GO_TIME_DIM (	
		DAY_KEY
	)	
~		
		
ALTER TABLE gosalesdw.EMP_SUCCESSION_FACT  		
	ADD CONSTRAINT FK_EMP_SU_457810 FOREIGN KEY	
	(	
		EMPLOYEE_KEY
	) REFERENCES gosalesdw.EMP_EMPLOYEE_DIM (	
		EMPLOYEE_KEY
	)	
	ADD CONSTRAINT FK_EMP_SU_786151 FOREIGN KEY	
	(	
		POSITION_KEY
	) REFERENCES gosalesdw.EMP_POSITION_DIM (	
		POSITION_KEY
	)	
	ADD CONSTRAINT FK_EMP_SU_297339 FOREIGN KEY	
	(	
		SUCCESSOR_STATUS_KEY
	) REFERENCES gosalesdw.EMP_SUCCESSION_STATUS_DIM (	
		SUCCESSOR_STATUS_KEY
	)	
	ADD CONSTRAINT FK_EMP_SU_453030 FOREIGN KEY	
	(	
		ORGANIZATION_KEY
	) REFERENCES gosalesdw.GO_ORG_DIM (	
		ORGANIZATION_KEY
	)	
	ADD CONSTRAINT FK_EMP_SU_383896 FOREIGN KEY	
	(	
		DAY_KEY
	) REFERENCES gosalesdw.GO_TIME_DIM (	
		DAY_KEY
	)	
~		
		
ALTER TABLE gosalesdw.EMP_SUMMARY_FACT  		
	ADD CONSTRAINT FK_EMP_SU_310998 FOREIGN KEY	
	(	
		EMPLOYEE_KEY
	) REFERENCES gosalesdw.EMP_EMPLOYEE_DIM (	
		EMPLOYEE_KEY
	)	
	ADD CONSTRAINT FK_EMP_SU_249887 FOREIGN KEY	
	(	
		POSITION_KEY
	) REFERENCES gosalesdw.EMP_POSITION_DIM (	
		POSITION_KEY
	)	
	ADD CONSTRAINT FK_EMP_SU_956331 FOREIGN KEY	
	(	
		ORGANIZATION_KEY
	) REFERENCES gosalesdw.GO_ORG_DIM (	
		ORGANIZATION_KEY
	)	
	ADD CONSTRAINT FK_EMP_SU_400029 FOREIGN KEY	
	(	
		DAY_KEY
	) REFERENCES gosalesdw.GO_TIME_DIM (	
		DAY_KEY
	)	
~		
		
ALTER TABLE gosalesdw.EMP_SURVEY_FACT  		
	ADD CONSTRAINT FK_EMP_SU_588199 FOREIGN KEY	
	(	
		POSITION_KEY
	) REFERENCES gosalesdw.EMP_POSITION_DIM (	
		POSITION_KEY
	)	
	ADD CONSTRAINT FK_EMP_SU_901671 FOREIGN KEY	
	(	
		EMPLOYEE_TOPIC_KEY
	) REFERENCES gosalesdw.EMP_SURVEY_TOPIC_DIM (	
		EMPLOYEE_TOPIC_KEY
	)	
	ADD CONSTRAINT FK_EMP_SU_432315 FOREIGN KEY	
	(	
		ORGANIZATION_KEY
	) REFERENCES gosalesdw.GO_ORG_DIM (	
		ORGANIZATION_KEY
	)	
	ADD CONSTRAINT FK_EMP_SU_225419 FOREIGN KEY	
	(	
		SATISFACTION_KEY
	) REFERENCES gosalesdw.GO_SATISFACTION_DIM (	
		SATISFACTION_KEY
	)	
	ADD CONSTRAINT FK_EMP_SU_660370 FOREIGN KEY	
	(	
		DAY_KEY
	) REFERENCES gosalesdw.GO_TIME_DIM (	
		DAY_KEY
	)	
~		
		
ALTER TABLE gosalesdw.EMP_SURVEY_TARG_FACT  		
	ADD CONSTRAINT FK_EMP_SU_485585 FOREIGN KEY	
	(	
		EMPLOYEE_TOPIC_KEY
	) REFERENCES gosalesdw.EMP_SURVEY_TOPIC_DIM (	
		EMPLOYEE_TOPIC_KEY
	)	
~		
		
ALTER TABLE gosalesdw.EMP_TRAINING_FACT  		
	ADD CONSTRAINT FK_EMP_TR_834131 FOREIGN KEY	
	(	
		EMPLOYEE_KEY
	) REFERENCES gosalesdw.EMP_EMPLOYEE_DIM (	
		EMPLOYEE_KEY
	)	
	ADD CONSTRAINT FK_EMP_TR_584561 FOREIGN KEY	
	(	
		EXPENSE_TYPE_KEY
	) REFERENCES gosalesdw.EMP_EXPENSE_TYPE_DIM (	
		EXPENSE_TYPE_KEY
	)	
	ADD CONSTRAINT FK_EMP_TR_744042 FOREIGN KEY	
	(	
		POSITION_KEY
	) REFERENCES gosalesdw.EMP_POSITION_DIM (	
		POSITION_KEY
	)	
	ADD CONSTRAINT FK_EMP_TR_422856 FOREIGN KEY	
	(	
		TRAINING_KEY
	) REFERENCES gosalesdw.EMP_TRAINING_DIM (	
		TRAINING_KEY
	)	
	ADD CONSTRAINT FK_EMP_TR_787825 FOREIGN KEY	
	(	
		ORGANIZATION_KEY
	) REFERENCES gosalesdw.GO_ORG_DIM (	
		ORGANIZATION_KEY
	)	
	ADD CONSTRAINT FK_EMP_TR_887725 FOREIGN KEY	
	(	
		DAY_KEY
	) REFERENCES gosalesdw.GO_TIME_DIM (	
		DAY_KEY
	)	
~		
		
ALTER TABLE gosalesdw.FIN_ACCOUNT_DIM  		
	ADD CONSTRAINT FK_FIN_AC_859556 FOREIGN KEY	
	(	
		ACCOUNT_CLASS_CODE
	) REFERENCES gosalesdw.FIN_ACCOUNT_CLASS_LOOKUP (	
		ACCOUNT_CLASS_CODE
	)	
	ADD CONSTRAINT FK_FIN_AC_117367 FOREIGN KEY	
	(	
		ACCOUNT_CODE
	) REFERENCES gosalesdw.FIN_ACCOUNT_NAME_LOOKUP (	
		ACCOUNT_CODE
	)	
	ADD CONSTRAINT FK_FIN_AC_181075 FOREIGN KEY	
	(	
		ACCOUNT_TYPE_CODE
	) REFERENCES gosalesdw.FIN_ACCOUNT_TYPE_LOOKUP (	
		ACCOUNT_TYPE_CODE
	)	
~		
		
ALTER TABLE gosalesdw.FIN_FINANCE_FACT  		
	ADD CONSTRAINT FK_FIN_FI_174032 FOREIGN KEY	
	(	
		ACCOUNT_KEY
	) REFERENCES gosalesdw.FIN_ACCOUNT_DIM (	
		ACCOUNT_KEY
	)	
	ADD CONSTRAINT FK_FIN_FI_528551 FOREIGN KEY	
	(	
		SUBMISSION_KEY
	) REFERENCES gosalesdw.FIN_SUBM_DIM (	
		SUBMISSION_KEY
	)	
	ADD CONSTRAINT FK_FIN_FI_558254 FOREIGN KEY	
	(	
		ORGANIZATION_KEY
	) REFERENCES gosalesdw.GO_ORG_DIM (	
		ORGANIZATION_KEY
	)	
~		
		
ALTER TABLE gosalesdw.FIN_SUBM_DIM  		
	ADD CONSTRAINT FK_FIN_SU_617965 FOREIGN KEY	
	(	
		SUBMISSION_CURRENCY_CODE
	) REFERENCES gosalesdw.FIN_SUBM_CURRENCY_LOOKUP (	
		SUBMISSION_CURRENCY_CODE
	)	
	ADD CONSTRAINT FK_FIN_SU_323571 FOREIGN KEY	
	(	
		SUBMISSION_TYPE_CODE
	) REFERENCES gosalesdw.FIN_SUBM_TYPE_LOOKUP (	
		SUBMISSION_TYPE_CODE
	)	
~		
		
ALTER TABLE gosalesdw.GO_ORG_DIM  		
	ADD CONSTRAINT FK_GO_ORG_120096 FOREIGN KEY	
	(	
		ORGANIZATION_CODE
	) REFERENCES gosalesdw.GO_ORG_NAME_LOOKUP (	
		ORGANIZATION_CODE
	)	
~		
		
ALTER TABLE gosalesdw.GO_TIME_DIM  		
	ADD CONSTRAINT FK_GO_TIM_681724 FOREIGN KEY	
	(	
		QUARTER_KEY
	) REFERENCES gosalesdw.GO_TIME_QUARTER_LOOKUP (	
		QUARTER_KEY
	)	
~		
		
ALTER TABLE gosalesdw.MRK_PRODUCT_SURVEY_FACT  		
	ADD CONSTRAINT FK_MRK_PR_796852 FOREIGN KEY	
	(	
		BRANCH_KEY
	) REFERENCES gosalesdw.GO_BRANCH_DIM (	
		BRANCH_KEY
	)	
	ADD CONSTRAINT FK_MRK_PR_960139 FOREIGN KEY	
	(	
		ORGANIZATION_KEY
	) REFERENCES gosalesdw.GO_ORG_DIM (	
		ORGANIZATION_KEY
	)	
	ADD CONSTRAINT FK_MRK_PR_482842 FOREIGN KEY	
	(	
		RTL_COUNTRY_KEY
	) REFERENCES gosalesdw.GO_REGION_DIM (	
		COUNTRY_KEY
	)	
	ADD CONSTRAINT FK_MRK_PR_887800 FOREIGN KEY	
	(	
		PRODUCT_SURVEY_KEY
	) REFERENCES gosalesdw.MRK_PRODUCT_SURVEY_DIM (	
		PRODUCT_SURVEY_KEY
	)	
	ADD CONSTRAINT FK_MRK_PR_986966 FOREIGN KEY	
	(	
		PRODUCT_KEY
	) REFERENCES gosalesdw.SLS_PRODUCT_DIM (	
		PRODUCT_KEY
	)	
~		
		
ALTER TABLE gosalesdw.MRK_PROD_SURVEY_TARG_FACT  		
	ADD CONSTRAINT FK_MRK_PR_943810 FOREIGN KEY	
	(	
		PRODUCT_SURVEY_KEY
	) REFERENCES gosalesdw.MRK_PRODUCT_SURVEY_DIM (	
		PRODUCT_SURVEY_KEY
	)	
	ADD CONSTRAINT FK_MRK_PR_399532 FOREIGN KEY	
	(	
		PRODUCT_KEY
	) REFERENCES gosalesdw.SLS_PRODUCT_DIM (	
		PRODUCT_KEY
	)	
~		
		
ALTER TABLE gosalesdw.MRK_PROMOTION_DIM  		
	ADD CONSTRAINT FK_MRK_PR_855497 FOREIGN KEY	
	(	
		BUNDLE_GROUP_CODE
	) REFERENCES gosalesdw.MRK_BUNDLE_GROUP_LOOKUP (	
		BUNDLE_GROUP_CODE
	)	
	ADD CONSTRAINT FK_MRK_PR_401710 FOREIGN KEY	
	(	
		CAMPAIGN_CODE
	) REFERENCES gosalesdw.MRK_CAMPAIGN_LOOKUP (	
		CAMPAIGN_CODE
	)	
~		
		
ALTER TABLE gosalesdw.MRK_PROMOTION_FACT  		
	ADD CONSTRAINT FK_MRK_PR_242698 FOREIGN KEY	
	(	
		EMPLOYEE_KEY
	) REFERENCES gosalesdw.EMP_EMPLOYEE_DIM (	
		EMPLOYEE_KEY
	)	
	ADD CONSTRAINT FK_MRK_PR_162580 FOREIGN KEY	
	(	
		ORGANIZATION_KEY
	) REFERENCES gosalesdw.GO_ORG_DIM (	
		ORGANIZATION_KEY
	)	
	ADD CONSTRAINT FK_MRK_PR_112198 FOREIGN KEY	
	(	
		RTL_COUNTRY_KEY
	) REFERENCES gosalesdw.GO_REGION_DIM (	
		COUNTRY_KEY
	)	
	ADD CONSTRAINT FK_MRK_PR_977347 FOREIGN KEY	
	(	
		ORDER_DAY_KEY
	) REFERENCES gosalesdw.GO_TIME_DIM (	
		DAY_KEY
	)	
	ADD CONSTRAINT FK_MRK_PR_835136 FOREIGN KEY	
	(	
		PROMOTION_KEY
	) REFERENCES gosalesdw.MRK_PROMOTION_DIM (	
		PROMOTION_KEY
	)	
	ADD CONSTRAINT FK_MRK_PR_658440 FOREIGN KEY	
	(	
		PRODUCT_KEY
	) REFERENCES gosalesdw.SLS_PRODUCT_DIM (	
		PRODUCT_KEY
	)	
	ADD CONSTRAINT FK_MRK_PR_169035 FOREIGN KEY	
	(	
		SALES_ORDER_KEY
	) REFERENCES gosalesdw.SLS_SALES_ORDER_DIM (	
		SALES_ORDER_KEY
	)	
~		
		
ALTER TABLE gosalesdw.MRK_PROMOTION_PLAN_FACT  		
	ADD CONSTRAINT FK_MRK_PR_713564 FOREIGN KEY	
	(	
		BRANCH_KEY
	) REFERENCES gosalesdw.GO_BRANCH_DIM (	
		BRANCH_KEY
	)	
	ADD CONSTRAINT FK_MRK_PR_363552 FOREIGN KEY	
	(	
		ORGANIZATION_KEY
	) REFERENCES gosalesdw.GO_ORG_DIM (	
		ORGANIZATION_KEY
	)	
	ADD CONSTRAINT FK_MRK_PR_326565 FOREIGN KEY	
	(	
		RTL_COUNTRY_KEY
	) REFERENCES gosalesdw.GO_REGION_DIM (	
		COUNTRY_KEY
	)	
	ADD CONSTRAINT FK_MRK_PR_699653 FOREIGN KEY	
	(	
		PROMOTION_KEY
	) REFERENCES gosalesdw.MRK_PROMOTION_DIM (	
		PROMOTION_KEY
	)	
	ADD CONSTRAINT FK_MRK_PR_556226 FOREIGN KEY	
	(	
		PRODUCT_KEY
	) REFERENCES gosalesdw.SLS_PRODUCT_DIM (	
		PRODUCT_KEY
	)	
~		
		
ALTER TABLE gosalesdw.MRK_RTL_SURVEY_FACT  		
	ADD CONSTRAINT FK_MRK_RT_949337 FOREIGN KEY	
	(	
		BRANCH_KEY
	) REFERENCES gosalesdw.GO_BRANCH_DIM (	
		BRANCH_KEY
	)	
	ADD CONSTRAINT FK_MRK_RT_958931 FOREIGN KEY	
	(	
		ORGANIZATION_KEY
	) REFERENCES gosalesdw.GO_ORG_DIM (	
		ORGANIZATION_KEY
	)	
	ADD CONSTRAINT FK_MRK_RT_760908 FOREIGN KEY	
	(	
		RTL_COUNTRY_KEY
	) REFERENCES gosalesdw.GO_REGION_DIM (	
		COUNTRY_KEY
	)	
	ADD CONSTRAINT FK_MRK_RT_498277 FOREIGN KEY	
	(	
		RETAILER_SURVEY_KEY
	) REFERENCES gosalesdw.MRK_RTL_SURVEY_DIM (	
		RETAILER_SURVEY_KEY
	)	
~		
		
ALTER TABLE gosalesdw.MRK_RTL_SURVEY_TARG_FACT  		
	ADD CONSTRAINT FK_MRK_RT_409618 FOREIGN KEY	
	(	
		RETAILER_SURVEY_KEY
	) REFERENCES gosalesdw.MRK_RTL_SURVEY_DIM (	
		RETAILER_SURVEY_KEY
	)	
~		
		
ALTER TABLE gosalesdw.SLS_PRODUCT_DIM  		
	ADD CONSTRAINT FK_SLS_PR_258044 FOREIGN KEY	
	(	
		PRODUCT_BRAND_CODE
	) REFERENCES gosalesdw.SLS_PRODUCT_BRAND_LOOKUP (	
		PRODUCT_BRAND_CODE
	)	
	ADD CONSTRAINT FK_SLS_PR_713437 FOREIGN KEY	
	(	
		PRODUCT_COLOR_CODE
	) REFERENCES gosalesdw.SLS_PRODUCT_COLOR_LOOKUP (	
		PRODUCT_COLOR_CODE
	)	
	ADD CONSTRAINT FK_SLS_PR_107864 FOREIGN KEY	
	(	
		PRODUCT_LINE_CODE
	) REFERENCES gosalesdw.SLS_PRODUCT_LINE_LOOKUP (	
		PRODUCT_LINE_CODE
	)	
	ADD CONSTRAINT FK_SLS_PR_574992 FOREIGN KEY	
	(	
		PRODUCT_SIZE_CODE
	) REFERENCES gosalesdw.SLS_PRODUCT_SIZE_LOOKUP (	
		PRODUCT_SIZE_CODE
	)	
	ADD CONSTRAINT FK_SLS_PR_636799 FOREIGN KEY	
	(	
		PRODUCT_TYPE_CODE
	) REFERENCES gosalesdw.SLS_PRODUCT_TYPE_LOOKUP (	
		PRODUCT_TYPE_CODE
	)	
~		
		
ALTER TABLE gosalesdw.SLS_SALES_FACT  		
	ADD CONSTRAINT FK_SLS_SA_469797 FOREIGN KEY	
	(	
		EMPLOYEE_KEY
	) REFERENCES gosalesdw.EMP_EMPLOYEE_DIM (	
		EMPLOYEE_KEY
	)	
	ADD CONSTRAINT FK_SLS_SA_783364 FOREIGN KEY	
	(	
		ORGANIZATION_KEY
	) REFERENCES gosalesdw.GO_ORG_DIM (	
		ORGANIZATION_KEY
	)	
	ADD CONSTRAINT FK_SLS_SA_467221 FOREIGN KEY	
	(	
		ORDER_DAY_KEY
	) REFERENCES gosalesdw.GO_TIME_DIM (	
		DAY_KEY
	)	
	ADD CONSTRAINT FK_SLS_SA_124242 FOREIGN KEY	
	(	
		PROMOTION_KEY
	) REFERENCES gosalesdw.MRK_PROMOTION_DIM (	
		PROMOTION_KEY
	)	
	ADD CONSTRAINT FK_SLS_SA_236809 FOREIGN KEY	
	(	
		ORDER_METHOD_KEY
	) REFERENCES gosalesdw.SLS_ORDER_METHOD_DIM (	
		ORDER_METHOD_KEY
	)	
	ADD CONSTRAINT FK_SLS_SA_547467 FOREIGN KEY	
	(	
		PRODUCT_KEY
	) REFERENCES gosalesdw.SLS_PRODUCT_DIM (	
		PRODUCT_KEY
	)	
	ADD CONSTRAINT FK_SLS_SA_155859 FOREIGN KEY	
	(	
		RETAILER_SITE_KEY
	) REFERENCES gosalesdw.SLS_RTL_DIM (	
		RETAILER_SITE_KEY
	)	
	ADD CONSTRAINT FK_SLS_SA_443969 FOREIGN KEY	
	(	
		SALES_ORDER_KEY
	) REFERENCES gosalesdw.SLS_SALES_ORDER_DIM (	
		SALES_ORDER_KEY
	)	
~		
		
ALTER TABLE gosalesdw.SLS_SALES_TARG_FACT  		
	ADD CONSTRAINT FK_SLS_SA_896430 FOREIGN KEY	
	(	
		EMPLOYEE_KEY
	) REFERENCES gosalesdw.EMP_EMPLOYEE_DIM (	
		EMPLOYEE_KEY
	)	
	ADD CONSTRAINT FK_SLS_SA_221658 FOREIGN KEY	
	(	
		ORGANIZATION_KEY
	) REFERENCES gosalesdw.GO_ORG_DIM (	
		ORGANIZATION_KEY
	)	
	ADD CONSTRAINT FK_SLS_SA_680008 FOREIGN KEY	
	(	
		RTL_COUNTRY_KEY
	) REFERENCES gosalesdw.GO_REGION_DIM (	
		COUNTRY_KEY
	)	
~		

--Cubing Servies
ALTER TABLE "GOSALESDW"."GO_REGION_DIM" ADD CONSTRAINT "GO_REGION_DIM_COUNRY_CODE_UN" UNIQUE ("COUNTRY_CODE")~
ALTER TABLE "GOSALESDW"."SLS_RTL_DIM" ADD CONSTRAINT "SLS_RTL_DIM_GO_REGION_DIM_FK" FOREIGN KEY
	("RTL_COUNTRY_CODE")
	REFERENCES "GOSALESDW"."GO_REGION_DIM"
	("COUNTRY_CODE")
	ON DELETE CASCADE
	NOT ENFORCED~

ALTER TABLE "GOSALESDW"."SLS_RTL_DIM" ADD CONSTRAINT "SLS_RTL_DIM_RETAILER_KEY_RETAILER_SITE_KEY_UN" UNIQUE
	("RETAILER_KEY",
	 "RETAILER_SITE_KEY")~
ALTER TABLE "GOSALESDW"."SLS_SALES_FACT" ADD CONSTRAINT "SLS_SALES_FACT_SLS_RTL_DIM_RETAILER_KEY_RETAILER_SITE_KEY_FK" FOREIGN KEY
	("RETAILER_KEY",
	 "RETAILER_SITE_KEY")
	REFERENCES "GOSALESDW"."SLS_RTL_DIM"
	("RETAILER_KEY",
	  "RETAILER_SITE_KEY")
	ON DELETE CASCADE
	NOT ENFORCED~

ALTER TABLE "GOSALESDW"."SLS_SALES_FACT" ADD CONSTRAINT "SLS_SALES_FACT_GO_TIME_DIM_FK" FOREIGN KEY
	("SHIP_DAY_KEY")
	REFERENCES "GOSALESDW"."GO_TIME_DIM"
	("DAY_KEY")
	ON DELETE CASCADE
	NOT ENFORCED~


ALTER TABLE "GOSALESDW"."SLS_SALES_FACT" ADD CONSTRAINT "SLS_SALES_FACT_GO_TIME_DIM_FK1" FOREIGN KEY
	("CLOSE_DAY_KEY")
	REFERENCES "GOSALESDW"."GO_TIME_DIM"
	("DAY_KEY")
	ON DELETE CASCADE
	NOT ENFORCED~


SET CURRENT SCHEMA = GOSALES
~

DROP PROCEDURE GOSALES.ASSIGNSTAFF (INTEGER, INTEGER)
~
CREATE PROCEDURE GOSALES.ASSIGNSTAFF (IN ORDER_DETAIL_CODE_IN INTEGER, IN SALES_STAFF_CODE_IN INTEGER)
LANGUAGE SQL
BEGIN
UPDATE GOSALES.RETURNED_ITEM
SET ASSIGNED_TO = ASSIGNSTAFF.SALES_STAFF_CODE_IN
WHERE ORDER_DETAIL_CODE = ASSIGNSTAFF.ORDER_DETAIL_CODE_IN;
END
~

GRANT EXECUTE ON PROCEDURE GOSALES.ASSIGNSTAFF(INTEGER,INTEGER) TO USER GOSALES
~

CONNECT RESET
~

TERMINATE
~

