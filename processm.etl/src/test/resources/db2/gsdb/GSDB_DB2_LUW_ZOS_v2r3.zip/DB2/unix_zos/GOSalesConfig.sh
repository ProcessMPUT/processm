#!/bin/sh
########################################################################
#   5724-E34
#   (c) Copyright IBM Corporation 2008, 2009.
#   All rights reserved.
#
#   The source code for this program is not published or otherwise
#   divested of its trade secrets, irrespective of what has been
#   deposited with the U.S. Copyright Office.
########################################################################
#   Filename: GOSalesConfig.sh
#
#   Description :
#      This file contains the default configuration options that
#      are used when creating the GOSALES data.  These options
#      can be modified by the user to alter the configuration of
#      the sample database.
#
########################################################################

########################################################################
#   Enter the location name for the database
########################################################################
GOSALES_INST=

########################################################################
#   Enter the database name 
########################################################################
GOSALES_DB=GSDB

########################################################################
#   Enter the DB2 for z/OS version (8 or 9)
########################################################################
GOSALES_LEVEL=9

########################################################################
#   OPTIONAL: Create the database(Y/N)?  This will cause
#   an existing database with the same name to be dropped.
########################################################################
GOSALES_CREATEDB=

########################################################################
#   Enter the names of the storage group, 16K buffer pool and 
#   tablespaces to use.
#   The tablespaces can optionally be created by the script
########################################################################
GOSALES_STG=
GOSALES_BP=BP16K0
GOSALES_TS=GSDBTS
GOSALES_LOB_TS=GSLOBTS

########################################################################
#   Enter the names to use for each schema
#   WARNING: Existing objects in these schemas will be dropped
########################################################################
GOSALES_SCHEMA=GOSALES
GOSALESHR_SCHEMA=GOSALESHR
GOSALESMR_SCHEMA=GOSALESMR
GOSALESRT_SCHEMA=GOSALESRT
GOSALESCT_SCHEMA=GOSALESCT
GOSALESDW_SCHEMA=GOSALESDW

########################################################################
#   Enter the list of users, groups or PUBLIC that will have CONTROL
#   permissions for the GOSALES, GOSALESHR, GOSALESMR, GOSALESRT
#   and GOSALESCT schemas
#   This string needs to follow the syntax of the GRANT command.
#   Examples :
#     1) Provide control access to the user GOSALES and the group DBUSERS
#          GOSALES_GRANTEES=USER GOSALES, GROUP DBUSERS
#     2) Provide control access to everyone using PUBLIC
#          GOSALES_GRANTEES=PUBLIC
#     3) Provide control access to users BOB, JOE and SUE
#          GOSALES_GRANTEES=BOB,JOE,SUE
#
########################################################################
GOSALES_GRANTEES=GOSALES

########################################################################
#   Enter the list of users, groups or PUBLIC that will have CONTROL
#   permissions for the GOSALESDW schema
########################################################################
GOSALESDW_GRANTEES=GOSALESDW

