#!/bin/sh
########################################################################
#   5724-E34
#   (c) Copyright IBM Corporation 2008, 2009.
#   All rights reserved.
#
#   The source code for this program is not published or otherwise
#   divested of its trade secrets, irrespective of what has been
#   deposited with the U.S. Copyright Office.
########################################################################

echo --CREATE COMMENTS FOR ${GOSALES_SCHEMA} SCHEMA
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.BRANCH:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.BRANCH IS \'BRANCH contains address information for corporate offices and distribution centers.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.CONVERSION_RATE:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.CONVERSION_RATE IS \'CONVERSION_RATE contains currency exchange values.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.COUNTRY:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.COUNTRY IS \'COUNTRY describes country names where retailers operate, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.CURRENCY_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.CURRENCY_LOOKUP IS \'CURRENCY_LOOKUP describes currency names in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.EURO_CONVERSION:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.EURO_CONVERSION IS \'EURO_CONVERSION contains Euro conversion rates for the countries that the joined the ECM in 1999.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.INVENTORY_LEVELS:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.INVENTORY_LEVELS IS \'INVENTORY_LEVELS contains inventory data for sales made between sales operations and retailers.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.ORDER_DETAILS:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.ORDER_DETAILS IS \'ORDER_DETAILS contains transaction details on sales made to retailers.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.ORDER_HEADER:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.ORDER_HEADER IS \'ORDER_HEADER contains general order information on sales made to retailers.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.ORDER_METHOD:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.ORDER_METHOD IS \'ORDER_METHOD describes order methods such as fax or web, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.PRODUCT:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.PRODUCT IS \'PRODUCT contains product specifications.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.PRODUCT_BRAND:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.PRODUCT_BRAND IS \'PRODUCT_BRAND describes the product brand names in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.PRODUCT_COLOR_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.PRODUCT_COLOR_LOOKUP IS \'PRODUCT_COLOR_LOOKUP describes the product colors in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.PRODUCT_FORECAST:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.PRODUCT_FORECAST IS \'PRODUCT_FORECAST contains product volume forecasts at the sales branch level.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.PRODUCT_LINE:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.PRODUCT_LINE IS \'PRODUCT_LINE describes general product categories in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.PRODUCT_NAME_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.PRODUCT_NAME_LOOKUP IS \'PRODUCT_NAME_LOOKUP describribes product names and descriptions in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.PRODUCT_SIZE_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.PRODUCT_SIZE_LOOKUP IS \'PRODUCT_SIZE_LOOKUP describes product sizes in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.PRODUCT_TYPE:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.PRODUCT_TYPE IS \'PRODUCT_TYPE describes subcategories under product line of products sold by the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.RETURN_REASON:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.RETURN_REASON IS \'RETURN_REASON describes return reasons for products returned by retailers, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.RETURNED_ITEM:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.RETURNED_ITEM IS \'RETURNED_ITEM contains details of products returned by retailers.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.SALES_REGION:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.SALES_REGION IS \'SALES_REGION describes the region names under which countries are grouped as sales territories, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.SALES_TARGET:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.SALES_TARGET IS \'SALES_TARGET contains sales targets for employees of the Great Outdoors Company who sell to retailers.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.TIME_DIMENSION:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.TIME_DIMENSION IS \'TIME_DIMENSION contains a four-year range of date lookup values.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.TIME_QUARTER_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.TIME_QUARTER_LOOKUP IS \'TIME_QUARTER_LOOKUP describes quarterly periods used by the the Great Outdoors Company when making sales and financial reports, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALES_SCHEMA}.xgorev:
echo @
echo COMMENT ON TABLE ${GOSALES_SCHEMA}.xgorev IS \'xgorev contains release and revision information on the tables and data belonging to the transaction schemas: gosales, gosalesct, gosaleshr, gosalesmr, gosalesrt.\'
echo @
echo ""
echo --CREATE COMMENTS FOR ${GOSALESCT_SCHEMA} SCHEMA
echo echo CREATING COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_COUNTRY:
echo @
echo COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_COUNTRY IS \'CUST_COUNTRY describes country names where online sales are made to consumers, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_CRDT_CARD:
echo @
echo COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_CRDT_CARD IS \'CUST_CRDT_CARD contains credit card information of consumers who shop online.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_CRDT_CHECK:
echo @
echo COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_CRDT_CHECK IS \'CUST_CRDT_CHECK contains credit card scores of consumers who shop online.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_CUSTOMER:
echo @
echo COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_CUSTOMER IS \'CUST_CUSTOMER contains address information of consumers who shop online.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_INTEREST:
echo @
echo COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_INTEREST IS \'CUST_INTEREST contains interests or hobbies of consumers who shop online.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_INTEREST_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_INTEREST_LOOKUP IS \'CUST_INTEREST_LOOKUP describes interests or hobbies of consumers who shop online, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_MARITAL_STATUS:
echo @
echo COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_MARITAL_STATUS IS \'CUST_MARITAL_STATUS describes marital status of consumers who shop online, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_ORDER_DETAIL:
echo @
echo COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_ORDER_DETAIL IS \'CUST_ORDER_DETAIL contains details of purchases made by consumers who shop online.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_ORDER_HEADER:
echo @
echo COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_ORDER_HEADER IS \'CUST_ORDER_HEADER contains general order information of transactions made by consumers who shop online.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_ORDER_STATUS:
echo @
echo COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_ORDER_STATUS IS \'CUST_ORDER_STATUS describes order status of consumer transactions made online, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_PRICE:
echo @
echo COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_PRICE IS \'CUST_PRICE contains pricing data for products sold to consumers who shop online.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_PROFESSION:
echo @
echo COMMENT ON TABLE ${GOSALESCT_SCHEMA}.CUST_PROFESSION IS \'CUST_PROFESSION describes jobs or professions of consumers who shop online, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESCT_SCHEMA}.GO_CRDT_METHOD:
echo @
echo COMMENT ON TABLE ${GOSALESCT_SCHEMA}.GO_CRDT_METHOD IS \'GO_CRDT_METHOD describes the credit card or method used by the customer.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESCT_SCHEMA}.GO_SALES_TAX:
echo @
echo COMMENT ON TABLE ${GOSALESCT_SCHEMA}.GO_SALES_TAX IS \'GO_SALES_TAX contains sales tax rates at the country or state level.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESCT_SCHEMA}.PTNR_ACTIVITY:
echo @
echo COMMENT ON TABLE ${GOSALESCT_SCHEMA}.PTNR_ACTIVITY IS \'PTNR_ACTIVITY contains order information collected from the web partners that participate in online sales to consumers.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESCT_SCHEMA}.PTNR_CONTACT:
echo @
echo COMMENT ON TABLE ${GOSALESCT_SCHEMA}.PTNR_CONTACT IS \'PTNR_CONTACT contains address and contact information of the web partners that participate in online sales to consumers.\'
echo @
echo ""
echo --CREATE COMMENTS FOR ${GOSALESHR_SCHEMA} SCHEMA
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.DEPARTMENT_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.DEPARTMENT_LOOKUP IS \'DEPARTMENT_LOOKUP describes department names in the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EMPLOYEE:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EMPLOYEE IS \'EMPLOYEE contains employee information of those working for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EMPLOYEE_EXPENSE_DETAIL:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EMPLOYEE_EXPENSE_DETAIL IS \'EMPLOYEE_EXPENSE_DETAIL contains expense details of employees working for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EMPLOYEE_EXPENSE_PLAN:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EMPLOYEE_EXPENSE_PLAN IS \'EMPLOYEE_EXPENSE_PLAN contains expense budget data for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EMPLOYEE_HISTORY:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EMPLOYEE_HISTORY IS \'EMPLOYEE_HISTORY contains job history of those working for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EMPLOYEE_SUMMARY:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EMPLOYEE_SUMMARY IS \'EMPLOYEE_SUMMARY contains summaries of defined benefits for those working for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EMPLOYEE_SURVEY_RESULTS:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EMPLOYEE_SURVEY_RESULTS IS \'EMPLOYEE_SURVEY_RESULTS contains job satisfaction data of those working for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EMPLOYEE_SURVEY_TARGETS:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EMPLOYEE_SURVEY_TARGETS IS \'EMPLOYEE_SURVEY_TARGETS contains job satisfaction target scores for employees of the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EMPLOYEE_SURVEY_TOPIC:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EMPLOYEE_SURVEY_TOPIC IS \'EMPLOYEE_SURVEY_TOPIC describes employee survey questions for employees of the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EXPENSE_GROUP:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EXPENSE_GROUP IS \'EXPENSE_GROUP describes general categories for expenses incurred by the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EXPENSE_TYPE:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EXPENSE_TYPE IS \'EXPENSE_TYPE describes subcategories for expenses incurred by the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EXPENSE_UNIT:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.EXPENSE_UNIT IS \'EXPENSE_UNIT describes an expense as a quantity or percentage for expenses incurred by the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.GENDER_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.GENDER_LOOKUP IS \'GENDER_LOOKUP describes gender, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.ORGANIZATION:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.ORGANIZATION IS \'ORGANIZATION describes organization names, and an organization structure, in  supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.POSITION_DEPARTMENT:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.POSITION_DEPARTMENT IS \'POSITION_DEPARTMENT contains a department structure, and associated job positions for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.POSITION_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.POSITION_LOOKUP IS \'POSITION_LOOKUP describes job titles for employees in the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.POSITION_SUMMARY:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.POSITION_SUMMARY IS \'POSITION_SUMMARY contains headcount data for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.RANKING:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.RANKING IS \'RANKING describes performance grades of employees who work for the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.RANKING_RESULTS:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.RANKING_RESULTS IS \'RANKING_RESULTS contains the ranking scores of employees who work for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.RECRUITMENT:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.RECRUITMENT IS \'RECRUITMENT contains hiring data for jobs filled by employees of the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.RECRUITMENT_MEDIUM:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.RECRUITMENT_MEDIUM IS \'RECRUITMENT_MEDIUM describes the employment source of employees working for the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.RECRUITMENT_TYPE:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.RECRUITMENT_TYPE IS \'RECRUITMENT_TYPE describes categories of employment sources, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.SATISFACTION_INDEX:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.SATISFACTION_INDEX IS \'SATISFACTION_INDEX describes a satisfaction level for each survey topic in EMPLOYEE_SURVEY_RESULTS, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.SUCCESSION_DETAILS:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.SUCCESSION_DETAILS IS \'SUCCESSION_DETAILS contains the readiness status of employees to move into new management roles in the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.SUCCESSOR_STATUS:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.SUCCESSOR_STATUS IS \'SUCCESSOR_STATUS describes the readiness status of employees moving to new management postions in the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.TERMINATION_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.TERMINATION_LOOKUP IS \'TERMINATION_LOOKUP describes the termination reason or current status of employees that work for the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.TRAINING:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.TRAINING IS \'TRAINING describes the training courses offered to employees of the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESHR_SCHEMA}.TRAINING_DETAILS:
echo @
echo COMMENT ON TABLE ${GOSALESHR_SCHEMA}.TRAINING_DETAILS IS \'TRAINING_DETAILS contains the training data of employees that work for the Great Outdoors Company.\'
echo @
echo ""
echo --CREATE COMMENTS FOR ${GOSALESMR_SCHEMA} SCHEMA
echo echo CREATING COMMENT ON TABLE ${GOSALESMR_SCHEMA}.PRODUCT_SURVEY_RESULTS:
echo @
echo COMMENT ON TABLE ${GOSALESMR_SCHEMA}.PRODUCT_SURVEY_RESULTS IS \'PRODUCT_SURVEY_RESULTS contains consumer satisfaction data for products sold by the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESMR_SCHEMA}.PRODUCT_SURVEY_TARGETS:
echo @
echo COMMENT ON TABLE ${GOSALESMR_SCHEMA}.PRODUCT_SURVEY_TARGETS IS \'PRODUCT_SURVEY_TARGETS contains consumer satisfaction target scores for products sold by the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESMR_SCHEMA}.PRODUCT_SURVEY_TOPIC:
echo @
echo COMMENT ON TABLE ${GOSALESMR_SCHEMA}.PRODUCT_SURVEY_TOPIC IS \'PRODUCT_SURVEY_TOPIC describes the product survey questions in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESMR_SCHEMA}.PROMOTION_BUNDLE_GROUP:
echo @
echo COMMENT ON TABLE ${GOSALESMR_SCHEMA}.PROMOTION_BUNDLE_GROUP IS \'PROMOTION_BUNDLE_GROUP describes bundle names of products packaged together as a sales promotion, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESMR_SCHEMA}.PROMOTION_CAMPAIGN:
echo @
echo COMMENT ON TABLE ${GOSALESMR_SCHEMA}.PROMOTION_CAMPAIGN IS \'PROMOTION_CAMPAIGN describes categories of sales promotions, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESMR_SCHEMA}.PROMOTION_PLAN:
echo @
echo COMMENT ON TABLE ${GOSALESMR_SCHEMA}.PROMOTION_PLAN IS \'PROMOTION_PLAN contains planning data used in sales promotions.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESMR_SCHEMA}.PROMOTIONS:
echo @
echo COMMENT ON TABLE ${GOSALESMR_SCHEMA}.PROMOTIONS IS \'PROMOTIONS describes sales promotion names in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESMR_SCHEMA}.RETAILER_SURVEY_RESULTS:
echo @
echo COMMENT ON TABLE ${GOSALESMR_SCHEMA}.RETAILER_SURVEY_RESULTS IS \'RETAILER_SURVEY_RESULTS contains retailer satisfaction data of companies that buy product from the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESMR_SCHEMA}.RETAILER_SURVEY_TARGETS:
echo @
echo COMMENT ON TABLE ${GOSALESMR_SCHEMA}.RETAILER_SURVEY_TARGETS IS \'RETAILER_SURVEY_TARGETS contains retailer satisfaction target scores for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESMR_SCHEMA}.RETAILER_SURVEY_TOPIC:
echo @
echo COMMENT ON TABLE ${GOSALESMR_SCHEMA}.RETAILER_SURVEY_TOPIC IS \'RETAILER_SURVEY_TOPIC describes the retailer survey questions in supported languages.\'
echo @
echo ""
echo --CREATE COMMENTS FOR ${GOSALESRT_SCHEMA} SCHEMA
echo echo CREATING COMMENT ON TABLE ${GOSALESRT_SCHEMA}.ACTIVITY_STATUS_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESRT_SCHEMA}.ACTIVITY_STATUS_LOOKUP IS \'ACTIVITY_STATUS_LOOKUP describes in supported languages if a retailer is active or not.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESRT_SCHEMA}.RETAILER:
echo @
echo COMMENT ON TABLE ${GOSALESRT_SCHEMA}.RETAILER IS \'RETAILER contains the names of retailers that buy product from the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESRT_SCHEMA}.RETAILER_ACTIVITY:
echo @
echo COMMENT ON TABLE ${GOSALESRT_SCHEMA}.RETAILER_ACTIVITY IS \'RETAILER_ACTIVITY contains monthly sales totals of retailers that buy product from the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESRT_SCHEMA}.RETAILER_CONTACT:
echo @
echo COMMENT ON TABLE ${GOSALESRT_SCHEMA}.RETAILER_CONTACT IS \'RETAILER_CONTACT contains contact information of retailers that buy product from the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESRT_SCHEMA}.RETAILER_SITE:
echo @
echo COMMENT ON TABLE ${GOSALESRT_SCHEMA}.RETAILER_SITE IS \'RETAILER_SITE contains address information of retailers that buy product from the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESRT_SCHEMA}.RETAILER_SITE_MB:
echo @
echo COMMENT ON TABLE ${GOSALESRT_SCHEMA}.RETAILER_SITE_MB IS \'RETAILER_SITE_MB contains address information in localized spelling of retailers that buy product from the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESRT_SCHEMA}.RETAILER_TYPE:
echo @
echo COMMENT ON TABLE ${GOSALESRT_SCHEMA}.RETAILER_TYPE IS \'RETAILER_TYPE describes categories of retailers that buy product from the Great Outdoors Company, in supported languages.\'
echo @
echo ""
echo --CREATE COMMENTS FOR ${GOSALESDW_SCHEMA} SCHEMA
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.DIST_INVENTORY_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.DIST_INVENTORY_FACT IS \'Warehouse table DIST_INVENTORY_FACT contains inventory data for sales made between sales operations and retailers.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.DIST_PRODUCT_FORECAST_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.DIST_PRODUCT_FORECAST_FACT IS \'Warehouse table DIST_PRODUCT_FORECAST_FACT contains product volume forecasts at the sales branch level.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.DIST_RETURN_REASON_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.DIST_RETURN_REASON_DIM IS \'Warehouse table DIST_RETURN_REASON_DIM describes return reasons for products returned by retailers, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.DIST_RETURNED_ITEMS_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.DIST_RETURNED_ITEMS_FACT IS \'Warehouse table DIST_RETURNED_ITEMS_FACT contains details of products returned by retailers.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_EMPLOYEE_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_EMPLOYEE_DIM IS \'Warehouse table EMP_EMPLOYEE_DIM contains the employee hierarchy and job history of those working for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_EXPENSE_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_EXPENSE_FACT IS \'Warehouse table EMP_EXPENSE_FACT contains expense details of employees working for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_EXPENSE_PLAN_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_EXPENSE_PLAN_FACT IS \'Warehouse table EMP_EXPENSE_PLAN_FACT contains expense budget data for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_EXPENSE_TYPE_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_EXPENSE_TYPE_DIM IS \'Warehouse table EMP_EXPENSE_TYPE_DIM describes subcategories for expenses incurred by the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_EXPENSE_UNIT_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_EXPENSE_UNIT_LOOKUP IS \'Warehouse table EMP_EXPENSE_UNIT_LOOKUP describes an expense as a quantity or percentage for expenses incurred by the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_POSITION_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_POSITION_DIM IS \'Warehouse table EMP_POSITION_DIM contains a department structure, and associated job positions for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_POSITION_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_POSITION_LOOKUP IS \'Warehouse table EMP_POSITION_LOOKUP describes job titles and department names for employees in the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_POSITION_SUMMARY_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_POSITION_SUMMARY_FACT IS \'Warehouse table EMP_POSITION_SUMMARY_FACT contains headcount data for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_RANKING_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_RANKING_DIM IS \'Warehouse table EMP_RANKING_DIM describes performance grades of employees who work for the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_RANKING_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_RANKING_FACT IS \'Warehouse table EMP_RANKING_FACT contains the ranking scores of employees who work for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_RECRUITMENT_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_RECRUITMENT_DIM IS \'Warehouse table EMP_RECRUITMENT_DIM describes the employment source of employees working for the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_RECRUITMENT_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_RECRUITMENT_FACT IS \'Warehouse table EMP_RECRUITMENT_FACT contains hiring data for jobs filled by employees of the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_SUCCESSION_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_SUCCESSION_FACT IS \'Warehouse table EMP_SUCCESSION_FACT contains the readiness status of employees to move into new management roles in the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_SUCCESSION_STATUS_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_SUCCESSION_STATUS_DIM IS \'Warehouse table EMP_SUCCESSION_STATUS_DIM describes the readiness status of employees moving to new management postions in the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_SUMMARY_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_SUMMARY_FACT IS \'Warehouse table EMP_SUMMARY_FACT contains summaries of defined benefits for those working for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_SURVEY_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_SURVEY_FACT IS \'Warehouse table EMP_SURVEY_FACT contains job satisfaction data of those working for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_SURVEY_TARG_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_SURVEY_TARG_FACT IS \'Warehouse table EMP_SURVEY_TARG_FACT contains job satisfaction target scores for employees of the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_SURVEY_TOPIC_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_SURVEY_TOPIC_DIM IS \'Warehouse table EMP_SURVEY_TOPIC_DIM describes employee survey questions for employees of the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_TERMINATION_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_TERMINATION_LOOKUP IS \'Warehouse table EMP_TERMINATION_LOOKUP describes the termination reason or current status of employees that work for the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_TRAINING_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_TRAINING_DIM IS \'Warehouse table EMP_TRAINING_DIM describes the training courses offered to employees of the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_TRAINING_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.EMP_TRAINING_FACT IS \'Warehouse table EMP_TRAINING_FACT contains the training data of employees that work for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.FIN_ACCOUNT_CLASS_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.FIN_ACCOUNT_CLASS_LOOKUP IS \'Warehouse table FIN_ACCOUNT_CLASS_LOOKUP describes the type or usage of a financial account, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.FIN_ACCOUNT_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.FIN_ACCOUNT_DIM IS \'Warehouse table FIN_ACCOUNT_DIM contains the financial account hierarchy for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.FIN_ACCOUNT_NAME_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.FIN_ACCOUNT_NAME_LOOKUP IS \'Warehouse table FIN_ACCOUNT_NAME_LOOKUP describes the financial account names relating to the account dimension, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.FIN_ACCOUNT_TYPE_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.FIN_ACCOUNT_TYPE_LOOKUP IS \'Warehouse table FIN_ACCOUNT_TYPE_LOOKUP describes the behaviour of financial accounts when aggregated, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.FIN_FINANCE_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.FIN_FINANCE_FACT IS \'Warehouse table FIN_FINANCE_FACT contains the debit or credit amounts of the financial accounts for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.FIN_SUBM_CURRENCY_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.FIN_SUBM_CURRENCY_LOOKUP IS \'Warehouse table FIN_SUBM_CURRENCY_LOOKUP describes the reporting currency relating to the submission dimension, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.FIN_SUBM_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.FIN_SUBM_DIM IS \'Warehouse table FIN_SUBM_DIM describes the year and names of each set of financial accounts for the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.FIN_SUBM_TYPE_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.FIN_SUBM_TYPE_LOOKUP IS \'Warehouse table FIN_SUBM_TYPE_LOOKUP describes the reporting scenario of the financial statements for the Great Outdoors Company, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.GO_BRANCH_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.GO_BRANCH_DIM IS \'Warehouse table GO_BRANCH_DIM contains address information for corporate offices and distribution centers.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.GO_GENDER_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.GO_GENDER_LOOKUP IS \'Warehouse table GO_GENDER_LOOKUP describes gender, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.GO_ORG_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.GO_ORG_DIM IS \'Warehouse table GO_ORG_DIM contains the organization hiearchy of the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.GO_ORG_NAME_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.GO_ORG_NAME_LOOKUP IS \'Warehouse table GO_ORG_NAME_LOOKUP describes organization names in  supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.GO_REGION_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.GO_REGION_DIM IS \'Warehouse table GO_REGION_DIM describes the region names and countries as sales territories, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.GO_SATISFACTION_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.GO_SATISFACTION_DIM IS \'Warehouse table GO_SATISFACTION_DIM describes a satisfaction level for each survey topic in EMPLOYEE_SURVEY_RESULTS, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.GO_TIME_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.GO_TIME_DIM IS \'Warehouse table GO_TIME_DIM contains a four-year range of date lookup values.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.GO_TIME_QUARTER_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.GO_TIME_QUARTER_LOOKUP IS \'Warehouse table GO_TIME_QUARTER_LOOKUP describes quarterly periods used by the the Great Outdoors Company when making sales and financial reports, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_ACTIVITY_STATUS_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_ACTIVITY_STATUS_DIM IS \'Warehouse table MRK_ACTIVITY_STATUS_DIM describes if a retailer is active or not, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_BUNDLE_GROUP_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_BUNDLE_GROUP_LOOKUP IS \'Warehouse table MRK_BUNDLE_GROUP_LOOKUP describes bundle names of products packaged together as a sales promotion, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_CAMPAIGN_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_CAMPAIGN_LOOKUP IS \'Warehouse table MRK_CAMPAIGN_LOOKUP describes categories of sales promotions, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_PROD_SURVEY_TARG_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_PROD_SURVEY_TARG_FACT IS \'Warehouse table MRK_PROD_SURVEY_TARG_FACT contains consumer satisfaction target scores for products sold by the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_PRODUCT_SURVEY_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_PRODUCT_SURVEY_DIM IS \'Warehouse table MRK_PRODUCT_SURVEY_DIM describes the product survey questions in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_PRODUCT_SURVEY_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_PRODUCT_SURVEY_FACT IS \'Warehouse table MRK_PRODUCT_SURVEY_FACT contains consumer satisfaction data for products sold by the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_PROMOTION_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_PROMOTION_DIM IS \'Warehouse table MRK_PROMOTION_DIM describes sales campaign and promotion names in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_PROMOTION_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_PROMOTION_FACT IS \'Warehouse table MRK_PROMOTION_FACT contains results of sales promotions done by the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_PROMOTION_PLAN_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_PROMOTION_PLAN_FACT IS \'Warehouse table MRK_PROMOTION_PLAN_FACT contains planning data used in sales promotions.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_RTL_SURVEY_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_RTL_SURVEY_DIM IS \'Warehouse table MRK_RTL_SURVEY_DIM describes the retailer survey questions in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_RTL_SURVEY_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_RTL_SURVEY_FACT IS \'Warehouse table MRK_RTL_SURVEY_FACT contains retailer satisfaction data of companies that buy product from the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_RTL_SURVEY_TARG_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.MRK_RTL_SURVEY_TARG_FACT IS \'Warehouse table MRK_RTL_SURVEY_TARG_FACT contains retailer satisfaction target scores for the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_ORDER_METHOD_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_ORDER_METHOD_DIM IS \'Warehouse table SLS_ORDER_METHOD_DIM describes order methods such as fax or web, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_PRODUCT_BRAND_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_PRODUCT_BRAND_LOOKUP IS \'Warehouse table SLS_PRODUCT_BRAND_LOOKUP describes the product brand names in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_PRODUCT_COLOR_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_PRODUCT_COLOR_LOOKUP IS \'Warehouse table SLS_PRODUCT_COLOR_LOOKUP describes the product colors in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_PRODUCT_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_PRODUCT_DIM IS \'Warehouse table SLS_PRODUCT_DIM contains the product hiearchy of line, type, and product, and an alternate hierarchy of product brand and product.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_PRODUCT_LINE_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_PRODUCT_LINE_LOOKUP IS \'Warehouse table SLS_PRODUCT_LINE_LOOKUP describes general product categories in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_PRODUCT_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_PRODUCT_LOOKUP IS \'Warehouse table SLS_PRODUCT_LOOKUP describribes product names and descriptions in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_PRODUCT_SIZE_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_PRODUCT_SIZE_LOOKUP IS \'Warehouse table SLS_PRODUCT_SIZE_LOOKUP describes product sizes in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_PRODUCT_TYPE_LOOKUP:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_PRODUCT_TYPE_LOOKUP IS \'Warehouse table SLS_PRODUCT_TYPE_LOOKUP describes subcategories under product line, in supported languages.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_RTL_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_RTL_DIM IS \'Warehouse table SLS_RTL_DIM describes the retailer hierarchy, including the names and addresses of companies that purchase wholesale from the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_SALES_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_SALES_FACT IS \'Warehouse table SLS_SALES_FACT contains transaction and order information on sales made to retailers that buy wholesale from the Great Outdoors Company.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_SALES_ORDER_DIM:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_SALES_ORDER_DIM IS \'Warehouse table SLS_SALES_ORDER_DIM contains dimension-type order information correlating to sales fact data.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_SALES_TARG_FACT:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.SLS_SALES_TARG_FACT IS \'Warehouse table SLS_SALES_TARG_FACT contains sales targets for employees of the Great Outdoors Company who sell to retailers.\'
echo @
echo echo CREATING COMMENT ON TABLE ${GOSALESDW_SCHEMA}.xgorev:
echo @
echo COMMENT ON TABLE ${GOSALESDW_SCHEMA}.xgorev IS \'Warehouse table xgorev contains release and revision information on the tables and data belonging to the transaction schemas: gosales, gosalesct, gosaleshr, gosalesmr, gosalesrt.\'
echo @
echo ""


