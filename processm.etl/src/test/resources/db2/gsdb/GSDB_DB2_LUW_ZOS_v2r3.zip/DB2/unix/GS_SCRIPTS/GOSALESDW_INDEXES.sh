#!/bin/sh
########################################################################
#   5724-E34
#   (c) Copyright IBM Corporation 2008, 2009.
#   All rights reserved.
#
#   The source code for this program is not published or otherwise
#   divested of its trade secrets, irrespective of what has been
#   deposited with the U.S. Copyright Office.
########################################################################

echo --CREATE INDEXES FOR GOSALESDW SCHEMA
echo  echo CREATING INDEX ON TABLE ${GOSALESDW_SCHEMA}.GO_REGION_DIM:
echo @
echo -- commented out for warehouse tutorial
echo -- CREATE UNIQUE  INDEX IX2_2081442489 ON ${GOSALESDW_SCHEMA}.GO_REGION_DIM \(COUNTRY_CODE \)
echo @
echo  echo CREATING INDEX ON TABLE ${GOSALESDW_SCHEMA}.SLS_RTL_DIM:
echo @
echo -- commented out for warehouse tutorial
echo -- CREATE UNIQUE  INDEX IX5_1976394110 ON ${GOSALESDW_SCHEMA}.SLS_RTL_DIM \(RETAILER_KEY ,
echo -- RETAILER_SITE_KEY \)
echo @
echo

