#!/bin/sh
##################################################################
#   5724-E34
#   (c) Copyright IBM Corporation 2008, 2009.
#   All rights reserved.
#
#   The source code for this program is not published or otherwise
#   divested of its trade secrets, irrespective of what has been
#   deposited with the U.S. Copyright Office.
##################################################################

echo -- DROP STORED PROCEDURES AND VERIFY TABLE > GOSALES_DROP.SQL 
echo DROP PROCEDURE ${GOSALES_SCHEMA}.VERIFY_DATA  >> GOSALES_DROP.SQL 
echo @ >> GOSALES_DROP.SQL 
echo DROP TABLE ${GOSALES_SCHEMA}.VERIFY  >> GOSALES_DROP.SQL 
echo @ >> GOSALES_DROP.SQL 
echo DROP PROCEDURE ${GOSALES_SCHEMA}.ASSIGNSTAFF  >> GOSALES_DROP.SQL 
echo @ >> GOSALES_DROP.SQL 
echo  >> GOSALES_DROP.SQL 

# DROP CONSTRAINTS
if [ -f GOSALES_DROP_CONSTRAINTS.sh ] ; then . ./GOSALES_DROP_CONSTRAINTS.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESHR_DROP_CONSTRAINTS.sh ] ; then . ./GOSALESHR_DROP_CONSTRAINTS.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESMR_DROP_CONSTRAINTS.sh ] ; then . ./GOSALESMR_DROP_CONSTRAINTS.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESRT_DROP_CONSTRAINTS.sh ] ; then . ./GOSALESRT_DROP_CONSTRAINTS.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESCT_DROP_CONSTRAINTS.sh ] ; then . ./GOSALESCT_DROP_CONSTRAINTS.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESDW_DROP_CONSTRAINTS.sh ] ; then . ./GOSALESDW_DROP_CONSTRAINTS.sh >> GOSALES_DROP.SQL ; fi;

# DROP VIEWS
if [ -f GOSALES_DROP_VIEWS.sh ] ; then . ./GOSALES_DROP_VIEWS.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESHR_DROP_VIEWS.sh ] ; then . ./GOSALESHR_DROP_VIEWS.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESMR_DROP_VIEWS.sh ] ; then . ./GOSALESMR_DROP_VIEWS.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESRT_DROP_VIEWS.sh ] ; then . ./GOSALESRT_DROP_VIEWS.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESCT_DROP_VIEWS.sh ] ; then . ./GOSALESCT_DROP_VIEWS.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESDW_DROP_VIEWS.sh ] ; then . ./GOSALESDW_DROP_VIEWS.sh >> GOSALES_DROP.SQL ; fi;

# DROP PK
if [ -f GOSALES_DROP_PK.sh ] ; then . ./GOSALES_DROP_PK.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESHR_DROP_PK.sh ] ; then . ./GOSALESHR_DROP_PK.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESMR_DROP_PK.sh ] ; then . ./GOSALESMR_DROP_PK.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESRT_DROP_PK.sh ] ; then . ./GOSALESRT_DROP_PK.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESCT_DROP_PK.sh ] ; then . ./GOSALESCT_DROP_PK.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESDW_DROP_PK.sh ] ; then . ./GOSALESDW_DROP_PK.sh >> GOSALES_DROP.SQL ; fi;

# DROP INDEXES
if [ -f GOSALES_DROP_INDEXES.sh ] ; then . ./GOSALES_DROP_INDEXES.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESHR_DROP_INDEXES.sh ] ; then . ./GOSALESHR_DROP_INDEXES.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESMR_DROP_INDEXES.sh ] ; then . ./GOSALESMR_DROP_INDEXES.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESRT_DROP_INDEXES.sh ] ; then . ./GOSALESRT_DROP_INDEXES.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESCT_DROP_INDEXES.sh ] ; then . ./GOSALESCT_DROP_INDEXES.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESDW_DROP_INDEXES.sh ] ; then . ./GOSALESDW_DROP_INDEXES.sh >> GOSALES_DROP.SQL ; fi;

# DROP TABLES
if [ -f GOSALES_DROP_TABLES.sh ] ; then . ./GOSALES_DROP_TABLES.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESHR_DROP_TABLES.sh ] ; then . ./GOSALESHR_DROP_TABLES.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESMR_DROP_TABLES.sh ] ; then . ./GOSALESMR_DROP_TABLES.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESRT_DROP_TABLES.sh ] ; then . ./GOSALESRT_DROP_TABLES.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESCT_DROP_TABLES.sh ] ; then . ./GOSALESCT_DROP_TABLES.sh >> GOSALES_DROP.SQL ; fi;
if [ -f GOSALESDW_DROP_TABLES.sh ] ; then . ./GOSALESDW_DROP_TABLES.sh >> GOSALES_DROP.SQL ; fi;

