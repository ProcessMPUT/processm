#!/bin/sh
########################################################################
#   5724-E34
#   (c) Copyright IBM Corporation 2008, 2009.
#   All rights reserved.
#
#   The source code for this program is not published or otherwise
#   divested of its trade secrets, irrespective of what has been
#   deposited with the U.S. Copyright Office.
########################################################################

echo --CREATE AUXILIARY TABLES FOR GOSALESCT SCHEMA
echo echo CREATING AUXILIARY TABLE ${GOSALESCT_SCHEMA}.CUST_CUSTOMER_AUX:
echo @
echo CREATE AUXILIARY TABLE ${GOSALESCT_SCHEMA}.CUST_CUSTOMER_AUX IN ${GOSALES_DB}.${GOSALES_LOB_TS}
echo STORES ${GOSALESCT_SCHEMA}.CUST_CUSTOMER
echo COLUMN CUST_INFO
echo @
echo echo CREATING UNIQUE INDEX FOR AUXILIARY TABLE ${GOSALESCT_SCHEMA}.CUST_CUSTOMER_AUX:
echo @
echo CREATE UNIQUE INDEX ${GOSALESCT_SCHEMA}.IX_CUST_CUSTOMER_AUX ON ${GOSALESCT_SCHEMA}.CUST_CUSTOMER_AUX
echo @

echo

