#!/bin/sh
########################################################################
#   5724-E34
#   (c) Copyright IBM Corporation 2008, 2009.
#   All rights reserved.
#
#   The source code for this program is not published or otherwise
#   divested of its trade secrets, irrespective of what has been
#   deposited with the U.S. Copyright Office.
########################################################################


echo --DROP VIEWS FOR GOSALESDW SCHEMA
echo echo DROPPING VIEW ${GOSALESDW_SCHEMA}.VIEW_ACCOUNT_DIM:
echo @
echo DROP VIEW ${GOSALESDW_SCHEMA}.VIEW_ACCOUNT_DIM
echo @
echo echo DROPPING VIEW ${GOSALESDW_SCHEMA}.VIEW_BALANCED_ORG_DIM:
echo @
echo DROP VIEW ${GOSALESDW_SCHEMA}.VIEW_BALANCED_ORG_DIM
echo @
echo echo DROPPING VIEW ${GOSALESDW_SCHEMA}.VIEW_ORG_DIM:
echo @
echo DROP VIEW ${GOSALESDW_SCHEMA}.VIEW_ORG_DIM
echo @
echo echo DROPPING VIEW ${GOSALESDW_SCHEMA}.VIEW_PRODUCT_NAME:
echo @
echo DROP VIEW ${GOSALESDW_SCHEMA}.VIEW_PRODUCT_NAME
echo @
echo echo DROPPING VIEW ${GOSALESDW_SCHEMA}.VIEW_STATEMENT_FACT:
echo @
echo DROP VIEW ${GOSALESDW_SCHEMA}.VIEW_STATEMENT_FACT
echo @
echo echo DROPPING VIEW ${GOSALESDW_SCHEMA}.VIEW_SUBMISSION_DIM:
echo @
echo DROP VIEW ${GOSALESDW_SCHEMA}.VIEW_SUBMISSION_DIM
echo @
echo echo DROPPING VIEW ${GOSALESDW_SCHEMA}.VIEW_TIME_MONTH_DIM:
echo @
echo DROP VIEW ${GOSALESDW_SCHEMA}.VIEW_TIME_MONTH_DIM
echo @
echo echo DROPPING VIEW ${GOSALESDW_SCHEMA}.VW_ACTIVE_EMPLOYEE_DIM:
echo @
echo DROP VIEW ${GOSALESDW_SCHEMA}.VW_ACTIVE_EMPLOYEE_DIM
echo @
echo 

