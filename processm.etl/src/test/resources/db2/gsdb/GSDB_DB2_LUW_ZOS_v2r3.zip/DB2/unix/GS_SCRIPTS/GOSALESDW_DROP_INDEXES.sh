#!/bin/sh
########################################################################
#   5724-E34
#   (c) Copyright IBM Corporation 2008, 2009.
#   All rights reserved.
#
#   The source code for this program is not published or otherwise
#   divested of its trade secrets, irrespective of what has been
#   deposited with the U.S. Copyright Office.
########################################################################

echo --DROP INDEXES FOR GOSALESDW SCHEMA
echo  echo DROPPING INDEX ON TABLE ${GOSALESDW_SCHEMA}.GO_REGION_DIM:
echo @
echo -- Commented out for the warehouse tutorial
echo -- DROP INDEX IX2_2081442489
echo @
echo  echo DROPPING INDEX ON TABLE ${GOSALESDW_SCHEMA}.SLS_RTL_DIM:
echo @
echo -- Commented out for the warehouse tutorial
echo -- DROP INDEX IX5_1976394110
echo @
echo

