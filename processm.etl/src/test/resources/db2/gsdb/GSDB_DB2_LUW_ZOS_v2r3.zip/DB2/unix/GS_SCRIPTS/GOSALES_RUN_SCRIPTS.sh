##################################################################
#   5724-E34
#   (c) Copyright IBM Corporation 2008, 2009.
#   All rights reserved.
#
#   The source code for this program is not published or otherwise
#   divested of its trade secrets, irrespective of what has been
#   deposited with the U.S. Copyright Office.
##################################################################
#  File: GOSALES_RUN_SCRIPTS.sh
#
#  Description:
#     This script must be started from the setupGSDB.sh
#     script.
#     This file performs one or more of the following functions :
#       - ATTACH to the NODENAME
#       - Creates the database, bufferpool and tablespaces
#       - Connects to the database
#       - Executes the SQL scripts that were generated in the
#         RUN_GOSALES_IMPORT.bat file to create the tables, indexes,
#         foreign keys, views, privileges and stored procedures that
#         make up the GOSALES database
#
##################################################################

terminateRunScripts()
{
   db2 connect reset > /dev/null  2>&1
   db2 terminate  > /dev/null  2>&1
}


CreateTableError( )
{
   echo Error creating tables for schema $1
   echo Error creating tables for schema $1 >> "${GOSALES_ERROR_LOG}"
   echo  - see log file "$1_TABLES.LOG" >> "${GOSALES_ERROR_LOG}"
   terminateRunScripts

}

CreateError( )
{

   case $2 in
     index)
        GOSALES_OBJ_TYPE="creating indexes"
	 			GOSALES_LOG_NAME="$1_INDEXES.LOG";;
     pk)
        GOSALES_OBJ_TYPE="creating primary keys"
	 			GOSALES_LOG_NAME="$1_PK.LOG";;
     constraint)
        GOSALES_OBJ_TYPE="creating constraints"
	 			GOSALES_LOG_NAME="$1_CONSTRAINTS.LOG";;
     view)
        GOSALES_OBJ_TYPE="creating views"
	 			GOSALES_LOG_NAME="$1_VIEWS.LOG";;
     grant)
        GOSALES_OBJ_TYPE="granting privileges"
	 			GOSALES_LOG_NAME="$1_GRANTS.LOG";;
     sp)
        GOSALES_OBJ_TYPE="creating stored procedures"
	 			GOSALES_LOG_NAME="$1_SP.LOG";;
     runstats)
        GOSALES_OBJ_TYPE="updating statistics"
	 			GOSALES_LOG_NAME="$1_SP.LOG";;
  esac

   echo Error ${GOSALES_OBJ_TYPE} for schema $1
   echo Error ${GOSALES_OBJ_TYPE} for schema $1 >> "${GOSALES_ERROR_LOG}"
   echo - see log file ${GOSALES_LOG_NAME} >> "${GOSALES_ERROR_LOG}"
}

VerifyTableRowCounts( )
{
   echo Verifying row counts
   if [ -f GOSALES_VERIFY.SQL ] ; then
      db2 -td@ -xf GOSALES_VERIFY.SQL > "${GOSALES_LOG_DIR}GOSALES_VERIFY.LOG"

      # count the lines in the log file that are not empty or do not
      # start with tab(s) or space(s) followed by a 0 
      if [ "${GOSALES_OS}" = "SunOS" ] ; then
           errorCnt=`egrep -c -v  "^$|^[	 ]*0" "${GOSALES_LOG_DIR}GOSALES_VERIFY.LOG"`
      else
           errorCnt=`grep -c -v -E "^$|^[	 ]*0" "${GOSALES_LOG_DIR}GOSALES_VERIFY.LOG"`
     fi

      echo Errors: ${errorCnt}
      if [ "${errorCnt}" = "0" ] ; then 
            echo "Table row count validation successful."
      else
            echo "Table row count validation failed."
            echo "Table row count validation failed." >> "${GOSALES_ERROR_LOG}"
            echo "- see log file GOSALES_VERIFY.LOG" >> "${GOSALES_ERROR_LOG}"

      fi
   fi
}

#########################################################################
# Verify the script was called correctly
#########################################################################

if [ "${GOSALES_START}" != "1" ] ; then
   echo This script must be called from setupGSDB.sh - Quitting
   exit 1
fi

##################################################################
# Create the database
# - needs to attach
##################################################################
echo "Starting GOSALES_RUN_SCRIPTS"

db2 connect reset > /dev/null  2>&1

if [ "${GOSALES_CREATEDB}" = "Y" -a "${GOSALES_ONLY_VERIFY}" = "N" ] ; then
   # Attach if the NODE is provided

   if [ "${GOSALES_NODENAME}" != "" ] ; then
      if [ "${GOSALES_ADMIN_USERNAME}" = "" ] ; then
         # Attempt to attach without a userid
         db2 attach to ${GOSALES_NODENAME}
      else
         if [ "${GOSALES_ADMIN_PASSWORD}" != "" ] ; then
           db2 attach to ${GOSALES_NODENAME} user ${GOSALES_ADMIN_USERNAME} using ${GOSALES_ADMIN_PASSWORD}
         else
            # Prompt the admin user for the password
            db2 attach to ${GOSALES_NODENAME} user ${GOSALES_ADMIN_USERNAME}
         fi
      fi

      # If an error occured while attaching to the node, then report the
      # error and exit.
      if [ $? -ne 0 ] ; then
         echo Attach to node ${GOSALES_NODENAME} failed.
         echo Attach to node ${GOSALES_NODENAME} failed. >> "${GOSALES_LOG_DIR}GOSALES_CREATE_DB.LOG"
         return 1;
      else
         echo Attach to node ${GOSALES_NODENAME} was successful. >> "${GOSALES_LOG_DIR}GOSALES_CREATE_DB.LOG"
      fi
   fi


   echo Creating database
   ##################################################################
   # Drop the existing database in the shell since we don�t worry
   # about the error of the result
   ##################################################################
   db2 drop database ${GOSALES_INST} >> "${GOSALES_LOG_DIR}GOSALES_CREATE_DB.LOG"

   ##################################################################
   # Run the script to create the database
   ##################################################################
   db2 -td@ -f GOSALES_CREATE_DB.SQL >> "${GOSALES_LOG_DIR}GOSALES_CREATE_DB.LOG"

   if [ $? != 0 ] ; then
      echo Error creating the database ${GOSALES_INST}.
      cat < "${GOSALES_LOG_DIR}GOSALES_CREATE_DB.LOG"
      terminateRunScripts;
      return 1;
   fi

   # Grant DBADM access to the
   #
   # db2 connect to $GOSALES_INST
   #
   if [ "${GOSALES_ADMIN_USERNAME}" != "" ]; then
        db2 connect to $GOSALES_INST >> "${GOSALES_LOG_DIR}GOSALES_CREATE_DB.LOG"
        db2 grant DBADM on database to USER ${GOSALES_ADMIN_USERNAME} >> "${GOSALES_LOG_DIR}GOSALES_CREATE_DB.LOG"
        if [ $? != 0 ] ; then echo Error granting DBADM permission to ${GOSALES_ADMIN_USERNAME}; fi;
   fi
fi

##################################################################
# Connect to the database
##################################################################

db2 connect reset > /dev/null  2>&1

echo Connecting to ${GOSALES_INST}

if [ "${GOSALES_ADMIN_USERNAME}" = "" ] ; then
   # Attempt to connect without a userid
   db2 connect to ${GOSALES_INST}
else
   if [ "${GOSALES_ADMIN_PASSWORD}" != "" ] ; then
      db2 connect to ${GOSALES_INST} user ${GOSALES_ADMIN_USERNAME} using ${GOSALES_ADMIN_PASSWORD}
   else
      # Prompt the admin user for the password
      db2 connect to ${GOSALES_INST} user ${GOSALES_ADMIN_USERNAME}
   fi
fi


if [ $? != 0 ] ; then
   echo Error connecting to the database ${GOSALES_INST}.
   terminateRunScripts;
   return 1;
fi

if [ ${GOSALES_ONLY_VERIFY} = "Y" ] ; then
   VerifyTableRowCounts
   return 0;
fi

if [ ${GOSALES_ONLY_COMMENTS} = "Y" ] ; then
   #AddComments
   db2 -td@ -f GOSALES_ADD_COMMENTS.SQL > "${GOSALES_LOG_DIR}GOSALES_ADD_COMMENTS.LOG"
   if [ $? != 0 ] ; then echo "Error adding table comments" >> "${GOSALES_ERROR_LOG}"; fi;
   terminateRunScripts;
   return 0;
fi

##################################################################
# Create the bufferpool and tablespace if required
##################################################################

if [ "${GOSALES_CREATE_BP_AND_TS}" = "Y" ] ; then
   echo Creating bufferpool and tablespace.
   db2 -td@ -f GOSALES_CREATE_TS.SQL > "${GOSALES_LOG_DIR}GOSALES_CREATE_TS.LOG"

   if [ $? != 0 ] ; then
      echo Error creating bufferpool or tablespace.
      cat < "${GOSALES_LOG_DIR}GOSALES_CREATE_TS.LOG"
      terminateRunScripts;
      return 1;
   fi
fi


##################################################################
# Drop the existing tables, views and stored procedures
# Ignore any errors
##################################################################
if [ "${GOSALES_CLEAN}" = "Y" ] ; then
   echo Dropping existing database objects
   db2 -td@ -vf GOSALES_DROP.SQL > "${GOSALES_LOG_DIR}GOSALES_DROP.LOG"
   db2 -td@ -vf WAREHOUSE_TUTORIAL_CLEANUP.SQL >> "${GOSALES_LOG_DIR}GOSALES_DROP.LOG"
fi


##################################################################
# Create the tables
##################################################################
echo Creating tables.

if [ -f GOSALES_TABLES.SQL ] ; then
   db2 -td@ -f GOSALES_TABLES.SQL > "${GOSALES_LOG_DIR}GOSALES_TABLES.LOG"
   if [ $? != 0 ] ; then CreateTableError GOSALES; return 1; fi;
fi

if [ -f GOSALESHR_TABLES.SQL ] ; then
   db2 -td@ -f GOSALESHR_TABLES.SQL > "${GOSALES_LOG_DIR}GOSALESHR_TABLES.LOG"
   if [ $? != 0 ] ; then CreateTableError GOSALESHR; return 1; fi;
fi

if [ -f GOSALESMR_TABLES.SQL ] ; then
   db2 -td@ -f GOSALESMR_TABLES.SQL > "${GOSALES_LOG_DIR}GOSALESMR_TABLES.LOG"
   if [ $? != 0 ] ; then CreateTableError GOSALESMR; return 1; fi;
fi

if [ -f GOSALESRT_TABLES.SQL ] ; then
   db2 -td@ -f GOSALESRT_TABLES.SQL > "${GOSALES_LOG_DIR}GOSALESRT_TABLES.LOG"
   if [ $? != 0 ] ; then CreateTableError GOSALESRT; return 1; fi;
fi

if [ -f GOSALESCT_TABLES.SQL ] ; then
   db2 -td@ -f GOSALESCT_TABLES.SQL > "${GOSALES_LOG_DIR}GOSALESCT_TABLES.LOG"
   if [ $? != 0 ] ; then CreateTableError GOSALESCT; return 1; fi;
fi

if [ -f GOSALESDW_TABLES.SQL ] ; then
   db2 -td@ -f GOSALESDW_TABLES.SQL > "${GOSALES_LOG_DIR}GOSALESDW_TABLES.LOG"
   if [ $? != 0 ] ; then CreateTableError GOSALESDW; return 1; fi;
fi

if [ "${GOSALES_SKIP_IMPORT}" = "N" ] ; then
	displayTime=`date`
	echo
	echo Load started at ${displayTime} >> "${GOSALES_LOG_DIR}GOSALES_LOAD.LOG"
	echo Loading data.
	##################################################################
	# Load the data 
	##################################################################
	db2 -td@ -f GOSALES_LOAD.SQL > "${GOSALES_LOG_DIR}GOSALES_LOAD.LOG"
	
	if [ $? != 0 ] ; then
   		cat < "${GOSALES_LOG_DIR}GOSALES_LOAD.LOG"
   		displayTime=`date`
   		echo Error loading data
   		echo Load ended at ${displayTime} >> "${GOSALES_LOG_DIR}GOSALES_LOAD.LOG"
   		echo Error loading data >> "${GOSALES_ERROR_LOG}"
      echo - see log file "GOSALES_LOAD.LOG" >> "${GOSALES_ERROR_LOG}"

   		terminateRunScripts;
   		return 1;
	fi
	if [ "${GOSALES_XML_SUPPORT}" = "N" ]; then
		db2 -td@ -vf GOSALESCT_PTNR_ACTIVITY.SQL >> "${GOSALES_LOG_DIR}GOSALES_LOAD.LOG"
	fi
	
	if [ $? != 0 ] ; then
   		cat < "${GOSALES_LOG_DIR}GOSALES_LOAD.LOG"
   		displayTime=`date`
   		echo Error loading data
   		echo Load ended at ${displayTime} >> "${GOSALES_LOG_DIR}GOSALES_LOAD.LOG"
   		echo Error loading data >> "${GOSALES_ERROR_LOG}"
      echo - see log file "GOSALES_LOAD.LOG" >> "${GOSALES_ERROR_LOG}"

   		terminateRunScripts;
   		return 1;
	fi
	



	displayTime=`date`
	echo Load ended at ${displayTime} >> "${GOSALES_LOG_DIR}GOSALES_LOAD.LOG"
fi

##################################################################
# Create
# primary keys
##################################################################
echo Creating Primary Keys.
if [ -f GOSALES_PK.SQL ] ; then
   db2 -td@ -f GOSALES_PK.SQL > "${GOSALES_LOG_DIR}GOSALES_PK.LOG"
   if [ $? != 0 ] ; then CreateError GOSALES pk; fi;
fi
if [ -f GOSALESHR_PK.SQL ] ; then
   db2 -td@ -f GOSALESHR_PK.SQL > "${GOSALES_LOG_DIR}GOSALESHR_PK.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESHR pk; fi;
fi
if [ -f GOSALESMR_PK.SQL ] ; then
   db2 -td@ -f GOSALESMR_PK.SQL > "${GOSALES_LOG_DIR}GOSALESMR_PK.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESMR pk; fi;
fi
if [ -f GOSALESRT_PK.SQL ] ; then
   db2 -td@ -f GOSALESRT_PK.SQL > "${GOSALES_LOG_DIR}GOSALESRT_PK.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESRT pk; fi;
fi
if [ -f GOSALESCT_PK.SQL ] ; then
   db2 -td@ -f GOSALESCT_PK.SQL > "${GOSALES_LOG_DIR}GOSALESCT_PK.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESCT pk; fi;
fi
if [ -f GOSALESDW_PK.SQL ] ; then
   db2 -td@ -f GOSALESDW_PK.SQL > "${GOSALES_LOG_DIR}GOSALESDW_PK.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESDW pk; fi;
fi

##################################################################
# Create indexes
##################################################################
echo Creating indexes.
if [ -f GOSALES_INDEXES.SQL ] ; then
   db2 -td@ -f GOSALES_INDEXES.SQL > "${GOSALES_LOG_DIR}GOSALES_INDEXES.LOG"
   if [ $? != 0 ] ; then CreateError GOSALES index; fi;
fi
if [ -f GOSALESHR_INDEXES.SQL ] ; then
   db2 -td@ -f GOSALESHR_INDEXES.SQL > "${GOSALES_LOG_DIR}GOSALESHR_INDEXES.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESHR index; fi;
fi
if [ -f GOSALESMR_INDEXES.SQL ] ; then
   db2 -td@ -f GOSALESMR_INDEXES.SQL > "${GOSALES_LOG_DIR}GOSALESMR_INDEXES.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESMR index; fi;
fi
if [ -f GOSALESRT_INDEXES.SQL ] ; then
   db2 -td@ -f GOSALESRT_INDEXES.SQL > "${GOSALES_LOG_DIR}GOSALESRT_INDEXES.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESRT index; fi;
fi
if [ -f GOSALESCT_INDEXES.SQL ] ; then
   db2 -td@ -f GOSALESCT_INDEXES.SQL > "${GOSALES_LOG_DIR}GOSALESCT_INDEXES.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESCT index; fi;
fi
if [ -f GOSALESDW_INDEXES.SQL ] ; then
   db2 -td@ -f GOSALESDW_INDEXES.SQL > "${GOSALES_LOG_DIR}GOSALESDW_INDEXES.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESDW index; fi;
fi

##################################################################
# Create constraints
##################################################################
echo Creating constraints.
if [ -f GOSALES_CONSTRAINTS.SQL ] ; then
   db2 -td@ -f GOSALES_CONSTRAINTS.SQL > "${GOSALES_LOG_DIR}GOSALES_CONSTRAINTS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALES constraint; fi;
fi
if [ -f GOSALESHR_CONSTRAINTS.SQL ] ;
   then db2 -td@ -f GOSALESHR_CONSTRAINTS.SQL > "${GOSALES_LOG_DIR}GOSALESHR_CONSTRAINTS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESHR constraint; fi;
fi
if [ -f GOSALESMR_CONSTRAINTS.SQL ] ; then
   db2 -td@ -f GOSALESMR_CONSTRAINTS.SQL > "${GOSALES_LOG_DIR}GOSALESMR_CONSTRAINTS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESMR constraint; fi;
fi
if [ -f GOSALESRT_CONSTRAINTS.SQL ] ; then
   db2 -td@ -f GOSALESRT_CONSTRAINTS.SQL > "${GOSALES_LOG_DIR}GOSALESRT_CONSTRAINTS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESRT constraint; fi;
fi
if [ -f GOSALESCT_CONSTRAINTS.SQL ] ; then
   db2 -td@ -f GOSALESCT_CONSTRAINTS.SQL > "${GOSALES_LOG_DIR}GOSALESCT_CONSTRAINTS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESCT constraint; fi;
fi
if [ -f GOSALESDW_CONSTRAINTS.SQL ] ; then
   db2 -td@ -f GOSALESDW_CONSTRAINTS.SQL > "${GOSALES_LOG_DIR}GOSALESDW_CONSTRAINTS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESDW constraint; fi;
fi

##################################################################
# Create stored procedures
##################################################################
echo Creating stored procedures
if [ -f GOSALES_SP.SQL ] ; then
   db2 -td@ -f GOSALES_SP.SQL > "${GOSALES_LOG_DIR}GOSALES_SP.LOG"
   if [ $? != 0 ] ; then CreateError GOSALES sp; fi;
fi
if [ -f GOSALESHR_SP.SQL ] ; then
   db2 -td@ -f GOSALESHR_SP.SQL > "${GOSALES_LOG_DIR}GOSALESHR_SP.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESHR sp; fi;
fi
if [ -f GOSALESMR_SP.SQL ] ; then
   db2 -td@ -f GOSALESMR_SP.SQL > "${GOSALES_LOG_DIR}GOSALESMR_SP.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESMR sp; fi;
fi
if [ -f GOSALESRT_SP.SQL ] ; then
   db2 -td@ -f GOSALESRT_SP.SQL > "${GOSALES_LOG_DIR}GOSALESRT_SP.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESRT sp; fi;
fi
if [ -f GOSALESCT_SP.SQL ] ; then
   db2 -td@ -f GOSALESCT_SP.SQL > "${GOSALES_LOG_DIR}GOSALESCT_SP.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESCT sp; fi;
fi
if [ -f GOSALESDW_SP.SQL ] ; then
   db2 -td@ -f GOSALESDW_SP.SQL > "${GOSALES_LOG_DIR}GOSALESDW_SP.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESDW sp; fi;
fi

##################################################################
# Create views
##################################################################
echo Creating views
if [ -f GOSALES_VIEWS.SQL ] ; then
   db2 -td@ -f GOSALES_VIEWS.SQL > "${GOSALES_LOG_DIR}GOSALES_VIEWS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALES view; fi;
fi
if [ -f GOSALESHR_VIEWS.SQL ] ; then
   db2 -td@ -f GOSALESHR_VIEWS.SQL > "${GOSALES_LOG_DIR}GOSALESHR_VIEWS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESHR view; fi;
fi
if [ -f GOSALESMR_VIEWS.SQL ] ; then
   db2 -td@ -f GOSALESMR_VIEWS.SQL > "${GOSALES_LOG_DIR}GOSALESMR_VIEWS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESMR view; fi;
fi
if [ -f GOSALESRT_VIEWS.SQL ] ; then
   db2 -td@ -f GOSALESRT_VIEWS.SQL > "${GOSALES_LOG_DIR}GOSALESRT_VIEWS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESRT view; fi;
fi
if [ -f GOSALESCT_VIEWS.SQL ] ; then
   db2 -td@ -f GOSALESCT_VIEWS.SQL > "${GOSALES_LOG_DIR}GOSALESCT_VIEWS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESCT view; fi;
fi
if [ -f GOSALESDW_VIEWS.SQL ] ; then
   db2 -td@ -f GOSALESDW_VIEWS.SQL > "${GOSALES_LDWOG_DIR}GOSALESDW_VIEWS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALES view; fi;
fi



##################################################################
# Create grants
##################################################################
echo Granting Permissions.
if [ -f GOSALES_GRANTS.SQL ] ; then
   db2 -td@ -f GOSALES_GRANTS.SQL > "${GOSALES_LOG_DIR}GOSALES_GRANTS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALES grant; fi;
fi
if [ -f GOSALESHR_GRANTS.SQL ] ; then
   db2 -td@ -f GOSALESHR_GRANTS.SQL > "${GOSALES_LOG_DIR}GOSALESHR_GRANTS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESHR grant; fi;
fi
if [ -f GOSALESMR_GRANTS.SQL ] ; then
   db2 -td@ -f GOSALESMR_GRANTS.SQL > "${GOSALES_LOG_DIR}GOSALESMR_GRANTS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESMR grant; fi;
fi
if [ -f GOSALESRT_GRANTS.SQL ] ; then
   db2 -td@ -f GOSALESRT_GRANTS.SQL > "${GOSALES_LOG_DIR}GOSALESRT_GRANTS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESRT grant; fi;
fi
if [ -f GOSALESCT_GRANTS.SQL ] ; then
   db2 -td@ -f GOSALESCT_GRANTS.SQL > "${GOSALES_LOG_DIR}GOSALESCT_GRANTS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESCT grant; fi;
fi
if [ -f GOSALESDW_GRANTS.SQL ] ; then
   db2 -td@ -f GOSALESDW_GRANTS.SQL > "${GOSALES_LOG_DIR}GOSALESDW_GRANTS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESDW grant; fi;
fi


##################################################################
# Update statistics
##################################################################
echo Updating statistics
if [ -f GOSALES_RUNSTATS.SQL ] ; then
   db2 -td@ -f GOSALES_RUNSTATS.SQL > "${GOSALES_LOG_DIR}GOSALES_RUNSTATS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALES runstats; fi;
fi
if [ -f GOSALESHR_RUNSTATS.SQL ] ; then
   db2 -td@ -f GOSALESHR_RUNSTATS.SQL > "${GOSALES_LOG_DIR}GOSALESHR_RUNSTATS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESHR runstats; fi;
fi
if [ -f GOSALESMR_RUNSTATS.SQL ] ; then
   db2 -td@ -f GOSALESMR_RUNSTATS.SQL > "${GOSALES_LOG_DIR}GOSALESMR_RUNSTATS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESMR runstats; fi;
fi
if [ -f GOSALESRT_RUNSTATS.SQL ] ; then
   db2 -td@ -f GOSALESRT_RUNSTATS.SQL > "${GOSALES_LOG_DIR}GOSALESRT_RUNSTATS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESRT runstats; fi;
fi
if [ -f GOSALESCT_RUNSTATS.SQL ] ; then
   db2 -td@ -f GOSALESCT_RUNSTATS.SQL > "${GOSALES_LOG_DIR}GOSALESCT_RUNSTATS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESCT runstats; fi;
fi
if [ -f GOSALESDW_RUNSTATS.SQL ] ; then
   db2 -td@ -f GOSALESDW_RUNSTATS.SQL > "${GOSALES_LOG_DIR}GOSALESDW_RUNSTATS.LOG"
   if [ $? != 0 ] ; then CreateError GOSALESDW runstats; fi;
fi

##################################################################
# Add table comments
##################################################################
echo Adding table comments
db2 -td@ -f GOSALES_ADD_COMMENTS.SQL > "${GOSALES_LOG_DIR}GOSALES_ADD_COMMENTS.LOG"
if [ $? != 0 ] ; then 
	echo "Error adding table comments" >> "${GOSALES_ERROR_LOG}"
  echo "- see log file GOSALES_ADD_COMMENTS.LOG" >> "${GOSALES_ERROR_LOG}"
fi


VerifyTableRowCounts

##################################################################
# Terminate and cleanup
##################################################################

terminateRunScripts;
return 0;

