#!/bin/sh
########################################################################
#   5724-E34
#   (c) Copyright IBM Corporation 2008, 2009.
#   All rights reserved.
#
#   The source code for this program is not published or otherwise
#   divested of its trade secrets, irrespective of what has been
#   deposited with the U.S. Copyright Office.
########################################################################

echo \/\/RUNSTATE JOB MSGLEVEL=\(1,1\),MSGCLASS=H,CLASS=A,NOTIFY=\&SYSUID., 
echo \/\/ REGION=0M 
echo \/\/JOBLIB DD DSN=PTCA.DB2910.SDSNLOAD,DISP=SHR 
echo \/\/STEP1 EXEC DSNUPROC,SYSTEM=\'PTCA\' 
echo \/\/STEPLIB DD DSN=PTCA.DB2910.SDSNLOAD,DISP=SHR 
echo \/\/SYSDISC DD SYSOUT=\* 
echo \/\/SYSMAP DD SYSOUT=\* 
echo \/\/SYSUT1 DD SYSOUT=\* 
echo \/\/SORTOUT DD SYSOUT=\* 
echo \/\/UTPRINT DD SYSOUT=\* 
echo \/\/SYSPRINT DD SYSOUT=\* 
echo \/\/SYSIN DD \* 
echo RUNSTATS TABLESPACE ${GOSALES_DB}.${GOSALES_TS} TABLE\(ALL\) INDEX\(ALL\) KEYCARD 
