#!/bin/sh
##################################################################
#   5724-E34
#   (c) Copyright IBM Corporation 2008, 2009.
#   All rights reserved.
#
#   The source code for this program is not published or otherwise
#   divested of its trade secrets, irrespective of what has been
#   deposited with the U.S. Copyright Office.
##################################################################
echo -----------------------------------------------
echo -- CREATE THE ${GOSALES_DB} DATABASE
echo -----------------------------------------------
echo
echo CREATE DATABASE ${GOSALES_DB} CCSID UNICODE stogroup ${GOSALES_STG}
echo @
echo
