#!/bin/sh
##################################################################
#   5724-E34
#   (c) Copyright IBM Corporation 2008, 2009.
#   All rights reserved.
#
#   The source code for this program is not published or otherwise
#   divested of its trade secrets, irrespective of what has been
#   deposited with the U.S. Copyright Office.
##################################################################
echo CREATE PROCEDURE ${GOSALES_SCHEMA}.ASSIGNSTAFF \(IN ORDER_DETAIL_CODE_IN VARCHAR\(16\), IN SALES_STAFF_CODE_IN INTEGER\)
echo LANGUAGE SQL
echo BEGIN
echo UPDATE ${GOSALES_SCHEMA}.RETURNED_ITEM
echo SET ASSIGNED_TO = ASSIGNSTAFF.SALES_STAFF_CODE_IN
echo WHERE ORDER_DETAIL_CODE = CAST\(ASSIGNSTAFF.ORDER_DETAIL_CODE_IN AS INTEGER\)\;
echo END
echo @
echo ""
echo GRANT EXECUTE ON PROCEDURE ${GOSALES_SCHEMA}.ASSIGNSTAFF\(VARCHAR\(\),INTEGER\) TO ${GOSALES_GRANTEES}
echo @
