#!/bin/sh
##################################################################
#   5724-E34
#   (c) Copyright IBM Corporation 2008, 2009.
#   All rights reserved.
#
#   The source code for this program is not published or otherwise
#   divested of its trade secrets, irrespective of what has been
#   deposited with the U.S. Copyright Office.
##################################################################

# Get the database version for the database comment
GOSALES_DB_COMMENT=`date`
if [ -f ${GOSALES_IMPORT_FILE_DIR}GOSALES_VERSION.txt ] ; then
     GOSALES_DB_COMMENT=`cat ${GOSALES_IMPORT_FILE_DIR}GOSALES_VERSION.txt`
fi;

echo -----------------------------------------------
echo -- CREATE THE ${GOSALES_INST} DATABASE
echo -----------------------------------------------
echo
echo CREATE DATABASE ${GOSALES_INST} ${GOSALES_DB_CREATE_AUTO_STORAGE} using codeset UTF-8 territory ${GOSALES_DB_TERRITORY} ${GOSALES_DB_PAGESIZE}
echo with \'${GOSALES_DB_COMMENT}\'
echo @
echo
