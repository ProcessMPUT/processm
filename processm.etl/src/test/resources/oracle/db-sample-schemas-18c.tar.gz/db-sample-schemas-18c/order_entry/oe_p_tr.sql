set define off
INSERT INTO product_descriptions VALUES(1726-
,'TR'-
,UNISTR(-
'LCD Monit\00f6r 11/PM'-
),UNISTR(-
'Likit Kristal Ekran 11 in\00e7 pasif monit\00f6r. Sanal olarak d\00fcz,'||-
' y\00fcksek \00e7\00f6z\00fcn\00fcrl\00fckl\00fc ekran azalt\0131l'||-
'm\0131\015f parlakl\0131kla se\00e7kin bir g\00f6r\00fcnt\00fc kali'||-
'tesine sahiptir.'-
));
INSERT INTO product_descriptions VALUES(2359-
,'TR'-
,UNISTR(-
'LCD Monit\00f6r 9/PM'-
),UNISTR(-
'Likit Kristal Ekran 9 in\00e7 pasif monit\00f6r. K\00fc\00e7\00fck mo'||-
'nit\00f6r\00fcn masan\0131zda daha fazla \00e7al\0131\015fma yeri b'||-
'\0131rakarak sa\011flad\0131\011f\0131 verimli\011fin keyfine bak'||-
'\0131n. Tak ve kullan uyumlulu\011fuyla kurulmas\0131 \00e7ok kolay.'-
));
INSERT INTO product_descriptions VALUES(3060-
,'TR'-
,UNISTR(-
'Monit\00f6r 17/HR'-
),UNISTR(-
'CRT Monit\00f6r 17 in\00e7 (16 g\00f6r\00fclebilir) y\00fcksek \00e7'||-
'\00f6z\00fcn\00fcrl\00fck. Ola\011fan\00fcst\00fc resim performans'||-
'\0131 ve daha fazla ekran alan\0131. Bu monit\00f6r, ola\011fan\00fcs'||-
't\00fc de\011ferde \015f\0131k, zengin renge sahip monit\00f6r perfor'||-
'mans\0131 sunar. Ekranda g\00f6r\00fcnt\00fc kontrol\00fc dahil olmak'||-
' \00fczere ileri \00f6zelliklere sahiptir.'-
));
INSERT INTO product_descriptions VALUES(2243-
,'TR'-
,UNISTR(-
'Monit\00f6r 17/HR/F'-
),UNISTR(-
'Monit\00f6r 17 in\00e7 (16 g\00f6r\00fclebilir) y\00fcksek \00e7'||-
'\00f6z\00fcn\00fcrl\00fck, d\00fcz ekran. Ekran i\00e7inde (k\00f6'||-
'\015felerde bile) daha s\00fcrekli ve kesin odaklanma i\00e7in Geli'||-
'\015fmi\015f Eliptik Do\011frultma Sistemi\0027ne sahip y\00fcksek yo'||-
'\011funluklu foton tabancas\0131.'-
));
INSERT INTO product_descriptions VALUES(3057-
,'TR'-
,UNISTR(-
'Monit\00f6r 17/SD'-
),UNISTR(-
'CRT Monit\00f6r 17 in\00e7 (16 g\00f6r\00fclebilir) k\0131sa derinlik'||-
'. Ola\011fan\00fcst\00fc resim berrakl\0131\011f\0131 ve do\011frul'||-
'u\011fu sa\011flar. Geli\015fmi\015f verimlilik i\00e7in b\00fcy'||-
'\00fck masa\00fcst\00fcne ek olarak profesyonel renk, teknik m\00fchen'||-
'dislik ve g\00f6r\00fcnt\00fcleme/animasyon kullan\0131c\0131lar'||-
'\0131na istedikleri renk uygunlu\011funu verir.'-
));
INSERT INTO product_descriptions VALUES(3061-
,'TR'-
,UNISTR(-
'Monit\00f6r 19/SD'-
),UNISTR(-
'CRT Monit\00f6r 19 in\00e7 (18 g\00f6r\00fcnebilir) k\0131sa derinlik'||-
'. Y\00fcksek kar\015f\0131tl\0131kl\0131 siyah ekran kaplamas\0131: '||-
'\00fcst\00fcn kar\015f\0131tl\0131k ve gri \00f6l\00e7ek performans'||-
'\0131. Hareketli, ger\00e7e\011fiyle e\015fde\011fer ses ve zengin de'||-
'rin bas tonlar\0131yla t\00fcm \00e7oklu ortam ses deneyimlerinizi canl'||-
'and\0131ran dinamik bas sese sahip yeni tasarlanm\0131\015f y\00fcksel'||-
'tilmi\015f profesyonel hoperl\00f6rler. Bunlara ek olarak, renk kodlu ka'||-
'blolar, basit tak ve kullan kurulumu ve dijital ekranda kontrolle \00e7ok'||-
'lu ortam\0131n\0131zdaki ve Internetinizdeki g\00f6r\00fcnt\00fcleri '||-
'birka\00e7 dakikada ayarlamaya haz\0131r olursunuz.'-
));
INSERT INTO product_descriptions VALUES(2245-
,'TR'-
,UNISTR(-
'Monit\00f6r 19/SD/M'-
),UNISTR(-
'Monit\00f6r 19 (18 G\00f6r\00fcnebilir) k\0131sa derinlik, Tek renkli.'||-
' K\00fc\00e7\00fck tasar\0131mda inan\0131lmaz resim performans\0131'||-
'. Basit, ekranda g\00f6r\00fcnt\00fcl\00fc men\00fc, ekran boyutlar'||-
'\0131n\0131, renkleri ve resim \00f6zelliklerini kolayca ayarlaman'||-
'\0131za yard\0131mc\0131 olur. Monit\00f6r\00fcn\00fcz\00fc ki'||-
'\015fisel bilgisayar\0131n\0131za takman\0131z yeterlidir. Art\0131k '||-
'\00e7al\0131\015fmaya haz\0131rs\0131n\0131z.'-
));
INSERT INTO product_descriptions VALUES(3065-
,'TR'-
,UNISTR(-
'Monit\00f6r 21/D'-
),UNISTR(-
'CRT Monit\00f6r 21 in\00e7 (20 g\00f6r\00fcnebilir). Dijital OptiScan '||-
'teknolojisi: 75 Hz\0027de 1600 x 1200 \00e7\00f6z\00fcn\00fcrl\00fc'||-
'\011f\00fc destekler. Boyutlar (YxGxD): 8,3 x 18,5 x 15 in\00e7. Monit'||-
'\00f6rden a\00e7\0131lan, ayr\0131labilir ve tak\0131labilir Platin S'||-
'erisi hoperl\00f6rler g\00fc\00e7l\00fc ses ve dijital ses \00e7alar '||-
'prizi kolayl\0131\011f\0131 sa\011flar. Dijital ses \00e7alar\0131n'||-
'\0131z\0131 takman\0131z yeterlidir. Sesleri, ki\015fisel bilgisayar'||-
'\0131n\0131z\0131 \00e7al\0131\015ft\0131rmadan dinleyebilirsiniz.'-
));
INSERT INTO product_descriptions VALUES(3331-
,'TR'-
,UNISTR(-
'Monit\00f6r 21/HR'-
),UNISTR(-
'21 in\00e7 monit\00f6r (20 in\00e7 g\00f6r\00fcnebilir) y\00fcksek '||-
'\00e7\00f6z\00fcn\00fcrl\00fck. Bu monit\00f6r i\015f, masa\00fcst'||-
'\00fc yay\0131nc\0131l\0131k ve yo\011fun grafi\011fe sahip uygulama'||-
'lar i\00e7in uygundur. B\00fcy\00fck ekran\0131n, uygulamalar\0131 '||-
'\00e7al\0131\015ft\0131rmak i\00e7in daha \00e7ok \00e7al\0131'||-
'\015fma alan\0131 sunarak sa\011flad\0131\011f\0131 verimli\011fin '||-
'keyfini \00e7\0131kar\0131n.'-
));
INSERT INTO product_descriptions VALUES(2252-
,'TR'-
,UNISTR(-
'Monit\00f6r 21/HR/M'-
),UNISTR(-
'Monit\00f6r 21 in\00e7 (20 g\00f6r\00fclebilir) y\00fcksek \00e7'||-
'\00f6z\00fcn\00fcrl\00fck, tek renk. Birim boyutu: 35,6 x 29,6 x 33,3 '||-
'cm (14,6 kg) Paket: 40,53 x 31,24 x 35,39 cm (16,5 kg). Yatay frekans 31,5'||-
' - 54 kHz, Dikey frekans 50 - 120 Hz. Universal g\00fc\00e7 kayna\011f'||-
'\0131 90 - 132 V, 50 - 60 Hz.'-
));
INSERT INTO product_descriptions VALUES(3064-
,'TR'-
,UNISTR(-
'Monit\00f6r 21/SD'-
),UNISTR(-
'Monit\00f6r 21 in\00e7 (20 g\00f6r\00fclebilir) k\0131sa derinlik. '||-
'\00d6zellikler aras\0131nda \015funlar bulunmaktad\0131r: 0,25-0,28 De'||-
'lik Izgara Mesafesi, 76 Hz\0027de 1920 x 1200 \00e7\00f6z\00fcn\00fcr'||-
'l\00fck deste\011fi, ekranda g\00f6r\00fcnt\00fc ve iletken yans'||-
'\0131tmay\0131 engelleyici film kaplama.'-
));
INSERT INTO product_descriptions VALUES(3155-
,'TR'-
,UNISTR(-
'Monit\00f6r \00c7er\00e7evesi - HD'-
),UNISTR(-
'Monit\00f6r \00c7er\00e7evesi, dayan\0131kl\0131, maksimum monit'||-
'\00f6r a\011f\0131rl\0131\011f\0131 30 kg'-
));
INSERT INTO product_descriptions VALUES(3234-
,'TR'-
,UNISTR(-
'Monit\00f6r \00c7er\00e7evesi - STD'-
),UNISTR(-
'Standart Monit\00f6r \00c7er\00e7evesi, maksimum monit\00f6r a\011f'||-
'\0131rl\0131\011f\0131 10 kg'-
));
INSERT INTO product_descriptions VALUES(3350-
,'TR'-
,UNISTR(-
'Plazma Monit\00f6r 10/LE/VGA'-
),UNISTR(-
'10 in\00e7 d\00fc\015f\00fck enerjili plazma monit\00f6r, VGA \00e7'||-
'\00f6z\00fcn\00fcrl\00fck'-
));
INSERT INTO product_descriptions VALUES(2236-
,'TR'-
,UNISTR(-
'Plasma Monit\00f6r 10/TFT/XGA'-
),UNISTR(-
'Diz\00fcst\00fc bilgisayarlar i\00e7in 10 in\00e7 TFT XGA d\00fcz ekr'||-
'an monit\00f6r'-
));
INSERT INTO product_descriptions VALUES(3054-
,'TR'-
,UNISTR(-
'Plasma Monit\00f6r 10/XGA'-
),UNISTR(-
'10 in\00e7 standart plazma monit\00f6r, XGA \00e7\00f6z\00fcn\00fcrl'||-
'\00fck. Bu sanal olarak d\00fcz, y\00fcksek \00e7\00f6z\00fcn\00fcr'||-
'l\00fckl\00fc ekran, azalt\0131lm\0131\015f parlakl\0131\011fa sahi'||-
'p ola\011fan\00fcst\00fc resim kalitesi sa\011flar.'-
));
INSERT INTO product_descriptions VALUES(1782-
,'TR'-
,UNISTR(-
'Compact 400/DQ'-
),UNISTR(-
'Saniyede 400 karakter basabilen y\00fcksek h\0131zl\0131 taslak yaz'||-
'\0131c\0131. Boyutlar (YxGxD): 17,34 x 24,26 x 26,32 in\00e7. Aray'||-
'\00fcz: RS-232 seri (9-pin), geni\015fleme yuvas\0131 yok. Ka\011f'||-
'\0131t boyutu: A4, ABD Letter.'-
));
INSERT INTO product_descriptions VALUES(2430-
,'TR'-
,UNISTR(-
'Compact 400/LQ'-
),UNISTR(-
'Saniyede 400 karakter basabilen y\00fcksek mektup kalitesinde yaz\0131c'||-
'\0131. Boyutlar (YxGxD): 12.37 x 27.96 x 23.92 in\00e7. Aray\00fcz: RS-'||-
'232 seri (25-pin), 3 geni\015fleme yuvas\0131. Ka\011f\0131t boyutlar'||-
'\0131: A2, A3, A4.'-
));
INSERT INTO product_descriptions VALUES(1792-
,'TR'-
,UNISTR(-
'Industrial 600/DQ'-
),UNISTR(-
'Geni\015f ta\015f\0131ma renk kapasitesi saniyede 600 karakter basabile'||-
'n y\00fcksek h\0131zl\0131 taslak yaz\0131c\0131s\0131. Boyutlar (Yx'||-
'GxD): 22,31 x 25,73 x 20,12 in\00e7. Ka\011f\0131t boyutu: 3x5 in\00e7'||-
'-11x17 in\00e7 aras\0131 tam bo\015falt\0131ma sahip geni\015f format'||-
'.'-
));
INSERT INTO product_descriptions VALUES(1791-
,'TR'-
,UNISTR(-
'Industrial 700/HD'-
),UNISTR(-
'End\00fcstriyel kullan\0131m i\00e7in, daha sert g\00f6vdeye ve toz ko'||-
'rumas\0131na sahip saniyede 700 karakter basabilen nokta-matris yaz\0131'||-
'c\0131. Aray\00fcz: paralel Centronics, IEEE 1284 uyumlu. Ka\011f\0131'||-
't boyutu: 3x5-11x17 aras\0131ndaki tam bo\015falt\0131ml\0131 geni'||-
'\015f format. Bellek: 4MB. Boyutlar (YxGxD): 9,3 x 16,5 x 13 in\00e7.'-
));
INSERT INTO product_descriptions VALUES(2302-
,'TR'-
,UNISTR(-
'Inkjet B/6'-
),UNISTR(-
'Inkjet Yaz\0131c\0131, siyah ve beyaz, dakikada 6 sayfa, 600x300 dpi '||-
'\00e7\00f6z\00fcn\00fcrl\00fck. Aray\00fcz: Paralel Centronics, IEEE'||-
' 1284 uyumlu. Boyutlar (YxGxD): 7,3 x 17,5 x 14 in\00e7. Ka\011f\0131t '||-
'boyutu: A3, A4, ABD legal. Geni\015fleme yuvas\0131 yok.'-
));
INSERT INTO product_descriptions VALUES(2453-
,'TR'-
,UNISTR(-
'Inkjet C/4'-
),UNISTR(-
'Inkjet Yaz\0131c\0131, renkli (iki ayr\0131 m\00fcrekkep kartu\015fuy'||-
'la birlikte), dakikada 6 sayfa siyah/ beyaz, dakikada 4 sayfa renkli, 600x'||-
'300 dpi \00e7\00f6z\00fcn\00fcrl\00fck. Aray\00fcz: \00c7ift y'||-
'\00f6nl\00fc IEEE 1284 uyumlu paralel aray\00fcz ve RS-232 seri (9-pin)'||-
' aray\00fcz 2 a\00e7\0131k EIO geni\015fleme yuvas\0131. Bellek: 8MB '||-
'96KB al\0131c\0131 arabelle\011fi.'-
));
INSERT INTO product_descriptions VALUES(1797-
,'TR'-
,UNISTR(-
'Inkjet C/8/HQ'-
),UNISTR(-
'Inkjet yaz\0131c\0131, renkli, dakikada 8 sayfa, y\00fcksek \00e7'||-
'\00f6z\00fcn\00fcrl\00fck (foto\011fraf kalitesi). Bellek: 16 MB. Boy'||-
'utlar (YxGxD): 7,3 x 17,5 x 14 in\00e7. Ka\011f\0131t boyutu: A4, ABD L'||-
'etter, zarflar. Aray\00fcz: paralel Centronics, IEEE 1284 uyumlu.'-
));
INSERT INTO product_descriptions VALUES(2459-
,'TR'-
,UNISTR(-
'LaserPro 1200/8/BW'-
),UNISTR(-
'Profesyonel siyah ve beyaz lazer yaz\0131c\0131, 1200 dpi \00e7\00f6z'||-
'\00fcn\00fcrl\00fck, saniyede 8 sayfa. Boyutlar (YxGxD): 22,37 x 19,86 '||-
'x 21,92 in\00e7. Yaz\0131l\0131m: SPNIX v4.0 i\00e7in geli\015fmi'||-
'\015f s\00fcr\00fcc\00fc deste\011fi; MS-DOS Yerle\015fik yaz\0131c'||-
'\0131 s\00fcr\00fcc\00fcleri: ZoomSmart \00f6l\00e7ekleme teknolojis'||-
'i, ilan tahtas\0131, el ilan\0131, ayna, filigran, bask\0131 \00f6nizl'||-
'eme, h\0131zl\0131 ayarlar, \00f6yk\00fcnme lazer yaz\0131c\0131 ken'||-
'ar bo\015fluklar\0131.'-
));
INSERT INTO product_descriptions VALUES(3127-
,'TR'-
,UNISTR(-
'LaserPro 600/6/BW'-
),UNISTR(-
'Standart siyah-beyaz lazer yaz\0131c\0131, 600 dpi \00e7\00f6z\00fcn'||-
'\00fcrl\00fck, saniyede 6 sayfa bask\0131. Aray\00fcz: paralel Centron'||-
'ics, IEEE 1284 uyumlu. Bellek: 8MB 96KB al\0131c\0131 arabelle\011fi. S'||-
'PNIX AutoCAM s.17 i\00e7in MS-DOS ToolBox yard\0131mc\0131 program'||-
'\0131 uyumlu s\00fcr\00fcc\00fc.'-
));
INSERT INTO product_descriptions VALUES(2254-
,'TR'-
,UNISTR(-
'HD 10GB /I'-
),UNISTR(-
'10GB kapasiteli sabit disk s\00fcr\00fcc\00fc (dahili). Bu s\00fcr'||-
'\00fcc\00fcler, bug\00fcn\00fcn titiz, verilerin kritik \00f6nem ta'||-
'\015f\0131d\0131\011f\0131 kurulu\015f ortamlar\0131nda kullan'||-
'\0131lmak \00fczere tasarlanm\0131\015ft\0131r ve RAID uygulama yaz'||-
'\0131l\0131mlar\0131nda kullanmak i\00e7in idealdir. Universal se'||-
'\00e7enek setleri, \015firketinizin sunucusuna veya depolama sistemine h'||-
'\0131zl\0131 kurulum i\00e7in uygun h\0131zl\0131 ba\011flant\0131 '||-
'prizi tepsisinde konfig\00fcre edilir ve \00f6nceden monte edilir.'-
));
INSERT INTO product_descriptions VALUES(3353-
,'TR'-
,UNISTR(-
'HD 10GB /R'-
),UNISTR(-
'10GB \00c7\0131kar\0131labilir Sabit Disk s\00fcr\00fcc\00fc i\00e7'||-
'in 10GB \00c7\0131kar\0131labilir sabit disk s\00fcr\00fcc\00fc. Sup'||-
'ra7 disket s\00fcr\00fcc\00fcler, maksimum veri transferi h\0131z'||-
'\0131n\0131 160MB/saniyeye \00e7\0131kartarak giri\015fim performans'||-
'\0131n\0131 geli\015ftirmek i\00e7in en son teknolojiyi sa\011flar.'-
));
INSERT INTO product_descriptions VALUES(3069-
,'TR'-
,UNISTR(-
'HD 10GB /S'-
),UNISTR(-
'Standart Montaj i\00e7in 10GB sabit disk. Geriye do\011fru, Supra5 siste'||-
'mlerle uyumlu, kullan\0131c\0131lar\0131n art\0131r\0131lm\0131'||-
'\015f depolama kapasitesini h\0131zl\0131 \015fekilde sa\011flamak i'||-
'\00e7in bu s\00fcr\00fcc\00fcleri yerle\015ftirme ve yeniden yerle'||-
'\015ftirme olana\011f\0131 vard\0131r. Supra s\00fcr\00fcc\00fcler '||-
'\015firket yaz\0131l\0131m\0131 uyumsuzlu\011fu riskini ortadan kald'||-
'\0131r\0131r.'-
));
INSERT INTO product_descriptions VALUES(2253-
,'TR'-
,UNISTR(-
'HD 10GB @5400 /SE'-
),UNISTR(-
'10GB kapasiteli sabit disk s\00fcr\00fcc\00fc (harici) SCSI aray\00fcz'||-
'\00fc, 5400 RPM. Universal se\00e7enek setleri, \015firket s\00fcr'||-
'\00fcc\00fcn\00fcze veya depolama sisteminize h\0131zl\0131 kurulum i'||-
'\00e7in h\0131zl\0131 ba\011flant\0131 tepsisinde konfig\00fcre edil'||-
'mi\015f ve \00f6nceden monte edilmi\015ftir. Supra s\00fcr\00fcc'||-
'\00fcler \015firket yaz\0131l\0131m\0131 uyumsuzlu\011funu ortadan k'||-
'ald\0131r\0131r.'-
));
INSERT INTO product_descriptions VALUES(3354-
,'TR'-
,UNISTR(-
'HD 12GB /I'-
),UNISTR(-
'12GB kapasiteli sabit disk s\00fcr\00fcc\00fc (dahili). Supra s\00fcr'||-
'\00fcc\00fcler \015firket yaz\0131l\0131m\0131 uyumsuzlu\011funu or'||-
'tadan kald\0131r\0131r. Geriye d\00f6n\00fck uyumluluk: Supra2 ve Supr'||-
'a3 ayg\0131tlar\0131 iyile\015ftirilmi\015f \00e7\00f6z\00fcmler ol'||-
'u\015fturmak veya gelecekte b\00fcy\00fctmek i\00e7in kar\0131\015ft'||-
'\0131rabilir veya e\015fle\015ftirebilirsiniz.'-
));
INSERT INTO product_descriptions VALUES(3072-
,'TR'-
,UNISTR(-
'HD 12GB /N'-
),UNISTR(-
'Dar Montaj Alan\0131 i\00e7in 12GB sabit disk s\00fcr\00fcc\00fc. Sup'||-
'ra9 h\0131zl\0131 tak\0131labilir sabit disk s\00fcr\00fcc\00fcler, '||-
's\00fcr\00fcc\00fcleri on line olarak takma ve \00e7\0131karma beceri'||-
'si sa\011flar. H\0131zl\0131 tak\0131labilir sabit disk s\00fcr\00fc'||-
'c\00fclerimiz, zorlu g\00fcvenirlik ve performans standartlar\0131m'||-
'\0131z\0131 kar\015f\0131lamak i\00e7in gereklidir.'-
));
INSERT INTO product_descriptions VALUES(3334-
,'TR'-
,UNISTR(-
'HD 12GB /R'-
),UNISTR(-
'12GB \00c7\0131kar\0131labilir sabit disk s\00fcr\00fcc\00fc. Bir'||-
'\00e7ok giri\015fim platformuna uyumludur ve art\0131r\0131lm\0131'||-
'\015f depolama kapasitesini h\0131zl\0131 \015fekilde da\011f\0131tm'||-
'ak i\00e7in bu s\00fcr\00fcc\00fcy\00fc kullanabilir ve yeniden kulla'||-
'nabilirsiniz. Supra7 Universal disk s\00fcr\00fcc\00fcler, \015firket '||-
'sunucusu ve harici depolama duvarlar\0131 yoluyla uygunlu\011fu payla'||-
'\015fan y\00fcksek performansl\0131 h\0131zl\0131 tak\0131lan s'||-
'\00fcr\00fcc\00fclerin ikinci neslidir.'-
));
INSERT INTO product_descriptions VALUES(3071-
,'TR'-
,UNISTR(-
'HD 12GB /S'-
),UNISTR(-
'Standart Montaj Alan\0131 i\00e7in 12GB sabit disk s\00fcr\00fcc\00fc'||-
'. Supra9 h\0131zl\0131 tak\0131labilir sabit disk s\00fcr\00fcc\00fc'||-
'ler, s\00fcr\00fcc\00fcleri online olarak takma ve \00e7\0131karma be'||-
'cerisi sa\011flar. H\0131zl\0131 tak\0131labilir sabit disk s\00fcr'||-
'\00fcc\00fclerimiz, zorlu g\00fcvenirlik ve performans standartlar'||-
'\0131m\0131z\0131 kar\015f\0131lamak i\00e7in gereklidir.'-
));
INSERT INTO product_descriptions VALUES(2255-
,'TR'-
,UNISTR(-
'HD 12GB @7200 /SE'-
),UNISTR(-
'12GB kapasiteli sabit disk s\00fcr\00fcc\00fc (harici) SCSI, 7200 RPM. '||-
'Bu s\00fcr\00fcc\00fcler, bug\00fcn\00fcn titiz, verilerin kritik '||-
'\00f6nem ta\015f\0131d\0131\011f\0131 kurulu\015f ortamlar\0131nda'||-
' kullan\0131lmak \00fczere tasarlanm\0131\015ft\0131r ve RAID uygulam'||-
'a yaz\0131l\0131mlar\0131nda kullanmak i\00e7in idealdir. Universal se'||-
'\00e7enek setleri, \015firketinizin sunucusuna veya depolama sistemine h'||-
'\0131zl\0131 kurulum i\00e7in uygun h\0131zl\0131 ba\011flant\0131 '||-
'prizi tepsisinde konfig\00fcre edilir ve \00f6nceden monte edilir.'-
));
INSERT INTO product_descriptions VALUES(1743-
,'TR'-
,UNISTR(-
'HD 18.2GB @10000 /E'-
),UNISTR(-
'Harici sabit disk s\00fcr\00fcc\00fc - 18,2 GB, en \00e7ok 10.000 RPM '||-
'h\0131za sahiptir. Bu s\00fcr\00fcc\00fcler, bug\00fcn\00fcn titiz, '||-
'verilerin kritik \00f6nem ta\015f\0131d\0131\011f\0131 kurulu\015f '||-
'ortamlar\0131nda kullan\0131lmak \00fczere tasarlanm\0131\015ft\0131'||-
'r ve RAID uygulama yaz\0131l\0131mlar\0131nda kullanmak i\00e7in ideal'||-
'dir.'-
));
INSERT INTO product_descriptions VALUES(2382-
,'TR'-
,UNISTR(-
'HD 18.2GB@10000 /I'-
),UNISTR(-
'18.2 GB SCSI sabit disk @ 10000 RPM (dahili). Supra7 Universal disk s'||-
'\00fcr\00fcc\00fcler, bir\00e7ok giri\015f platformu aras\0131nda s'||-
'\00fcr\00fcc\00fc uygunlu\011fu olana\011f\0131 vererek, m\00fc'||-
'\015fteriler i\00e7in e\015fsiz bir yat\0131r\0131m koruma ve kolayla'||-
'\015ft\0131rma d\00fczeyi sa\011flar.'-
));
INSERT INTO product_descriptions VALUES(3399-
,'TR'-
,UNISTR(-
'HD 18GB /SE'-
),UNISTR(-
'18GB SCSI harici sabit disk s\00fcr\00fcc\00fc. Supra5 Universal sabit '||-
'disk s\00fcr\00fcc\00fcleri \00e7e\015fitli sunucular, RAID s\0131ra'||-
'lar\0131 ve harici depolama raflar\0131 aras\0131nda h\0131zl\0131 ba'||-
'\011flant\0131 becerisi sa\011flar.'-
));
INSERT INTO product_descriptions VALUES(3073-
,'TR'-
,UNISTR(-
'HD 6GB /I'-
),UNISTR(-
'6GB kapasiteli sabit disk s\00fcr\00fcc\00fc (dahili). Supra s\00fcr'||-
'\00fcc\00fcler \015firket yaz\0131l\0131m\0131 uyumsuzlu\011funu or'||-
'tadan kald\0131r\0131r.'-
));
INSERT INTO product_descriptions VALUES(1768-
,'TR'-
,UNISTR(-
'HD 8.2GB @5400'-
),UNISTR(-
'Sabit s\00fcr\00fcc\00fc disk - 8,2 GB, en \00e7ok 5.400 RPM h\0131zl'||-
'\0131. Supra s\00fcr\00fcc\00fcler \015firket yaz\0131l\0131m\0131'||-
' uyumsuzlu\011funu ortadan kald\0131r\0131r. Standart seri RS-232 aray'||-
'\00fcz.'-
));
INSERT INTO product_descriptions VALUES(2410-
,'TR'-
,UNISTR(-
'HD 8.4GB @5400'-
),UNISTR(-
'8.4 GB sabit disk @ 5400 RPM. D\00fc\015f\00fck maliyetli: S\00fcr'||-
'\00fcc\00fcler kurulu\015f platformu \00fczerinden kullan\0131labilir'||-
'. Bu h\0131zl\0131 tak\0131labilir sabit disk s\00fcr\00fcc\00fcler,'||-
' zorlu g\00fcvenilirlik ve performans standartlar\0131n\0131z\0131 kar'||-
'\015f\0131lamak i\00e7in gereklidir.'-
));
INSERT INTO product_descriptions VALUES(2257-
,'TR'-
,UNISTR(-
'HD 8GB /I'-
),UNISTR(-
'8GB kapasiteli sabit disk s\00fcr\00fcc\00fc (dahili). Supra9 h\0131zl'||-
'\0131 tak\0131labilir sabit disk s\00fcr\00fcc\00fcler, s\00fcr'||-
'\00fcc\00fcleri on line olarak takma ve \00e7\0131karma becerisi sa'||-
'\011flar. Geriye d\00f6n\00fck uyumluluk: En iyi duruma getirilmi\015f'||-
' \00e7\00f6z\00fcmler ve daha sonraki geli\015ftirmeler i\00e7in Supr'||-
'a2 ve Supra3 ayg\0131tlar\0131n\0131 bir arada kullanabilirsiniz.'-
));
INSERT INTO product_descriptions VALUES(3400-
,'TR'-
,UNISTR(-
'HD 8GB /SE'-
),UNISTR(-
'8GB kapasiteli SCSI sabit disk s\00fcr\00fcc\00fc (harici). Supra7 disk'||-
' s\00fcr\00fcc\00fcler, maksimum veri transferi h\0131z\0131n\0131 e'||-
'n \00e7ok 255MB/sn\0027ye \00e7\0131kartarak kurulu\015fun performans'||-
'\0131n\0131 geli\015ftirmek \00fczere son teknolojiyi sa\011flar.'-
));
INSERT INTO product_descriptions VALUES(3355-
,'TR'-
,UNISTR(-
'HD 8GB /SI'-
),UNISTR(-
'8GB SCSI sabit disk s\00fcr\00fcc\00fc, dahili. Bir \00e7ok kurulu'||-
'\015f platformuna uyumludur ve art\0131r\0131lm\0131\015f depolama ka'||-
'pasitesini h\0131zl\0131 \015fekilde da\011f\0131tmak i\00e7in bu s'||-
'\00fcr\00fcc\00fcy\00fc kullanabilir ve yeniden kullanabilirsiniz.'-
));
INSERT INTO product_descriptions VALUES(1772-
,'TR'-
,UNISTR(-
'HD 9.1GB @10000'-
),UNISTR(-
'Sabit disk s\00fcr\00fcc\00fc - 9,1 GB, en \00e7ok 10.000 RPM h\0131z'||-
'l\0131. Bu s\00fcr\00fcc\00fcler, bug\00fcn\00fcn titiz, veri incele'||-
'mesi yapan kurulu\015f ortamlar\0131nda kullan\0131lmak \00fczere tasa'||-
'rlanm\0131\015ft\0131r. \0130\015f yapma kolayl\0131\011f\0131: Ha'||-
'ngi uygulama yaz\0131l\0131m\0131nda kullan\0131laca\011f\0131na bak'||-
'madan, gereksinim duydu\011funuz s\00fcr\00fcc\00fcleri kolayl\0131kl'||-
'a se\00e7ebilirsiniz.'-
));
INSERT INTO product_descriptions VALUES(2414-
,'TR'-
,UNISTR(-
'HD 9.1GB @10000 /I'-
),UNISTR(-
'9.1 GB SCSI sabit disk @ 10000 RPM (dahili). 10.000 RPM eksen h\0131z'||-
'\0131nda ve 18GB ve 9,1 GB kapasitesinde Supra7 disk s\00fcr\00fcc'||-
'\00fcler mevcuttur. SCSI ve RS-232 aray\00fczleri.'-
));
INSERT INTO product_descriptions VALUES(2415-
,'TR'-
,UNISTR(-
'HD 9.1GB @7200'-
),UNISTR(-
'9,1 GB sabit disk @ 7200 RPM. Universal se\00e7enek setleri, \015firket '||-
'sunucunuza veya depolama sisteminize h\0131zl\0131 kurulum i\00e7in h'||-
'\0131zl\0131 ba\011flant\0131 tepsisinde konfig\00fcre edilmi\015f v'||-
'e \00f6nceden monte edilmi\015ftir.'-
));
INSERT INTO product_descriptions VALUES(2395-
,'TR'-
,UNISTR(-
'32MB \00d6nbellek /M'-
),UNISTR(-
'32MB Yans\0131t\0131lm\0131\015f \00f6nbellek (100-MHz Kay\0131tl'||-
'\0131 SDRAM)'-
));
INSERT INTO product_descriptions VALUES(1755-
,'TR'-
,UNISTR(-
'32MB \00d6nbellek /NM'-
),UNISTR(-
'32MB Yans\0131t\0131lmam\0131\015f \00f6nbellek'-
));
INSERT INTO product_descriptions VALUES(2406-
,'TR'-
,UNISTR(-
'64MB \00d6nbellek /M'-
),UNISTR(-
'64MB Yans\0131t\0131lm\0131\015f \00f6nbellek'-
));
INSERT INTO product_descriptions VALUES(2404-
,'TR'-
,UNISTR(-
'64MB \00d6nbellek /NM'-
),UNISTR(-
'64 MB yans\0131t\0131lmam\0131\015f \00f6nbellek. FPM bellek yongalar'||-
'\0131 5 voltluk SIMM\0027lere uygulan\0131r, ancak 3.3 volt DIMM\0027l'||-
'er \015feklinde de bulunur.'-
));
INSERT INTO product_descriptions VALUES(1770-
,'TR'-
,UNISTR(-
'8MB \00d6nbellek /NM'-
),UNISTR(-
'8MB Yans\0131t\0131lmam\0131\015f \00d6nbellek (100-MHz Kay\0131tl'||-
'\0131 SDRAM)'-
));
INSERT INTO product_descriptions VALUES(2412-
,'TR'-
,UNISTR(-
'8MB EDO Bellek'-
),UNISTR(-
'8 MB 8x32 EDO SIM bellek. Geni\015fletilmi\015f Veri \00c7\0131k\0131'||-
'\015f belle\011fi, k\00fc\00e7\00fck ancak ay\0131rt edici bir de'||-
'\011fi\015fiklikle FPM\0027den ayr\0131l\0131r. FPM\0027den farkl'||-
'\0131 olarak, bellek kontrolc\00fcs\00fc sonraki d\00f6ng\00fcye ba'||-
'\015flamak i\00e7in s\00fctun adresini kald\0131rd\0131\011f\0131nd'||-
'a EDO\0027nun veri \00e7\0131k\0131\015f s\00fcr\00fcc\00fcleri a'||-
'\00e7\0131k kal\0131r. B\00f6ylece, \00f6nceki d\00f6ng\00fc tamaml'||-
'anmadan yeni bir veri d\00f6ng\00fcs\00fc ba\015flayabilir. EDO, SIMM '||-
've DIMM\0027lerde halinde 3,3 ve 5 volt olarak mevcuttur.'-
));
INSERT INTO product_descriptions VALUES(2378-
,'TR'-
,UNISTR(-
'DIMM - 128 MB'-
),UNISTR(-
'128 MB DIMM bellek. SIMM\0027den DIMM\0027ye ge\00e7menin temel nedeni,'||-
' 64-bit i\015flemcilerin daha y\00fcksek veri yolu geni\015fliklerini d'||-
'esteklemektir. DIMM\0027ler 64 veya 72-bit geni\015fli\011findedir; SIM'||-
'M\0027ler sadece 32 veya 36-bit geni\015fli\011findedir (e\015fitlik d'||-
'e\011feriyle).'-
));
INSERT INTO product_descriptions VALUES(3087-
,'TR'-
,UNISTR(-
'DIMM - 16 MB'-
),UNISTR(-
'Citrus OLX DIMM - 16 MB kapasite.'-
));
INSERT INTO product_descriptions VALUES(2384-
,'TR'-
,UNISTR(-
'DIMM - 1GB'-
),UNISTR(-
'Bellek DIMM: RAM - 1 GB kapasite.'-
));
INSERT INTO product_descriptions VALUES(1749-
,'TR'-
,UNISTR(-
'DIMM - 256MB'-
),UNISTR(-
'Bellek DIMM: RAM 256 MB. (100-MHz Kay\0131tl\0131 SDRAM)'-
));
INSERT INTO product_descriptions VALUES(1750-
,'TR'-
,UNISTR(-
'DIMM - 2GB'-
),UNISTR(-
'Bellek DIMM: RAM, 2 GB kapasite.'-
));
INSERT INTO product_descriptions VALUES(2394-
,'TR'-
,UNISTR(-
'DIMM - 32MB'-
),UNISTR(-
'32 MB DIMM Bellek y\00fckseltme'-
));
INSERT INTO product_descriptions VALUES(2400-
,'TR'-
,UNISTR(-
'DIMM - 512 MB'-
),UNISTR(-
'512 MB DIMM bellek. Geli\015fmi\015f d\00fczeyde bellek y\00fckseltme:'||-
' Sistemi y\00fckseltmek i\00e7in, ayn\0131 sistemde kullan\0131lmas'||-
'\0131 gereken SIMM\0027den daha az DIMM gerekir. Art\0131r\0131lm'||-
'\0131\015f maksimum bellek tavanlar\0131: Ayn\0131 say\0131da bellek '||-
'yuvas\0131 verildi\011finde, DIMM\0027leri kullanan bir sistemin maksim'||-
'um belle\011fi, SIMM\0027leri kullanan sisteminkinden daha \00e7oktur. '||-
'DIMM\0027lerde kart\0131n her taraf\0131nda, bir SIMM\0027dekinden iki'||-
' kat fazla veri h\0131z\0131 sa\011flayan ayr\0131 temas noktalar'||-
'\0131 vard\0131r.'-
));
INSERT INTO product_descriptions VALUES(1763-
,'TR'-
,UNISTR(-
'DIMM - 64MB'-
),UNISTR(-
'Bellek DIMM: RAM, 64MB (100-MHz Kay\0131ts\0131z ECC SDRAM)'-
));
INSERT INTO product_descriptions VALUES(2396-
,'TR'-
,UNISTR(-
'EDO - 32MB'-
),UNISTR(-
'Bellek EDO SIM: RAM, 32 MB (100-MHz Kay\0131tl\0131 Olmayan ECC SDRAM). '||-
'FPM\0027ye benzer \015fekilde, EDO, SIMM\0027lerde ve DIMM\0027lerde, '||-
'3,3 ve 5 voltluk \00e7e\015fitler halinde mevcuttur. EDO, EDO belle'||-
'\011fini desteklemek \00fczere tasarlanmam\0131\015f olan bir bilgisay'||-
'ara y\00fcklenirse, bellek \00e7al\0131\015fmayabilir.'-
));
INSERT INTO product_descriptions VALUES(2272-
,'TR'-
,UNISTR(-
'RAM - 16 MB'-
),UNISTR(-
'Bellek SIMM: RAM - 16 MB kapasite.'-
));
INSERT INTO product_descriptions VALUES(2274-
,'TR'-
,UNISTR(-
'RAM - 32 MB'-
),UNISTR(-
'Bellek SIMM: RAM - 32 MB kapasite.'-
));
INSERT INTO product_descriptions VALUES(3090-
,'TR'-
,UNISTR(-
'RAM - 48 MB'-
),UNISTR(-
'Rasgele Eri\015fimli Bellek (RAM), SIMM - 48 MB kapasite.'-
));
INSERT INTO product_descriptions VALUES(1739-
,'TR'-
,UNISTR(-
'SDRAM - 128 MB'-
),UNISTR(-
'SDRAM bellek, 128 MB kapasite. SDRAM, standart DRAM\0027lerden en \00e7o'||-
'k d\00f6rt kat fazla olan 100 MHz h\0131zdaki verilere eri\015febilir. '||-
'SDRAM\0027nin avantajlar\0131 tam olarak uygulanabilir, ancak, bu sadece'||-
' SDRAM\0027yi destekleyecek \015fekilde tasarlanm\0131\015f bilgisayar'||-
'da yap\0131labilir. SDRAM 5 ve 3,3 volt DIMM\0027ler halinde mevcuttur.'-
));
INSERT INTO product_descriptions VALUES(3359-
,'TR'-
,UNISTR(-
'SDRAM - 16 MB'-
),UNISTR(-
'SDRAM bellek y\00fckseltme mod\00fcl\00fc, 16 MB. Senkronize Dinamik Ra'||-
'sgele Eri\015fimli Bellek, EDO\0027dan sonra piyasaya s\00fcr\00fclm'||-
'\00fc\015ft\00fcr. Bunun mimarisi ve i\015fletimi standart DRAM\0027l'||-
'erdeki gibidir, ancak SDRAM, veri alma s\00fcresini daha da azaltan belle'||-
'k saklama a\00e7\0131s\0131ndan devrim say\0131labilecek bir de\011fi'||-
'\015fiklik sa\011flar. SDRAM, CPU\0027yu kontrol eden sistem saatiyle s'||-
'enkronize edilir. Bu da, mikro i\015flemcinin fonksiyonlar\0131n\0131 k'||-
'ontrol eden sistem saatinin, SDRAM fonksiyonlar\0131n\0131 da kontrol et'||-
'ti\011fi anlam\0131na gelir. Bu, bellek kontrolc\00fcs\00fcn\00fcn, v'||-
'eri talebinin hangi saat devrinde haz\0131r olaca\011f\0131n\0131 bilm'||-
'esini olanak verir ve b\00f6ylece zamanlama gecikmelerini ortadan kald'||-
'\0131r\0131r.'-
));
INSERT INTO product_descriptions VALUES(3088-
,'TR'-
,UNISTR(-
'SDRAM - 32 MB'-
),UNISTR(-
'ECC - 32 MB kapasiteye sahip SDRAM mod\00fcl\00fc. SDRAM, ayn\0131 anda'||-
' \00e7al\0131\015fabilen birden \00e7ok bellek y\0131\011f\0131n'||-
'\0131na sahiptir. Y\0131\011f\0131nlar aras\0131nda ge\00e7i\015f, '||-
's\00fcrekli veri ak\0131\015f\0131na izin verir.'-
));
INSERT INTO product_descriptions VALUES(2276-
,'TR'-
,UNISTR(-
'SDRAM - 48 MB'-
),UNISTR(-
'Bellek SIMM: RAM - 48 MB. SDRAM, veri blo\011fu modunda \00e7al\0131'||-
'\015fabilir. Veri blo\011fu modunda, tek bir veri adresine eri\015fildi'||-
'\011finde, tek bir par\00e7a yerine t\00fcm veri blo\011fu al\0131n'||-
'\0131r. Talep edilecek olan sonraki veri par\00e7as\0131n\0131n, '||-
'\00f6ncekinin devam\0131 olaca\011f\0131 varsay\0131l\0131r. Durum g'||-
'enellikle b\00f6yle oldu\011fu i\00e7in veriler haz\0131r tutulur.'-
));
INSERT INTO product_descriptions VALUES(3086-
,'TR'-
,UNISTR(-
'VRAM - 16 MB'-
),UNISTR(-
'Citrus Video RAM mod\00fcl\00fc - 16 MB kapasite. VRAM, bilgisayardaki g'||-
'\00f6r\00fcnt\00fc sistemi taraf\0131ndan g\00f6r\00fcnt\00fc bilgi'||-
'lerini saklamak i\00e7in kullan\0131l\0131r ve g\00f6r\00fcnt\00fc i'||-
'\015flemleri i\00e7in ayr\0131ca saklan\0131r. G\00f6r\00fcnt\00fc '||-
'ekranlar\0131n\0131 yenilemek i\00e7in s\00fcrekli veri dizisi ak'||-
'\0131\015f\0131 sa\011flamak \00fczere geli\015ftirilmi\015ftir.'-
));
INSERT INTO product_descriptions VALUES(3091-
,'TR'-
,UNISTR(-
'VRAM - 64 MB'-
),UNISTR(-
'Citrus Video RAM bellek mod\00fcl\00fc - 64 MB kapasite. Fiziksel olarak'||-
', VRAM aynen kayd\0131rma yazmac\0131 adl\0131 eklenmi\015f donan'||-
'\0131ma sahip DRAM\0027ye benzer. VRAM\0027nin \00f6zelli\011fi, bu k'||-
'ayd\0131rma yazmac\0131na tek bir saat devrinde t\00fcm bir veri sat'||-
'\0131r\0131n\0131n (en \00e7ok 256 bit) transferini yapabilmesidir. Al'||-
'ma say\0131s\0131 olas\0131 de\011fer olan 256\0027dan tek bir almaya'||-
' indirgendi\011fi i\00e7in bu yetenek, alma s\00fcresini \00f6nemli '||-
'\00f6l\00e7\00fcde azalt\0131r. Veri bellek d\00f6k\00fcm\00fc i'||-
'\00e7in mevcut kayd\0131rma yazmac\0131na sahip olman\0131n ana kazanc'||-
'\0131, bunun ekran\0131 yenilemek i\00e7in veri almak yerine CPU\0027y'||-
'u bo\015faltmas\0131 ve b\00f6ylelikle veri bant geni\015fli\011fini '||-
'iki kat\0131na \00e7\0131karmas\0131d\0131r. Bu nedenle, VRAM\0027ye'||-
' \00e7ift ba\011flant\0131 noktal\0131 oldu\011fu i\00e7in ba\015fv'||-
'urulur. Ancak, kayd\0131rma yazmac\0131 sadece VRAM \00e7ipine bunu kul'||-
'lanmas\0131 i\00e7in \00f6zel talimat verildi\011finde kullan\0131l'||-
'\0131r. Kayd\0131rma yazmac\0131n\0131 kullanacak komut grafik kontrol'||-
'c\00fclerinde yerle\015fiktir.'-
));
INSERT INTO product_descriptions VALUES(1787-
,'TR'-
,UNISTR(-
'CPU D300'-
),UNISTR(-
'\00c7ift CPU @ 300Mhz. Sadece hafif ki\015fisel kullan\0131m veya 5'||-
'\0027ten az e\015fzamanl\0131 kullan\0131c\0131ya sahip dosya sunucul'||-
'ar\0131 i\00e7in. B\00fcy\00fck olas\0131l\0131kla yak\0131nda bu '||-
'\00fcr\00fcn\00fcn modas\0131 ge\00e7ecek.'-
));
INSERT INTO product_descriptions VALUES(2439-
,'TR'-
,UNISTR(-
'CPU D400'-
),UNISTR(-
'\00c7ift CPU @ 400Mhz. \0130yi fiyat/performans oran\0131; orta boyutlu'||-
' LAN dosya sunucular\0131 i\00e7in (en \00e7ok 100 e\015fzamanl\0131 '||-
'kullan\0131c\0131).'-
));
INSERT INTO product_descriptions VALUES(1788-
,'TR'-
,UNISTR(-
'CPU D600'-
),UNISTR(-
'\00c7ift CPU @ 600Mhz. Y\00fcksek teknoloji ve y\00fcksek saat h\0131z'||-
'\0131; \00e7ok y\00fckl\00fc WAN sunucular\0131 i\00e7in (en \00e7o'||-
'k 200 e\015fzamanl\0131 kullan\0131c\0131).'-
));
INSERT INTO product_descriptions VALUES(2375-
,'TR'-
,UNISTR(-
'GP 1024x768'-
),UNISTR(-
'Grafik \0130\015flemci, \00e7\00f6z\00fcn\00fcrl\00fck 1024 X 768 p'||-
'iksel. SPNIX v3.3 ve v4.0 alt\0131ndaki 2B ve 3B uygulama yaz\0131l'||-
'\0131mlar\0131 i\00e7in ola\011fan\00fcst\00fc fiyat/performans. Bu '||-
'tek karttan iki monit\00f6r \00e7al\0131\015ft\0131rarak g\00f6r'||-
'\00fcnt\00fcleme g\00fcc\00fcn\00fcz\00fc iki kat\0131na \00e7'||-
'\0131kartabilirsiniz. \0130ki adet 17 in\00e7 monit\00f6r bir adet 21 '||-
'in\00e7 monit\00f6rden daha \00e7ok ekran alan\0131na sahiptir. Birden'||-
' \00e7ok g\00f6rev y\00fcr\00fcten veya s\0131kl\0131kla birden '||-
'\00e7ok kaynaktan verilere eri\015fen kullan\0131c\0131lar i\00e7in m'||-
'\00fckemmel bir se\00e7enek.'-
));
INSERT INTO product_descriptions VALUES(2411-
,'TR'-
,UNISTR(-
'GP 1280x1024'-
),UNISTR(-
'Grafik \0130\015flemci, \00e7\00f6z\00fcn\00fcrl\00fck 1280 X 1024 '||-
'piksel. Ortalama fiyat, son teknoloji 3B performansa sahip: Saniyede 15 mi'||-
'lyon Gouraud g\00f6lgeli \00fc\00e7gen, kullan\0131c\0131 taraf\0131'||-
'ndan \00f6zelle\015ftirilebilir ayarlara sahip MCAD ve DCC uygulama yaz'||-
'\0131l\0131mlar\0131 i\00e7in en iyi duruma getirilmi\015f 3B s\00fc'||-
'r\00fcc\00fcler. Desteklenen t\00fcm standart \00e7\00f6z\00fcn'||-
'\00fcrl\00fcklerde ger\00e7ek renkleri destekleyen 64MB DDR SDRAM birle'||-
'\015ftirilmi\015f \00e7er\00e7eve arabelle\011fi.'-
));
INSERT INTO product_descriptions VALUES(1769-
,'TR'-
,UNISTR(-
'GP 800x600'-
),UNISTR(-
'Grafik i\015flemci, \00e7\00f6z\00fcn\00fcrl\00fck 800 x 600 piksel.'||-
' Geli\015fmi\015f uygulama yaz\0131l\0131mlar\0131 i\00e7in b\00fcy'||-
'\00fck 2B yetene\011fi veya genel 3B destek isteyen kullan\0131c\0131l'||-
'ar i\00e7in \00e7arp\0131c\0131 bir de\011fer. Son derece karma\015f'||-
'\0131k modellerde ola\011fan\00fcst\00fc performans g\00f6sterir ve m'||-
'\00fc\015fteriye, olu\015fturma s\00fcreci yerine tasar\0131ma odakla'||-
'nmas\0131 i\00e7in zaman kazand\0131r\0131r.'-
));
INSERT INTO product_descriptions VALUES(2049-
,'TR'-
,UNISTR(-
'MB - S300'-
),UNISTR(-
'Ki\015fisel bilgisayar tipi ana kart, 300 Serisi.'-
));
INSERT INTO product_descriptions VALUES(2751-
,'TR'-
,UNISTR(-
'MB - S450'-
),UNISTR(-
'Ki\015fisel bilgisayar tipi ana kart, 450 Serisi.'-
));
INSERT INTO product_descriptions VALUES(3112-
,'TR'-
,UNISTR(-
'MB - S500'-
),UNISTR(-
'Ki\015fisel bilgisayar tipi ana kart, 500 Serisi.'-
));
INSERT INTO product_descriptions VALUES(2752-
,'TR'-
,UNISTR(-
'MB - S550'-
),UNISTR(-
'550 Serisi i\00e7in ki\015fisel bilgisayar tipi ana kart.'-
));
INSERT INTO product_descriptions VALUES(2293-
,'TR'-
,UNISTR(-
'MB - S600'-
),UNISTR(-
'Ana Kart, 600 Serisi.'-
));
INSERT INTO product_descriptions VALUES(3114-
,'TR'-
,UNISTR(-
'MB - S900/650+'-
),UNISTR(-
'Ki\015fisel bilgisayar ana kart\0131, 900 Serisi; 650 ve \00fcst\00fcn'||-
'deki t\00fcm modeller i\00e7in standart ana kart.'-
));
INSERT INTO product_descriptions VALUES(3129-
,'TR'-
,UNISTR(-
'Ses Kart\0131 STD'-
),UNISTR(-
'Ses Kart\0131 - standart s\00fcr\00fcm, MIDI aray\00fcz\00fc, hat gir'||-
'i\015f/\00e7\0131k\0131\015f\0131, d\00fc\015f\00fck empedansl'||-
'\0131 mikrofon giri\015fi.'-
));
INSERT INTO product_descriptions VALUES(3133-
,'TR'-
,UNISTR(-
'G\00f6r\00fcnt\00fc Kart\0131 /32'-
),UNISTR(-
'32MB \00f6nbelle\011fe sahip G\00f6r\00fcnt\00fc Kart\0131.'-
));
INSERT INTO product_descriptions VALUES(2308-
,'TR'-
,UNISTR(-
'G\00f6r\00fcnt\00fc Kart\0131 /E32'-
),UNISTR(-
'32 MB belle\011fe sahip 3-B ELSA G\00f6r\00fcnt\00fc Kart\0131.'-
));
INSERT INTO product_descriptions VALUES(2496-
,'TR'-
,UNISTR(-
'WSP DA-130'-
),UNISTR(-
'Depolama alt birimleri i\00e7in geni\015f depolama i\015flemcisi DA-130'||-
'.'-
));
INSERT INTO product_descriptions VALUES(2497-
,'TR'-
,UNISTR(-
'WSP DA-290'-
),UNISTR(-
'Geni\015f depolama i\015flemcisi (model DA-290).'-
));
INSERT INTO product_descriptions VALUES(3106-
,'TR'-
,UNISTR(-
'KB 101/EN'-
),UNISTR(-
'Standart PC/AT Geli\015ftirilmi\015f Klavye (101/102-Tu\015f). Giri'||-
'\015f yerel ayar\0131: \0130ngilizce (ABD).'-
));
INSERT INTO product_descriptions VALUES(2289-
,'TR'-
,UNISTR(-
'KB 101/ES'-
),UNISTR(-
'Standart PC/AT Geli\015fmi\015f Klavye (101/102-Tu\015f). Giri\015f ye'||-
'rel ayar\0131: \0130spanyolca.'-
));
INSERT INTO product_descriptions VALUES(3110-
,'TR'-
,UNISTR(-
'KB 101/FR'-
),UNISTR(-
'Standart PC/AT Geli\015fmi\015f Klavye (101/102-Tu\015f). Giri\015f ye'||-
'rel ayar\0131: Frans\0131zca.'-
));
INSERT INTO product_descriptions VALUES(3108-
,'TR'-
,UNISTR(-
'KB E/EN'-
),UNISTR(-
'\0130ki ayr\0131 tu\015f alan\0131 olan Ergonomik Klavye, \00e7\0131'||-
'kart\0131labilir say\0131sal tu\015f tak\0131m\0131. Tu\015f d\00fc'||-
'zeni: \0130ngilizce (ABD).'-
));
INSERT INTO product_descriptions VALUES(2058-
,'TR'-
,UNISTR(-
'Fare +WP'-
),UNISTR(-
'Daha rahat yazma ve fare kullan\0131m\0131 i\00e7in fare ve bilek altl'||-
'\0131\011f\0131 birle\015fimi.'-
));
INSERT INTO product_descriptions VALUES(2761-
,'TR'-
,UNISTR(-
'Fare +WP/CL'-
),UNISTR(-
'\015eirket logosu bulunan fare ve bilek altl\0131\011f\0131ndan olu'||-
'\015fan set.'-
));
INSERT INTO product_descriptions VALUES(3117-
,'TR'-
,UNISTR(-
'Fare C/E'-
),UNISTR(-
'Ergonomik, kablosuz fare. Maksimum konfor ve kullan\0131m kolayl\0131'||-
'\011f\0131 sa\011flayan izleme topuyla birlikte.'-
));
INSERT INTO product_descriptions VALUES(2056-
,'TR'-
,UNISTR(-
'Fare Altl\0131\011f\0131 /CL'-
),UNISTR(-
'\015eirket logolu standart fare altl\0131\011f\0131'-
));
INSERT INTO product_descriptions VALUES(2211-
,'TR'-
,UNISTR(-
'Bilek Altl\0131\011f\0131'-
),UNISTR(-
'Klavyeyi kullan\0131rken bileklerinizi desteklemek i\00e7in k\00f6p'||-
'\00fck \015ferit.'-
));
INSERT INTO product_descriptions VALUES(2944-
,'TR'-
,UNISTR(-
'Bilek Altl\0131\011f\0131 /CL'-
),UNISTR(-
'\015eirket logosu bulunan bilek altl\0131\011f\0131'-
));
INSERT INTO product_descriptions VALUES(1742-
,'TR'-
,UNISTR(-
'CD-ROM 500/16x'-
),UNISTR(-
'CD s\00fcr\00fcc\00fc, salt okunur, h\0131z 16x, maksimum kapasite 500'||-
' MB.'-
));
INSERT INTO product_descriptions VALUES(2402-
,'TR'-
,UNISTR(-
'CD-ROM 600/E/24x'-
),UNISTR(-
'600 MB harici 24x h\0131zl\0131 CD-ROM s\00fcr\00fcc\00fc (salt okunu'||-
'r).'-
));
INSERT INTO product_descriptions VALUES(2403-
,'TR'-
,UNISTR(-
'CD-ROM 600/I/24x'-
),UNISTR(-
'600 MB dahili salt okunur CD-ROM s\00fcr\00fcc\00fc, okuma h\0131z'||-
'\0131 24x'-
));
INSERT INTO product_descriptions VALUES(1761-
,'TR'-
,UNISTR(-
'CD-ROM 600/I/32x'-
),UNISTR(-
'600 MB Dahili CD-ROM S\00fcr\00fcc\00fc, h\0131z 32x (salt okunur).'-
));
INSERT INTO product_descriptions VALUES(2381-
,'TR'-
,UNISTR(-
'CD-ROM 8x'-
),UNISTR(-
'CD Yaz\0131c\0131, salt okunur, h\0131z 8x'-
));
INSERT INTO product_descriptions VALUES(2424-
,'TR'-
,UNISTR(-
'CDW 12/24'-
),UNISTR(-
'CD Yaz\0131c\0131, h\0131z 12x yazma, 24x okuma. Uyar\0131: yak\0131n'||-
'da modas\0131 ge\00e7ecek; bu h\0131z art\0131k yeterince y\00fcksek '||-
'de\011fil ve uygun fiyatl\0131 daha iyi alternatifler mevcut.'-
));
INSERT INTO product_descriptions VALUES(1781-
,'TR'-
,UNISTR(-
'CDW 20/48/E'-
),UNISTR(-
'CD Yaz\0131c\0131, okuma 48x, yazma 20x'-
));
INSERT INTO product_descriptions VALUES(2264-
,'TR'-
,UNISTR(-
'CDW 20/48/I'-
),UNISTR(-
'CD-ROM s\00fcr\00fcc\00fc: okuma 20x, yazma 48x (dahili)'-
));
INSERT INTO product_descriptions VALUES(2260-
,'TR'-
,UNISTR(-
'DFD 1.44/3.5'-
),UNISTR(-
'\00c7ift Disket S\00fcr\00fcc\00fc - 1.44 MB - 3.5'-
));
INSERT INTO product_descriptions VALUES(2266-
,'TR'-
,UNISTR(-
'DVD 12x'-
),UNISTR(-
'DVD-ROM s\00fcr\00fcc\00fc: h\0131z 12x'-
));
INSERT INTO product_descriptions VALUES(3077-
,'TR'-
,UNISTR(-
'DVD 8x'-
),UNISTR(-
'DVD - ROM s\00fcr\00fcc\00fc, 8x h\0131z. B\00fcy\00fck olas\0131l'||-
'\0131kla \00e7ok yak\0131nda modas\0131 ge\00e7ecek...'-
));
INSERT INTO product_descriptions VALUES(2259-
,'TR'-
,UNISTR(-
'FD 1.44/3.5'-
),UNISTR(-
'Disket S\00fcr\00fcc\00fc - 1.44 MB Y\00fcksek Yo\011funluklu kapasit'||-
'e - 3.5 in\00e7 ana g\00f6vde'-
));
INSERT INTO product_descriptions VALUES(2261-
,'TR'-
,UNISTR(-
'FD 1.44/3.5/E'-
),UNISTR(-
'Disket s\00fcr\00fcc\00fcs\00fc - 1.44 MB (y\00fcksek yo\011funluklu'||-
') kapasite - 3.5 in\00e7 (harici)'-
));
INSERT INTO product_descriptions VALUES(3082-
,'TR'-
,UNISTR(-
'Modem - 56/90/E'-
),UNISTR(-
'Modem - saniyede 56kb, s.90 PCI Global uyumlu. Harici; 110V g\00fc\00e7 '||-
'kayna\011f\0131 i\00e7in.'-
));
INSERT INTO product_descriptions VALUES(2270-
,'TR'-
,UNISTR(-
'Modem - 56/90/I'-
),UNISTR(-
'Modem - saniyede 56kb, s.90 PCI Global uyumlu. Dahili, standart ana g'||-
'\00f6vde i\00e7in (3.5 in\00e7).'-
));
INSERT INTO product_descriptions VALUES(2268-
,'TR'-
,UNISTR(-
'Modem - 56/H/E'-
),UNISTR(-
'Standart Hayes uyumlu modem - Saniyede 56kb, harici. G\00fc\00e7 kayna'||-
'\011f\0131: 220V.'-
));
INSERT INTO product_descriptions VALUES(3083-
,'TR'-
,UNISTR(-
'Modem - 56/H/I'-
),UNISTR(-
'Standart Hayes modem - Saniyede 56kb, dahili, standart 3.5 in\00e7 ana g'||-
'\00f6vde i\00e7in.'-
));
INSERT INTO product_descriptions VALUES(2374-
,'TR'-
,UNISTR(-
'Modem - C/100'-
),UNISTR(-
'DOCSIS/EURODOCSIS 1.0/1.1 uyumlu harici kablolu modem'-
));
INSERT INTO product_descriptions VALUES(1740-
,'TR'-
,UNISTR(-
'TD 12GB/DAT'-
),UNISTR(-
'Teyp s\00fcr\00fcc\00fc - 12 gb kapasite, DAT format\0131.'-
));
INSERT INTO product_descriptions VALUES(2409-
,'TR'-
,UNISTR(-
'TD 7GB/8'-
),UNISTR(-
'Teyp s\00fcr\00fcc\00fc, 7GB kapasite, 8mm kartu\015f teyp.'-
));
INSERT INTO product_descriptions VALUES(2262-
,'TR'-
,UNISTR(-
'ZIP 100'-
),UNISTR(-
'ZIP S\00fcr\00fcc\00fc, 100 MB kapasite (harici) art\0131 paralel ba'||-
'\011flant\0131 noktal\0131 ba\011flant\0131 i\00e7in kablo'-
));
INSERT INTO product_descriptions VALUES(2522-
,'TR'-
,UNISTR(-
'Pil - EL'-
),UNISTR(-
'Uzun \00f6m\00fcrl\00fc pil, diz\00fcst\00fc bilgisayarlar i\00e7in'-
));
INSERT INTO product_descriptions VALUES(2278-
,'TR'-
,UNISTR(-
'Pil - NiHM'-
),UNISTR(-
'Diz\00fcst\00fc bilgisayarlar i\00e7in yeniden \015farj edilebilir NiH'||-
'M pil'-
));
INSERT INTO product_descriptions VALUES(2418-
,'TR'-
,UNISTR(-
'Yedek Pil (DA-130)'-
),UNISTR(-
'LED g\00f6stergeleri bulunan tek pil \015farj cihaz\0131'-
));
INSERT INTO product_descriptions VALUES(2419-
,'TR'-
,UNISTR(-
'Yedek Pil (DA-290)'-
),UNISTR(-
'LED g\00f6stergeleri bulunan ikili pil \015farj cihaz\0131'-
));
INSERT INTO product_descriptions VALUES(3097-
,'TR'-
,UNISTR(-
'Kablo Ba\011flay\0131c\0131s\0131 - 32R'-
),UNISTR(-
'Kablo Ba\011flay\0131c\0131s\0131 - 32 pin \015ferit'-
));
INSERT INTO product_descriptions VALUES(3099-
,'TR'-
,UNISTR(-
'Kablo Grubu'-
),UNISTR(-
'Bilgisayar kablolar\0131n\0131 d\00fczenlemek ve toplamak i\00e7in kab'||-
'lo grubu'-
));
INSERT INTO product_descriptions VALUES(2380-
,'TR'-
,UNISTR(-
'Kablo PR/15/P'-
),UNISTR(-
'4,56 m paralel yaz\0131c\0131 kablosu'-
));
INSERT INTO product_descriptions VALUES(2408-
,'TR'-
,UNISTR(-
'Kablo PR/P/6'-
),UNISTR(-
'Standart Centronics 1,824 m yaz\0131c\0131 kablosu, paralel ba\011flant'||-
'\0131 noktas\0131'-
));
INSERT INTO product_descriptions VALUES(2457-
,'TR'-
,UNISTR(-
'Kablo PR/S/6'-
),UNISTR(-
'Standart RS232 seri yaz\0131c\0131 kablosu, 1,824 m'-
));
INSERT INTO product_descriptions VALUES(2373-
,'TR'-
,UNISTR(-
'Kablo RS232 10/AF'-
),UNISTR(-
'F/F ve 9F/25F adapt\00f6rleri bulunan 3,04 m RS232 kablo'-
));
INSERT INTO product_descriptions VALUES(1734-
,'TR'-
,UNISTR(-
'Kablo RS232 10/AM'-
),UNISTR(-
'M/M ve 9M/25M adapt\00f6rleri bulunan 3,04 m RS232 kablo'-
));
INSERT INTO product_descriptions VALUES(1737-
,'TR'-
,UNISTR(-
'Kablo SCSI 10/FW/ADS'-
),UNISTR(-
'DSxx0 Kablo i\00e7in 3,04 m SCSI2 F/W Adapt\00f6r'-
));
INSERT INTO product_descriptions VALUES(1745-
,'TR'-
,UNISTR(-
'Kablo SCSI 20/WD->D'-
),UNISTR(-
'6,08 m SCSI2 Geni\015f Disk Deposundan Disk Deposuna Kablo'-
));
INSERT INTO product_descriptions VALUES(2982-
,'TR'-
,UNISTR(-
'S\00fcr\00fcc\00fc Montaj\0131 - A'-
),UNISTR(-
'S\00fcr\00fcc\00fc Montaj\0131 montaj seti'-
));
INSERT INTO product_descriptions VALUES(3277-
,'TR'-
,UNISTR(-
'S\00fcr\00fcc\00fc Montaj\0131 - A/T'-
),UNISTR(-
'Y\00fcksek kasal\0131 ki\015fisel bilgisayar i\00e7in S\00fcr\00fcc'||-
'\00fc Montaj\0131 montaj seti'-
));
INSERT INTO product_descriptions VALUES(2976-
,'TR'-
,UNISTR(-
'S\00fcr\00fcc\00fc Montaj\0131 - D'-
),UNISTR(-
'Masa\00fcst\00fc ki\015fisel bilgisayar i\00e7in S\00fcr\00fcc\00fc'||-
' Montaj\0131'-
));
INSERT INTO product_descriptions VALUES(3204-
,'TR'-
,UNISTR(-
'Envoy DS'-
),UNISTR(-
'Envoy Takma Birimi'-
));
INSERT INTO product_descriptions VALUES(2638-
,'TR'-
,UNISTR(-
'Envoy DS/E'-
),UNISTR(-
'Geli\015fmi\015f Envoy Takma Birimi'-
));
INSERT INTO product_descriptions VALUES(3020-
,'TR'-
,UNISTR(-
'Envoy IC'-
),UNISTR(-
'Envoy Internet Bilgisayar\0131, Tak ve Kullan'-
));
INSERT INTO product_descriptions VALUES(1948-
,'TR'-
,UNISTR(-
'Envoy IC/58'-
),UNISTR(-
'Yerle\015fik 58K modeme sahip Internet bilgisayar\0131'-
));
INSERT INTO product_descriptions VALUES(3003-
,'TR'-
,UNISTR(-
'Diz\00fcst\00fc 128/12/56/v90/110'-
),UNISTR(-
'Envoy Diz\00fcst\00fc, 128MB bellek, 12GB sabit disk, v90 modem, 110V g'||-
'\00fc\00e7 kayna\011f\0131.'-
));
INSERT INTO product_descriptions VALUES(2999-
,'TR'-
,UNISTR(-
'Diz\00fcst\00fc 16/8/110'-
),UNISTR(-
'Envoy Diz\00fcst\00fc, 16MB bellek, 8GB sabit disk, 110V g\00fc\00e7 k'||-
'ayna\011f\0131 (sadece ABD).'-
));
INSERT INTO product_descriptions VALUES(3000-
,'TR'-
,UNISTR(-
'Diz\00fcst\00fc 32/10/56'-
),UNISTR(-
'Envoy Diz\00fcst\00fc, 32MB bellek, 10GB sabit disk, 56K Modem, evrensel'||-
' g\00fc\00e7 kayna\011f\0131 (de\011fi\015ftirilebilir).'-
));
INSERT INTO product_descriptions VALUES(3001-
,'TR'-
,UNISTR(-
'Diz\00fcst\00fc 48/10/56/110'-
),UNISTR(-
'Envoy Diz\00fcst\00fc, 48MB bellek, 10GB sabit disk, 56K modem, 110V g'||-
'\00fc\00e7 kayna\011f\0131.'-
));
INSERT INTO product_descriptions VALUES(3004-
,'TR'-
,UNISTR(-
'Diz\00fcst\00fc 64/10/56/220'-
),UNISTR(-
'Envoy Diz\00fcst\00fc, 64MB bellek, 10GB sabit disk, 56K modem, 220V g'||-
'\00fc\00e7 kayna\011f\0131.'-
));
INSERT INTO product_descriptions VALUES(3391-
,'TR'-
,UNISTR(-
'PS 110/220'-
),UNISTR(-
'G\00fc\00e7 Kayna\011f\0131 - de\011fi\015ftirilebilir, 110V/220V'-
));
INSERT INTO product_descriptions VALUES(3124-
,'TR'-
,UNISTR(-
'PS 110V /T'-
),UNISTR(-
'Y\00fcksek Kasal\0131 ki\015fisel bilgisayar i\00e7in g\00fc\00e7 ka'||-
'yna\011f\0131, 110V'-
));
INSERT INTO product_descriptions VALUES(1738-
,'TR'-
,UNISTR(-
'PS 110V /US'-
),UNISTR(-
'110 V G\00fc\00e7 Kayna\011f\0131 - ABD uyumlu'-
));
INSERT INTO product_descriptions VALUES(2377-
,'TR'-
,UNISTR(-
'PS 110V HS/US'-
),UNISTR(-
'110 V do\011frudan transfer edilebilir g\00fc\00e7 kayna\011f\0131 - '||-
'ABD uyumlu'-
));
INSERT INTO product_descriptions VALUES(2299-
,'TR'-
,UNISTR(-
'PS 12V /P'-
),UNISTR(-
'G\00fc\00e7 Kayna\011f\0131 - 12v ta\015f\0131nabilir'-
));
INSERT INTO product_descriptions VALUES(3123-
,'TR'-
,UNISTR(-
'PS 220V /D'-
),UNISTR(-
'Standart g\00fc\00e7 kayna\011f\0131, 220V, masa\00fcst\00fc bilgisa'||-
'yarlar i\00e7in.'-
));
INSERT INTO product_descriptions VALUES(1748-
,'TR'-
,UNISTR(-
'PS 220V /EUR'-
),UNISTR(-
'220 Volt G\00fc\00e7 kayna\011f\0131 tipi - Avrupa'-
));
INSERT INTO product_descriptions VALUES(2387-
,'TR'-
,UNISTR(-
'PS 220V /FR'-
),UNISTR(-
'220V G\00fc\00e7 kayna\011f\0131 tipi - Fransa'-
));
INSERT INTO product_descriptions VALUES(2370-
,'TR'-
,UNISTR(-
'PS 220V /HS/FR'-
),UNISTR(-
'220V do\011frudan de\011fi\015ftirilebilir g\00fc\00e7 kayna\011f'||-
'\0131, Fransa i\00e7in.'-
));
INSERT INTO product_descriptions VALUES(2311-
,'TR'-
,UNISTR(-
'PS 220V /L'-
),UNISTR(-
'Diz\00fcst\00fc bilgisayarlar i\00e7in g\00fc\00e7 kayna\011f\0131,'||-
' 220V'-
));
INSERT INTO product_descriptions VALUES(1733-
,'TR'-
,UNISTR(-
'PS 220V /UK'-
),UNISTR(-
'220V G\00fc\00e7 kayna\011f\0131 tipi - \0130ngiltere'-
));
INSERT INTO product_descriptions VALUES(2878-
,'TR'-
,UNISTR(-
'Y\00f6nlendirici - ASR/2W'-
),UNISTR(-
'\00d6zel ALS Y\00f6nlendirici - 2 y\00f6nl\00fc e\015fle\015fmeli, o'||-
'nayl\0131 Tedarik\00e7i gerektiren \00f6\011fe'-
));
INSERT INTO product_descriptions VALUES(2879-
,'TR'-
,UNISTR(-
'Y\00f6nlendirici - ASR/3W'-
),UNISTR(-
'\00d6zel ALS Y\00f6nlendirici - 3 y\00f6nl\00fc e\015fle\015fmeli, o'||-
'nayl\0131 Tedarik\00e7i gerektiren \00f6\011fe'-
));
INSERT INTO product_descriptions VALUES(2152-
,'TR'-
,UNISTR(-
'Y\00f6nlendirici - DTMF4'-
),UNISTR(-
'DTMF 4 ba\011flant\0131 noktas\0131 y\00f6nlendiricisi'-
));
INSERT INTO product_descriptions VALUES(3301-
,'TR'-
,UNISTR(-
'Vidalar <B.28.P>'-
),UNISTR(-
'Vidalar: Pirin\00e7, boyut 28mm, Phillips kafa. Plastik kutu, adet 500.'-
));
INSERT INTO product_descriptions VALUES(3143-
,'TR'-
,UNISTR(-
'Vidalar <B.28.S>'-
),UNISTR(-
'Vidalar: Pirin\00e7, boyut 28mm, d\00fcz. Plastik kutu, adet 500.'-
));
INSERT INTO product_descriptions VALUES(2323-
,'TR'-
,UNISTR(-
'Vidalar <B.32.P>'-
),UNISTR(-
'Vidalar: Pirin\00e7, boyut 32mm, Phillips kafa. Plastik kutu, adet 400.'-
));
INSERT INTO product_descriptions VALUES(3134-
,'TR'-
,UNISTR(-
'Vidalar <B.32.S>'-
),UNISTR(-
'Vidalar: Pirin\00e7, boyut 32mm, d\00fcz. Plastik kutu, adet 400.'-
));
INSERT INTO product_descriptions VALUES(3139-
,'TR'-
,UNISTR(-
'Vidalar <S.16.S>'-
),UNISTR(-
'Vidalar: \00c7elik, boyut 16mm, d\00fcz. Karton kutu, adet 750.'-
));
INSERT INTO product_descriptions VALUES(3300-
,'TR'-
,UNISTR(-
'Vidalar <S.32.P>'-
),UNISTR(-
'Vidalar: \00c7elik, boyut 32mm, Phillips kafa. Plastik kutu, adet 400.'-
));
INSERT INTO product_descriptions VALUES(2316-
,'TR'-
,UNISTR(-
'Vidalar <S.32.S>'-
),UNISTR(-
'Vidalar: \00c7elik, boyut 32mm, d\00fcz. Plastik kutu, adet 500.'-
));
INSERT INTO product_descriptions VALUES(3140-
,'TR'-
,UNISTR(-
'Vidalar <Z.16.S>'-
),UNISTR(-
'Vidalar: \00c7inko, boy 16mm, d\00fcz. Karton kutu, adet 750.'-
));
INSERT INTO product_descriptions VALUES(2319-
,'TR'-
,UNISTR(-
'Vidalar <Z.24.S>'-
),UNISTR(-
'Vidalar: \00c7inko, boyut 24mm, d\00fcz. Karton kutu, adet 500.'-
));
INSERT INTO product_descriptions VALUES(2322-
,'TR'-
,UNISTR(-
'Vidalar <Z.28.P>'-
),UNISTR(-
'Vidalar: \00c7inko, boyut 28mm, Philips kafa. Karton kutu, adet 850.'-
));
INSERT INTO product_descriptions VALUES(3178-
,'TR'-
,UNISTR(-
'Elektronik Tablo - SSP/V 2.0'-
),UNISTR(-
'SmartSpread Elektronik Tablo, Profesyonel S\00fcr\00fcm, S\00fcr\00fcm'||-
' 2.0, Vision S\00fcr\00fcm 11.1 ve 11.2 i\00e7in. Korumal\0131 ambalaj'||-
' i\00e7inde geli\015fmi\015f yaz\0131l\0131m ve online dok\00fcmanta'||-
'syonun bulundu\011fu CD-ROM\0027a ek olarak bas\0131l\0131 kullan'||-
'\0131m k\0131lavuzu, \00f6\011fretici k\0131lavuz ve lisans kayd'||-
'\0131 yer al\0131r.'-
));
INSERT INTO product_descriptions VALUES(3179-
,'TR'-
,UNISTR(-
'Elektronik Tablo - SSS/S 2.1'-
),UNISTR(-
'SmartSpread Elektronik Tablo, Standart S\00fcr\00fcm 2.1, SPNIX S\00fcr'||-
'\00fcm 4.0 i\00e7in. Korumal\0131 ambalaj i\00e7inde yaz\0131l\0131m'||-
' ve online dok\00fcmantasyonun bulundu\011fu CD-ROM\0027a ek olarak bas'||-
'\0131l\0131 kullan\0131m k\0131lavuzu ve lisans kayd\0131 yer al'||-
'\0131r.'-
));
INSERT INTO product_descriptions VALUES(3182-
,'TR'-
,UNISTR(-
'S\00f6zc\00fck \0130\015fleme - SWP/V 4.5'-
),UNISTR(-
'SmartWord S\00f6zc\00fck \0130\015flemci, Profesyonel S\00fcr\00fcm '||-
'4.5, Vision S\00fcr\00fcm 11.x i\00e7in. Korumal\0131 ambalaj i\00e7i'||-
'nde geli\015fmi\015f yaz\0131l\0131m i\00e7eren CD-ROM, bas\0131l'||-
'\0131 kullan\0131m k\0131lavuzu ve lisans kayd\0131 yer al\0131r.'-
));
INSERT INTO product_descriptions VALUES(3183-
,'TR'-
,UNISTR(-
'S\00f6zc\00fck \0130\015fleme - SWS/V 4.5'-
),UNISTR(-
'SmartWord S\00f6zc\00fck \0130\015flemci, Standart S\00fcr\00fcm 4.5'||-
', Vision S\00fcr\00fcm 11.x i\00e7in. Korumal\0131 ambalaj i\00e7inde'||-
' CD-ROM ve lisans kayd\0131 bulunur.'-
));
INSERT INTO product_descriptions VALUES(3197-
,'TR'-
,UNISTR(-
'Elektronik Tablo - SSS/V 2.1'-
),UNISTR(-
'SmartSpread Elektronik Tablo, Standart S\00fcr\00fcm 2.1, Vision S\00fc'||-
'r\00fcm 11.1 ve 11.2 i\00e7in. Korumal ambalaj i\00e7inde yaz\0131l'||-
'\0131m ve online dok\00fcmantasyonun bulundu\011fu CD-ROM\0027a ek ola'||-
'rak bas\0131l\0131 kullan\0131m k\0131lavuzu, \00f6\011fretici k'||-
'\0131lavuz ve lisans kayd\0131 yer al\0131r.'-
));
INSERT INTO product_descriptions VALUES(3255-
,'TR'-
,UNISTR(-
'Elektronik Tablo - SSS/CD 2.2B'-
),UNISTR(-
'SmartSpread Elektronik Tablo, Standart Beta S\00fcr\00fcm\00fc 2.2, SPN'||-
'IX S\00fcr\00fcm 4.1 i\00e7in. Sadece CD-ROM.'-
));
INSERT INTO product_descriptions VALUES(3256-
,'TR'-
,UNISTR(-
'Elektronik Tablo - SSS/V 2.0'-
),UNISTR(-
'SmartSpread Elektronik Tablo, Standart S\00fcr\00fcm 2.0, Vision S\00fc'||-
'r\00fcm 11.0. Korumal\0131 ambalaj i\00e7inde yaz\0131l\0131m ve onli'||-
'ne dok\00fcmantasyonun bulundu\011fu CD-ROM\0027a ek olarak bas\0131l'||-
'\0131 kullan\0131m k\0131lavuzu, \00f6\011fretici k\0131lavuz ve lis'||-
'ans kayd\0131 yer al\0131r.'-
));
INSERT INTO product_descriptions VALUES(3260-
,'TR'-
,UNISTR(-
'S\00f6zc\00fck \0130\015fleme - SWP/S 4.4'-
),UNISTR(-
'SmartSpread Elektronik Tablo, Standart S\00fcr\00fcm 2.2, SPNIX S\00fcr'||-
'\00fcm 4.x i\00e7in. Korumal\0131 ambalaj i\00e7inde yaz\0131l\0131m'||-
'\0131n bulundu\011fu CD-ROM\0027a ek olarak bas\0131l\0131 kullan'||-
'\0131m k\0131lavuzu ve lisans kayd\0131 yer al\0131r.'-
));
INSERT INTO product_descriptions VALUES(3262-
,'TR'-
,UNISTR(-
'Elektronik Tablo - SSS/S 2.2'-
),UNISTR(-
'SmartSpread Elektronik Tablo, Standart S\00fcr\00fcm 2.2, SPNIX S\00fcr'||-
'\00fcm 4.1 i\00e7in. Korumal\0131 ambalaj i\00e7inde yaz\0131l\0131m'||-
' ve online dok\00fcmantasyonun bulundu\011fu CD-ROM\0027a ek olarak bas'||-
'\0131l\0131 kullan\0131m k\0131lavuzu ve lisans kayd\0131 yer al'||-
'\0131r.'-
));
INSERT INTO product_descriptions VALUES(3361-
,'TR'-
,UNISTR(-
'Elektronik Tablo - SSP/S 1.5'-
),UNISTR(-
'SmartSpread Elektronik Tablo, Standart S\00fcr\00fcm 1.5, SPNIX S\00fcr'||-
'\00fcm 3.3 i\00e7in. Korumal\0131 ambalaj i\00e7inde geli\015fmi'||-
'\015f yaz\0131l\0131m ve online dok\00fcmantasyonun bulundu\011fu CD-'||-
'ROM\0027a ek olarak bas\0131l\0131 kullan\0131m k\0131lavuzu, \00f6'||-
'\011fretici k\0131lavuz ve lisans kayd\0131 yer al\0131r.'-
));
INSERT INTO product_descriptions VALUES(1799-
,'TR'-
,UNISTR(-
'SPNIX3.3 - SL'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V3.3 - Ana Sunucu'||-
' Lisans\0131. Sistem y\00f6netimi, geli\015ftiriciler veya kullan\0131'||-
'c\0131lar i\00e7in 10 genel lisans i\00e7erir. A\011f kullan\0131c'||-
'\0131s\0131 lisans\0131 bulunmaz.'-
));
INSERT INTO product_descriptions VALUES(1801-
,'TR'-
,UNISTR(-
'SPNIX3.3 - AL'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V3.3 - A\011f er'||-
'i\015fimi dahil olmak \00fczere, ek sistem y\00f6neticisi lisans\0131.'-
));
INSERT INTO product_descriptions VALUES(1803-
,'TR'-
,UNISTR(-
'SPNIX3.3 - DL'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V3.3 - Ek geli'||-
'\015ftirici lisans\0131.'-
));
INSERT INTO product_descriptions VALUES(1804-
,'TR'-
,UNISTR(-
'SPNIX3.3 - UL/N'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V3.3 - A\011f er'||-
'i\015fimine sahip ek kullan\0131c\0131 lisans\0131.'-
));
INSERT INTO product_descriptions VALUES(1805-
,'TR'-
,UNISTR(-
'SPNIX3.3 - UL/A'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V3.3 - A s\0131n'||-
'\0131f\0131 ek kullan\0131c\0131 lisans\0131.'-
));
INSERT INTO product_descriptions VALUES(1806-
,'TR'-
,UNISTR(-
'SPNIX3.3 - UL/C'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V3.3 - C s\0131n'||-
'\0131f\0131 ek kullan\0131c\0131 lisans\0131.'-
));
INSERT INTO product_descriptions VALUES(1808-
,'TR'-
,UNISTR(-
'SPNIX3.3 - UL/D'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V3.3 - D s\0131n'||-
'\0131f\0131 ek kullan\0131c\0131 lisans\0131.'-
));
INSERT INTO product_descriptions VALUES(1820-
,'TR'-
,UNISTR(-
'SPNIX3.3 - NL'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V3.3 - Ek a\011f'||-
' eri\015fimi lisans\0131.'-
));
INSERT INTO product_descriptions VALUES(1822-
,'TR'-
,UNISTR(-
'SPNIX4.0 - SL'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V4.0 - Ana Sunucu'||-
' Lisans\0131. Sistem y\00f6netimi, geli\015ftiriciler veya kullan\0131'||-
'c\0131lar i\00e7in 10 general lisans i\00e7erir. A\011f kullan\0131c'||-
'\0131 lisans\0131 yok.'-
));
INSERT INTO product_descriptions VALUES(2422-
,'TR'-
,UNISTR(-
'SPNIX4.0 - SAL'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V4.0 - A\011f er'||-
'i\015fimi dahil olmak \00fczere, ek sistem y\00f6neticisi lisans\0131.'-
));
INSERT INTO product_descriptions VALUES(2452-
,'TR'-
,UNISTR(-
'SPNIX4.0 - DL'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V4.0 - Ek geli'||-
'\015ftirici lisans\0131.'-
));
INSERT INTO product_descriptions VALUES(2462-
,'TR'-
,UNISTR(-
'SPNIX4.0 - UL/N'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V4.0 - A\011f er'||-
'i\015fimi olan ek kullan\0131c\0131 lisans\0131.'-
));
INSERT INTO product_descriptions VALUES(2464-
,'TR'-
,UNISTR(-
'SPNIX4.0 - UL/A'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V4.0 - A s\0131n'||-
'\0131f\0131 ek kullan\0131c\0131 lisans\0131.'-
));
INSERT INTO product_descriptions VALUES(2467-
,'TR'-
,UNISTR(-
'SPNIX4.0 - UL/D'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V4.0 - D s\0131n'||-
'\0131f\0131 ek kullan\0131c\0131 lisans\0131.'-
));
INSERT INTO product_descriptions VALUES(2468-
,'TR'-
,UNISTR(-
'SPNIX4.0 - UL/C'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V4.0 - C s\0131n'||-
'\0131f\0131 ek kullan\0131c\0131 lisans\0131.'-
));
INSERT INTO product_descriptions VALUES(2470-
,'TR'-
,UNISTR(-
'SPNIX4.0 - NL'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V4.0 - Ek a\011f'||-
' eri\015fimi lisans\0131.'-
));
INSERT INTO product_descriptions VALUES(2471-
,'TR'-
,UNISTR(-
'SPNIX3.3 SU'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V3.3 - V4.0\0027'||-
'a Y\00fckseltilmi\015f Ana Sunucu Lisans\0131.'-
));
INSERT INTO product_descriptions VALUES(2492-
,'TR'-
,UNISTR(-
'SPNIX3.3 AU'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V3.3 - V4.0 y'||-
'\00fckseltmesi; A s\0131n\0131f\0131 kullan\0131c\0131.'-
));
INSERT INTO product_descriptions VALUES(2493-
,'TR'-
,UNISTR(-
'SPNIX3.3 C/DU'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V3.3 - V4.0 y'||-
'\00fckseltmesi; C veya D s\0131n\0131f\0131 kullan\0131c\0131.'-
));
INSERT INTO product_descriptions VALUES(2494-
,'TR'-
,UNISTR(-
'SPNIX3.3 NU'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V3.3 - V4.0 y'||-
'\00fckseltmesi; a\011f eri\015fimi lisans\0131.'-
));
INSERT INTO product_descriptions VALUES(2995-
,'TR'-
,UNISTR(-
'SPNIX3.3 SAU'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V3.3 - V4.0 y'||-
'\00fckseltmesi; sistem y\00f6neticisi lisans\0131'-
));
INSERT INTO product_descriptions VALUES(3290-
,'TR'-
,UNISTR(-
'SPNIX3.3 DU'-
),UNISTR(-
'\0130\015fletim Sistemi Yaz\0131l\0131m\0131: SPNIX V3.3 - V4.0 y'||-
'\00fckseltmesi; geli\015ftirici lisans\0131.'-
));
INSERT INTO product_descriptions VALUES(1778-
,'TR'-
,UNISTR(-
'SPNIX3.3 i\00e7in C - 1 Tek Lisans'-
),UNISTR(-
'SPNIX V3.3 i\00e7in C programlama yaz\0131l\0131m\0131 - tek kullan'||-
'\0131c\0131'-
));
INSERT INTO product_descriptions VALUES(1779-
,'TR'-
,UNISTR(-
'SPNIX3.3 i\00e7in C- Dok\00fcmantasyon'-
),UNISTR(-
'C programlama dili dok\00fcmantasyonu, SPNIX V3.3'-
));
INSERT INTO product_descriptions VALUES(1780-
,'TR'-
,UNISTR(-
'SPNIX3.3 i\00e7in C- Sistem'-
),UNISTR(-
'SPNIX V3.3 i\00e7in C programlama yaz\0131l\0131m\0131 - sistem derley'||-
'ici, kitapl\0131klar, ba\011flay\0131c\0131'-
));
INSERT INTO product_descriptions VALUES(2371-
,'TR'-
,UNISTR(-
'SPNIX4.0 i\00e7in C - Dok\00fcmantasyon'-
),UNISTR(-
'C programlama dili dok\00fcmantasyonu, SPNIX V4.0'-
));
INSERT INTO product_descriptions VALUES(2423-
,'TR'-
,UNISTR(-
'SPNIX4.0 i\00e7in C - 1 Tek Lisans'-
),UNISTR(-
'SPNIX V4.0 i\00e7in C programlama yaz\0131l\0131m\0131 - tek kullan'||-
'\0131c\0131'-
));
INSERT INTO product_descriptions VALUES(3501-
,'TR'-
,UNISTR(-
'SPNIX4.0 i\00e7in C - Sistem'-
),UNISTR(-
'SPNIX V4.0 i\00e7in programlama yaz\0131l\0131m\0131 - sistem derleyic'||-
'isi, kitapl\0131klar, ba\011flay\0131c\0131'-
));
INSERT INTO product_descriptions VALUES(3502-
,'TR'-
,UNISTR(-
'SPNIX3.3 i\00e7in C-Sistem/Y\00fckseltme'-
),UNISTR(-
'SPNIX V3.3 i\00e7in C programlama yaz\0131l\0131m\0131 - 4.0 Y\00fcks'||-
'eltmesi; sistem derleyicisi, kitapl\0131klar, ba\011flay\0131c\0131'-
));
INSERT INTO product_descriptions VALUES(3503-
,'TR'-
,UNISTR(-
'SPNIX3.3 i\00e7in C - Tek Lisans/Y'-
),UNISTR(-
'SPNIX V3.3 i\00e7in C programlama yaz\0131l\0131m\0131 - 4.0 Y\00fcks'||-
'eltme - tek kullan\0131c\0131'-
));
INSERT INTO product_descriptions VALUES(1774-
,'TR'-
,UNISTR(-
'Ana ISO CP - BL'-
),UNISTR(-
'Ana ISO \0130leti\015fim Paketi - Ana Lisans'-
));
INSERT INTO product_descriptions VALUES(1775-
,'TR'-
,UNISTR(-
'\0130stemci ISO CP - S'-
),UNISTR(-
'Ek SPNIX V3.3 istemcisi i\00e7in ISO \0130leti\015fim Paketi eklenti li'||-
'sans\0131.'-
));
INSERT INTO product_descriptions VALUES(1794-
,'TR'-
,UNISTR(-
'OSI 8-16/IL'-
),UNISTR(-
'OSI Katman 8 - 16 - Art\0131\015fl\0131 Lisans'-
));
INSERT INTO product_descriptions VALUES(1825-
,'TR'-
,UNISTR(-
'X25 - 1 Hat Lisans\0131'-
),UNISTR(-
'X25 a\011f eri\015fimi kontrol sistemi, tek kullan\0131c\0131'-
));
INSERT INTO product_descriptions VALUES(2004-
,'TR'-
,UNISTR(-
'IC G\00f6zat\0131c\0131 - S'-
),UNISTR(-
'SPNIX i\00e7in IC Web G\00f6zat\0131c\0131s\0131. a\011f postas'||-
'\0131 yetene\011fine sahip g\00f6zat\0131c\0131.'-
));
INSERT INTO product_descriptions VALUES(2005-
,'TR'-
,UNISTR(-
'IC G\00f6zat\0131c\0131 Dok\00fcmantasyonu - S'-
),UNISTR(-
'SPNIX i\00e7in IC Web G\00f6zat\0131c\0131s\0131\0027na ait dok'||-
'\00fcmantasyon seti. Kurulum K\0131lavuzu, Posta Sunucusu Y\00f6netim K'||-
'\0131lavuzu ve Kullan\0131c\0131 H\0131zl\0131 Ba\015fvurusu bulunur'||-
'.'-
));
INSERT INTO product_descriptions VALUES(2416-
,'TR'-
,UNISTR(-
'\0130stemci ISO CP - S'-
),UNISTR(-
'Ek SPNIX V4.0 istemcisi i\00e7in ISO \0130leti\015fim Paketi eklenti li'||-
'sans\0131.'-
));
INSERT INTO product_descriptions VALUES(2417-
,'TR'-
,UNISTR(-
'\0130stemci ISO CP - V'-
),UNISTR(-
'Ek Vision istemcisi i\00e7in ISO \0130leti\015fim Paketi eklenti lisans'||-
'\0131.'-
));
INSERT INTO product_descriptions VALUES(2449-
,'TR'-
,UNISTR(-
'OSI 1-4/IL'-
),UNISTR(-
'OSI Katman\0131 1 - 4 - Art\0131\015fl\0131 Lisans'-
));
INSERT INTO product_descriptions VALUES(3101-
,'TR'-
,UNISTR(-
'IC G\00f6zat\0131c\0131 - V'-
),UNISTR(-
'Vision i\00e7in manuelli IC Web G\00f6zat\0131c\0131s\0131. A\011f p'||-
'ostas\0131 yetene\011fi olan g\00f6zat\0131c\0131.'-
));
INSERT INTO product_descriptions VALUES(3170-
,'TR'-
,UNISTR(-
'Smart Suite - V/SP'-
),UNISTR(-
'Vision i\00e7in Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBro'||-
'wse). \0130spanyolca yaz\0131l\0131m ve kullan\0131c\0131 manuelleri.'-
));
INSERT INTO product_descriptions VALUES(3171-
,'TR'-
,UNISTR(-
'Smart Suite - S3.3/EN'-
),UNISTR(-
'SPNIX S\00fcr\00fcm 3.3 i\00e7in Office Suite (SmartWrite, SmartArt, Sm'||-
'artSpread, SmartBrowse). \0130ngilizce yaz\0131l\0131m ve kullan\0131c'||-
'\0131 manuelleri.'-
));
INSERT INTO product_descriptions VALUES(3172-
,'TR'-
,UNISTR(-
'Grafikler - DIK+'-
),UNISTR(-
'Yaz\0131l\0131m Seti Grafikleri: Draw-It Kwik-Plus. 3-B nesne idaresi, d'||-
'e\011fi\015fken g\00f6lgeleme ve uzat\0131lm\0131\015f karakter yaz'||-
'\0131 tipleri i\00e7in yayg\0131n k\00fc\00e7\00fck resim dosyalar'||-
'\0131 ve geli\015fmi\015f \00e7izim ara\00e7lar\0131 i\00e7erir.'-
));
INSERT INTO product_descriptions VALUES(3173-
,'TR'-
,UNISTR(-
'Garfikler - SA'-
),UNISTR(-
'Yaz\0131l\0131m Seti Grafikleri: SmartArt. SPNIX i\00e7in birden \00e7'||-
'ok sat\0131r stiline, desene, yerle\015fik \015fekillere ve yayg\0131n'||-
' sembollere sahip profesyonel grafik paketleri.'-
));
INSERT INTO product_descriptions VALUES(3175-
,'TR'-
,UNISTR(-
'Proje Y\00f6netimi - S4.0'-
),UNISTR(-
'SPNIX V4.0 i\00e7in Proje Y\00f6netimi Yaz\0131l\0131m\0131. Yaz'||-
'\0131l\0131m, komut sat\0131r\0131 ve metin, grafik, elektronik tablo '||-
've \00f6zelle\015ftirilebilir rapor formatlar\0131 olan grafik aray'||-
'\00fcz\00fc i\00e7erir.'-
));
INSERT INTO product_descriptions VALUES(3176-
,'TR'-
,UNISTR(-
'Smart Suite - V/EN'-
),UNISTR(-
'Vision i\00e7in Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBro'||-
'wse). \0130ngilizce yaz\0131l\0131m ve kullan\0131c\0131 manuelleri.'-
));
INSERT INTO product_descriptions VALUES(3177-
,'TR'-
,UNISTR(-
'Smart Suite - V/FR'-
),UNISTR(-
'Vision i\00e7in Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBro'||-
'wse). Frans\0131zca yaz\0131l\0131m ve kullan\0131c\0131 manuelleri'-
));
INSERT INTO product_descriptions VALUES(3245-
,'TR'-
,UNISTR(-
'Smart Suite - S4.0/FR'-
),UNISTR(-
'SPNIX V4.0 i\00e7in Office Suite (SmartWrite, SmartArt, SmartSpread, Smar'||-
'tBrowse). Frans\0131zca yaz\0131l\0131m ve kullan\0131c\0131 manuelle'||-
'ri.'-
));
INSERT INTO product_descriptions VALUES(3246-
,'TR'-
,UNISTR(-
'Smart Suite - S4.0/SP'-
),UNISTR(-
'SPNIX V4.0 i\00e7in Office Suite (SmartWrite, SmartArt, SmartSpread, Smar'||-
'tBrowse). \0130spanyolca yaz\0131l\0131m ve kullan\0131c\0131 manuell'||-
'eri.'-
));
INSERT INTO product_descriptions VALUES(3247-
,'TR'-
,UNISTR(-
'Smart Suite - V/DE'-
),UNISTR(-
'Vision i\00e7in Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBro'||-
'wse). Almanca yaz\0131l\0131m ve kullan\0131c\0131 manuelleri.'-
));
INSERT INTO product_descriptions VALUES(3248-
,'TR'-
,UNISTR(-
'Smart Suite - S4.0/DE'-
),UNISTR(-
'SPNIX V4.0 i\00e7in Office Suite (SmartWrite, SmartArt, SmartSpread, Smar'||-
'tBrowse). Almanca yaz\0131l\0131m ve kullan\0131c\0131 manuelleri.'-
));
INSERT INTO product_descriptions VALUES(3250-
,'TR'-
,UNISTR(-
'Grafikler - DIK'-
),UNISTR(-
'Yaz\0131l\0131m Seti Grafikleri: Draw-It Kwik. GIF, JPG ve BMP formatlar'||-
'\0131nda kaydetme se\00e7enekleri bulunan Vision sistemleri i\00e7in ba'||-
'sit grafik paketi.'-
));
INSERT INTO product_descriptions VALUES(3251-
,'TR'-
,UNISTR(-
'Proje Y\00f6netimi - V'-
),UNISTR(-
'Vision i\00e7in Proje Y\00f6netimi Yaz\0131l\0131m\0131. Yaz\0131l'||-
'\0131m, komut sat\0131r\0131 ve metin, grafik, elektronik tablo ve '||-
'\00f6zelle\015ftirilebilir rapor formatlar\0131 olan grafik aray\00fcz'||-
'\00fc i\00e7erir.'-
));
INSERT INTO product_descriptions VALUES(3252-
,'TR'-
,UNISTR(-
'Proje Y\00f6netimi - S3.3'-
),UNISTR(-
'SPNIX V3.3 i\00e7in Proje Y\00f6netimi Yaz\0131l\0131m\0131. Yaz'||-
'\0131l\0131m, komut sat\0131r\0131 ve metin, grafik, elektronik tablo '||-
've \00f6zelle\015ftirilebilir rapor formatlar\0131 olan grafik aray'||-
'\00fcz\00fc i\00e7erir.'-
));
INSERT INTO product_descriptions VALUES(3253-
,'TR'-
,UNISTR(-
'Smart Suite - S4.0/EN'-
),UNISTR(-
'SPNIX V4.0 i\00e7in Office Suite (SmartWrite, SmartArt, SmartSpread, Smar'||-
'tBrowse). \0130ngilizce yaz\0131l\0131m ve kullan\0131c\0131 manuelle'||-
'ri.'-
));
INSERT INTO product_descriptions VALUES(3257-
,'TR'-
,UNISTR(-
'Web G\00f6zat\0131c\0131s\0131 - SB/S 2.1'-
),UNISTR(-
'Yaz\0131l\0131m Seti Web G\00f6zat\0131c\0131s\0131: SPNIX V3.3 i'||-
'\00e7in SmartBrowse V2.1. Ba\011flama duyarl\0131 yard\0131m dosyalar'||-
'\0131 ve online dok\00fcman.'-
));
INSERT INTO product_descriptions VALUES(3258-
,'TR'-
,UNISTR(-
'Web G\00f6zat\0131c\0131s\0131 - SB/V 1.0'-
),UNISTR(-
'Yaz\0131l\0131m Seti Web Taray\0131c\0131s\0131: Vision i\00e7in Sma'||-
'rtBrowse V2.1. Ba\011flama duyarl\0131 yard\0131m dosyalar\0131 ve onl'||-
'ine dok\00fcman.'-
));
INSERT INTO product_descriptions VALUES(3362-
,'TR'-
,UNISTR(-
'Web G\00f6zat\0131c\0131s\0131 - SB/S 4.0'-
),UNISTR(-
'Yaz\0131l\0131m Seti Web G\00f6zat\0131c\0131s\0131: SPNIX V4.0 i'||-
'\00e7in SmartBrowse V4.0. Ba\011flama duyarl\0131 yard\0131m dosyalar'||-
'\0131 ve online dok\00fcman.'-
));
INSERT INTO product_descriptions VALUES(2231-
,'TR'-
,UNISTR(-
'Masa - S/V'-
),UNISTR(-
'Standart boyutlu masa; sermaye olarak kullan\0131labilir, vergilendirileb'||-
'ilir kalem. Son kat, sipari\015f s\0131ras\0131nda stokta bulunan kapla'||-
'ma malzemesiyle (me\015fe, di\015fbudak, kiraz ve maun) yap\0131l\0131'||-
'r.'-
));
INSERT INTO product_descriptions VALUES(2335-
,'TR'-
,UNISTR(-
'Cep telefonu'-
),UNISTR(-
'D\00fc\015f\00fck pil t\00fcketimi olan iki bant cep telefonu. Hafif, '||-
'katlanabilir, tek kulakl\0131k yuvas\0131 ve yedek pil b\00f6lmesi.'-
));
INSERT INTO product_descriptions VALUES(2350-
,'TR'-
,UNISTR(-
'Masa - W/48'-
),UNISTR(-
'Masa - 48 in\00e7 kavissiz beyaz laminat; sermaye olarak kullan\0131labi'||-
'lir, vergilendirilebilir kalem.'-
));
INSERT INTO product_descriptions VALUES(2351-
,'TR'-
,UNISTR(-
'Masa - W/48/R'-
),UNISTR(-
'Masa - 48 in\00e7 kavisli 60 in\00e7 beyaz laminat; sermaye olarak kulla'||-
'n\0131labilir, vergilendirilebilir kalem.'-
));
INSERT INTO product_descriptions VALUES(2779-
,'TR'-
,UNISTR(-
'Masa - OS/O/F'-
),UNISTR(-
'Dosya \00e7ekmeceleri bulunan y\00f6netici stili b\00fcy\00fck boyutlu'||-
' me\015fe masa. Son kat sipari\015f s\0131ras\0131nda \00f6zelle'||-
'\015ftirilebilir, a\00e7\0131k, koyu me\015fe boyal\0131 veya do'||-
'\011fal elle boyama olarak sat\0131n al\0131nabilir.'-
));
INSERT INTO product_descriptions VALUES(3337-
,'TR'-
,UNISTR(-
'Mobil Web Telefonu'-
),UNISTR(-
'Web eri\015fimi i\00e7in ayl\0131k \00fccretli cep telefonu. \0130nce'||-
' \015fekil, deri g\00f6r\00fcn\00fcml\00fc ta\015f\0131ma kab\0131'||-
' ve kemer klipsi.'-
));
INSERT INTO product_descriptions VALUES(2091-
,'TR'-
,UNISTR(-
'Bloknot LW 8 1/2 x 11'-
),UNISTR(-
'Bloknot, \00e7izgili, beyaz, boyut 8 1/2 x 11 in\00e7'-
));
INSERT INTO product_descriptions VALUES(2093-
,'TR'-
,UNISTR(-
'T\00fckenmez Kalemler - 10/FP'-
),UNISTR(-
'Kal\0131c\0131 m\00fcrekkepli kalem \00e7abuk kurur ve bula\015fmaz. '||-
'P\00fcr\00fczs\00fcz ve kesintisiz yaz\0131 sa\011flar. \0130nce u'||-
'\00e7lu. Tek (siyah, mavi, k\0131rm\0131z\0131) veya kar\0131\015f'||-
'\0131k renkli kutu (6 siyah, 3 mavi ve 1 k\0131rm\0131z\0131).'-
));
INSERT INTO product_descriptions VALUES(2144-
,'TR'-
,UNISTR(-
'Kart D\00fczenleyici Kapak'-
),UNISTR(-
'Masa \00fcst\00fc stili kartvizit tutucu i\00e7in yedek kapak. Duman gr'||-
'isi (orijinal renk) veya saf plastik.'-
));
INSERT INTO product_descriptions VALUES(2336-
,'TR'-
,UNISTR(-
'Kartvizit Kutusu - 250'-
),UNISTR(-
'Kartvizit kutusu, kapasite 250. Sipari\015f verirken BC110-2, Rev. 3/2000'||-
' formunu (bas\0131l\0131 veya online) kullan\0131n ve y\0131ld\0131z '||-
'i\015faretli t\00fcm alanlar\0131 doldurun.'-
));
INSERT INTO product_descriptions VALUES(2337-
,'TR'-
,UNISTR(-
'Kartvizit - 1000/2L'-
),UNISTR(-
'Kartvizit kutusu, kapasite 1000, Her iki taraf\0131nda farkl\0131 dil bu'||-
'lunan 2 y\00f6nl\00fc model. Sipari\015f verirken BC111-2, Rev. 12/1999'||-
' (bas\0131l\0131 veya online) formunu kullan\0131n - y\0131ld\0131z i'||-
'\015faretli t\00fcm alanlar\0131 doldurun ve ikinci dil i\00e7in kutuy'||-
'u i\015faretleyin (\0130ngilizce her zaman birinci y\00fczdedir).'-
));
INSERT INTO product_descriptions VALUES(2339-
,'TR'-
,UNISTR(-
'Ka\011f\0131t - Standart Yaz\0131c\0131'-
),UNISTR(-
'20 lb. 8.5x11 in\00e7 beyaz lazer yaz\0131c\0131 ka\011f\0131d\0131 '||-
'(geri d\00f6n\00fc\015f\00fcml\00fc), on adet 500 ka\011f\0131tl'||-
'\0131k top'-
));
INSERT INTO product_descriptions VALUES(2536-
,'TR'-
,UNISTR(-
'Kartvizit - 250/2L'-
),UNISTR(-
'Kartvizit kutusu, kapasite 250, her iki taraf\0131ndan farkl\0131 dil bu'||-
'lunan 2 y\00f6nl\00fc model. Sipari\015f verirken BC111-2, D\00fcz. 12'||-
'/1999 (bas\0131l\0131 veya online) kullan\0131n - y\0131ld\0131zla i'||-
'\015faretli t\00fcm alanlar\0131 doldurun ve ikinci dil i\00e7in kutuy'||-
'u i\015faretleyin (\0130ngilizce her zaman birinci y\00fczdedir).'-
));
INSERT INTO product_descriptions VALUES(2537-
,'TR'-
,UNISTR(-
'Kartvizit Kutusu - 1000'-
),UNISTR(-
'Kartvizit kutusu, kapasite 1000. Sipari\015f verirken BC110-3, D\00fcz. '||-
'3/2000\0027i (bas\0131l\0131 veya online) kullan\0131n ve y\0131ld'||-
'\0131zla i\015faretli t\00fcm alanlar\0131 doldurun.'-
));
INSERT INTO product_descriptions VALUES(2783-
,'TR'-
,UNISTR(-
'Klips - Ka\011f\0131t'-
),UNISTR(-
'D\00fcnya markas\0131 ka\011f\0131t klips seti kalite standart\0131nd'||-
'a. Her birinde 100 klips bulunan 10 kutu. No.1 normal veya jumbo, d\00fcz'||-
' veya k\0131zaks\0131z.'-
));
INSERT INTO product_descriptions VALUES(2808-
,'TR'-
,UNISTR(-
'Bloknot LY 8 1/2 x 11'-
),UNISTR(-
'Bloknot, \00c7izgili, Sar\0131, boyut 8 1/2 x 11 in\00e7'-
));
INSERT INTO product_descriptions VALUES(2810-
,'TR'-
,UNISTR(-
'M\00fcrekkebi G\00f6r\00fclebilir T\00fckenmez Kalemler'-
),UNISTR(-
'Hassas yuvarlak u\00e7lu t\00fckenmez kalem. \0130\00e7i g\00f6r'||-
'\00fcnebilir kau\00e7uk tutma k\0131sm\0131 m\00fcrekkep durumunu g'||-
'\00f6sterir ve rahat yazmaya olanak sa\011flar. Siyah, mavi, k\0131rm'||-
'\0131z\0131 ve ye\015fil renklerden birer adet bulunan 4\0027l\00fc p'||-
'aket.'-
));
INSERT INTO product_descriptions VALUES(2870-
,'TR'-
,UNISTR(-
'Kur\015fun Kalem - Mekanik'-
),UNISTR(-
'Yazma konforunu art\0131rmak i\00e7in ergonomik olarak tasarlanm\0131'||-
'\015f mekanik kur\015fun kalem. Yeniden doldurulabilir silgiler ve kur'||-
'\015fun u\00e7lar. \00dc\00e7 kur\015fun u\00e7 boyutu mevcuttur: .5'||-
'mm (ince) .7mm (orta) ve .9mm (kal\0131n).'-
));
INSERT INTO product_descriptions VALUES(3051-
,'TR'-
,UNISTR(-
'T\00fckenmez Kalemler - 10/MP'-
),UNISTR(-
'Kal\0131c\0131 m\00fcrekkepli kalem \00e7abuk kurur ve bula\015fmaz. '||-
'P\00fcr\00fczs\00fcz ve kesintisiz yaz\0131 sa\011flar. Orta boylu u'||-
'\00e7. Tek (siyah, mavi, k\0131rm\0131z\0131) veya kar\0131\015f'||-
'\0131k renkli kutu (6 siyah, 3 mavi ve 1 k\0131rm\0131z\0131).'-
));
INSERT INTO product_descriptions VALUES(3150-
,'TR'-
,UNISTR(-
'Kartvizit Kab\0131 - 25'-
),UNISTR(-
'Kartvizit Kab\0131; kabartmal\0131 \015firket logosu bulunan a\011f'||-
'\0131r plastik kartvizit kab\0131. Kart kal\0131nl\0131\011f\0131na '||-
'ba\011fl\0131 olarak yakla\015f\0131k 25 adet kartvizitinizi saklayabi'||-
'lir.'-
));
INSERT INTO product_descriptions VALUES(3208-
,'TR'-
,UNISTR(-
'Kur\015fun Kalemler - A\011fa\00e7'-
),UNISTR(-
'2 d\00fczine a\011fa\00e7 kur\015fun kalem kutusu. Sipari\015f verirk'||-
'en kur\015fun tipini belirtin: 2H (iki kat sert), H (sert), HB (sert siya'||-
'h), B (yumu\015fak siyah).'-
));
INSERT INTO product_descriptions VALUES(3209-
,'TR'-
,UNISTR(-
'Kalemt\0131ra\015f'-
),UNISTR(-
'Elektrikli Kalemt\0131ra\015f, Uzun \00f6m\00fcrl\00fc sa\011flam '||-
'\00e7elik b\0131\00e7aklar. Kalem Koruyucu, kalemin fazla a\00e7\0131'||-
'lmas\0131n\0131 \00f6nlemeye yard\0131mc\0131 olur. K\0131zaks\0131'||-
'z kau\00e7uk ayaklar. Yerle\015fik kalem tutucu.'-
));
INSERT INTO product_descriptions VALUES(3224-
,'TR'-
,UNISTR(-
'Kartvizit D\00fczenleyicisi - 250'-
),UNISTR(-
'Kartvizitleri d\00fczenlemek i\00e7in ta\015f\0131nabilir tutucu, kapa'||-
'site 250 adet. Kartvizitler i\00e7in kitap\00e7\0131k stilinde, i\00e7'||-
'e do\011fru saydam cepler. \0130ste\011fe ba\011fl\0131 alfabetik sek'||-
'meler. Sipari\015f verirken rengi belirtin (koyu kahve, bej, burgonya '||-
'\015farab\0131 k\0131rm\0131z\0131s\0131, siyah ve a\00e7\0131k gr'||-
'i).'-
));
INSERT INTO product_descriptions VALUES(3225-
,'TR'-
,UNISTR(-
'Kartvizit D\00fczenleyicisi - 1000'-
),UNISTR(-
'Alfabetik ay\0131r\0131c\0131lara sahip kartvizit tutucu; kapasite 1000'||-
'. Duman grisi kapak ve siyah tabanl\0131 masa\00fcst\00fc stili tutucu.'||-
' \00c7ekmece i\00e7inde saklamak i\00e7in kapak \00e7\0131kar\0131la'||-
'bilir.'-
));
INSERT INTO product_descriptions VALUES(3511-
,'TR'-
,UNISTR(-
'Ka\011f\0131t - HQ Yaz\0131c\0131'-
),UNISTR(-
'Yaz\0131c\0131 s\0131k\0131\015fmalar\0131na kar\015f\0131 dayan'||-
'\0131kl\0131l\0131k testi uygulanm\0131\015f, m\00fcrekkep p\00fcsk'||-
'\00fcrtmeli ve lazer yaz\0131c\0131lar i\00e7in kaliteli ka\011f'||-
'\0131t. Ar\015fivlemede kullanmak amac\0131yla asitsiz. 92 parlakl'||-
'\0131\011f\0131nda 22lb. a\011f\0131rl\0131\011f\0131nda. Boyut 8 '||-
'1/2 x 11 in\00e7. Tek 500 sayfal\0131k ka\011f\0131t topu.'-
));
INSERT INTO product_descriptions VALUES(3515-
,'TR'-
,UNISTR(-
'Yedek Kur\015fun'-
),UNISTR(-
'Mekanik kur\015fun kalemler i\00e7in yeniden doldurulabilir u\00e7lar. '||-
'Her paket 25 u\00e7 ve yedek silgi i\00e7erir. \00dc\00e7 u\00e7 boyu'||-
'tunda mevcuttur: .5mm (ince), .7mm (orta) ve .9mm (kal\0131n).'-
));
INSERT INTO product_descriptions VALUES(2986-
,'TR'-
,UNISTR(-
'Manuel - Vision OS/2x +'-
),UNISTR(-
'Vision \0130\015fletim Sistemi V 2.x ve Vision Office Suite i\00e7in ma'||-
'nueller'-
));
INSERT INTO product_descriptions VALUES(3163-
,'TR'-
,UNISTR(-
'Manuel - Vision Net6.3/US'-
),UNISTR(-
'Vision Networking V6.3 Ba\015fvuru Manueli. Geli\015fmi\015f \015fifre'||-
'lemeli ABD s\00fcr\00fcm\00fc.'-
));
INSERT INTO product_descriptions VALUES(3165-
,'TR'-
,UNISTR(-
'Manuel - Vision Ara\00e7lar\01312.0'-
),UNISTR(-
'Vision \0130\015f Ara\00e7lar\0131 Tak\0131m\0131 V2.0 Ba\015fvuru '||-
'Manueli. Y\00fckleme, konfig\00fcrasyon ve kullan\0131m k\0131lavuzu i'||-
'\00e7erir.'-
));
INSERT INTO product_descriptions VALUES(3167-
,'TR'-
,UNISTR(-
'Manuel - Vision \0130S/2.x'-
),UNISTR(-
'Vision \0130\015fletim Sistemi V2.0/2.1/2/3 Ba\015fvuru Manueli. Vision'||-
' sistem y\00f6netimi i\00e7in tam y\00fckleme, konfig\00fcrasyon, y'||-
'\00f6netim ve ayar bilgileri. Bu manuelin tek S\00fcr\00fcm 2.0 ve 2.1 '||-
'manuellerinin yerine ge\00e7ti\011fine dikkat edin.'-
));
INSERT INTO product_descriptions VALUES(3216-
,'TR'-
,UNISTR(-
'Manuel - Vision Net6.3'-
),UNISTR(-
'Vision Networking V6.3 Ba\015fvuru Manueli. Basit \015fifrelemeli ABD d'||-
'\0131\015f\0131 s\00fcr\00fcm.'-
));
INSERT INTO product_descriptions VALUES(3220-
,'TR'-
,UNISTR(-
'Manuel - Vision OS/1.2'-
),UNISTR(-
'Vision \0130\015fletim Sistemi V1.2 Ba\015fvuru Manueli. Vision sistem '||-
'y\00f6netimi i\00e7in tam kurulum, konfig\00fcrasyon, y\00f6netim ve a'||-
'yarlama bilgileri.'-
));
INSERT INTO product_descriptions VALUES(1729-
,'TR'-
,UNISTR(-
'Kimyasal Maddeler - RCP'-
),UNISTR(-
'Kimyasal Temizlik Malzemeleri - 3500 silindir temizlik pe\00e7etesi'-
));
INSERT INTO product_descriptions VALUES(1910-
,'TR'-
,UNISTR(-
'CE Malzeme - H'-
),UNISTR(-
'Cam Elyaf Levha - dayan\0131kl\0131, 1 kal\0131n'-
));
INSERT INTO product_descriptions VALUES(1912-
,'TR'-
,UNISTR(-
'P\00c7 Malzeme - 3mm'-
),UNISTR(-
'Paslanmaz \00e7elik levha - 3mm. Standart g\00fc\00e7 kaynaklar\0131, '||-
'ana kart tutucular ve sabit s\00fcr\00fcc\00fcler i\00e7in \00f6ncede'||-
'n delik a\00e7\0131labilir. L\00fctfen, delinmi\015f levha i\00e7in s'||-
'ipari\015f verirken, haz\0131r levhan\0131n model numaras\0131n\0131,'||-
' yerle\015fimini ve boyutunu tan\0131mlamak i\00e7in uygun \015fablonu'||-
' kullan\0131n.'-
));
INSERT INTO product_descriptions VALUES(1940-
,'TR'-
,UNISTR(-
'ESD Kelep\00e7e/Klips'-
),UNISTR(-
'Bilgisayar kasas\0131na veya ba\015fka bir yere kolay ba\011flant\0131'||-
' i\00e7in krokodil pensi bulunan elektro statik de\015farj kelep\00e7es'||-
'i'-
));
INSERT INTO product_descriptions VALUES(2030-
,'TR'-
,UNISTR(-
'Lateks Eldivenler'-
),UNISTR(-
'Montajc\0131lar, kimyasal madde ta\015f\0131y\0131c\0131lar\0131 ve '||-
'tesisat\00e7\0131lar i\00e7in Latex Eldivenler. Parmak b\00f6lgeleri k'||-
'avrama noktas\0131 dokulu, dayan\0131kl\0131, g\00fcvenlik turuncusu r'||-
'enkli. Su ge\00e7irmez ve en \00e7ok 220 volt/2 amper, 110 volt/5 amper '||-
'\015foka dayan\0131kl\0131. 5 dakika s\00fcresince aside dayan\0131kl'||-
'\0131.'-
));
INSERT INTO product_descriptions VALUES(2326-
,'TR'-
,UNISTR(-
'Plastik Malzeme - Y'-
),UNISTR(-
'Plastik Malzeme - Sar\0131, standart kalitede.'-
));
INSERT INTO product_descriptions VALUES(2330-
,'TR'-
,UNISTR(-
'Plastik Malzeme - R'-
),UNISTR(-
'Plastik Malzeme - K\0131rm\0131z\0131, standart kalitede.'-
));
INSERT INTO product_descriptions VALUES(2334-
,'TR'-
,UNISTR(-
'Re\00e7ine'-
),UNISTR(-
'Genel kullan\0131m ama\00e7l\0131 sentetik re\00e7ine'-
));
INSERT INTO product_descriptions VALUES(2340-
,'TR'-
,UNISTR(-
'Kimyasal Maddeler - SW'-
),UNISTR(-
'Kimyasal Temizleme Malzemeleri - 3500 anti-statik temizleme bezi'-
));
INSERT INTO product_descriptions VALUES(2365-
,'TR'-
,UNISTR(-
'Kimyasal Maddeler - TCS'-
),UNISTR(-
'Kimyasal Temizlik Maddesi - 2500 ta\015f\0131t temizleme bezi'-
));
INSERT INTO product_descriptions VALUES(2594-
,'TR'-
,UNISTR(-
'CE Malzeme - L'-
),UNISTR(-
'Cam Elyaf Levha - dahili \0131s\0131 yal\0131t\0131m\0131 i\00e7in h'||-
'afif malzeme, 1/4 kal\0131nl\0131kta'-
));
INSERT INTO product_descriptions VALUES(2596-
,'TR'-
,UNISTR(-
'Paslanmaz \00c7elik Levha - 1mm'-
),UNISTR(-
'Paslanmaz \00e7elik levha - 3mm. Standart model g\00fc\00e7 kaynaklar'||-
'\0131, ana kart ve pil tutucular\0131 i\00e7in \00f6nceden delik a'||-
'\00e7\0131labilir. L\00fctfen, delinmi\015f levha i\00e7in sipari'||-
'\015f verirken, haz\0131r levhan\0131n model numaras\0131n\0131, yerl'||-
'e\015fimini ve boyutunu tan\0131mlamak i\00e7in uygun \015fablonu kull'||-
'an\0131n.'-
));
INSERT INTO product_descriptions VALUES(2631-
,'TR'-
,UNISTR(-
'ESD Kelep\00e7e/QR'-
),UNISTR(-
'Elektro Statik De\015farj Kelep\00e7esi: h\0131zl\0131 sal\0131verme '||-
'konekt\00f6rl\00fc 2 par\00e7a kur\015fun. Bir par\00e7as\0131 s'||-
'\00fcrekli vidal\0131 olarak bilgisayar kasas\0131na tak\0131l\0131 k'||-
'al\0131r, di\011feri kelep\00e7eye tak\0131l\0131r. Ek kal\0131c'||-
'\0131 u\00e7lar mevcut.'-
));
INSERT INTO product_descriptions VALUES(2721-
,'TR'-
,UNISTR(-
'Ki\015fisel Bilgisayar \00c7antas\0131 - L/S'-
),UNISTR(-
'Siyah Deri Bilgisayar \00c7antas\0131 - manueller, ek donan\0131m ve '||-
'\00e7al\0131\015fma ka\011f\0131tlar\0131 i\00e7in cebi olan tek di'||-
'z\00fcst\00fc kapasitesi. Ayarlanabilir koruyucu \015feritler ve g'||-
'\00fc\00e7 kayna\011f\0131 ve kablolar i\00e7in \00e7\0131kart'||-
'\0131labilir cep.'-
));
INSERT INTO product_descriptions VALUES(2722-
,'TR'-
,UNISTR(-
'Ki\015fisel Bilgisayar \00c7antas\0131 - L/D'-
),UNISTR(-
'Siyah Deri Bilgisayar \00c7antas\0131 - ek donan\0131m, manueller ve '||-
'\00e7al\0131\015fma ka\011f\0131tlar\0131 i\00e7in cebi olan \00e7'||-
'ift diz\00fcst\00fc bilgisayar ta\015f\0131y\0131c\0131s\0131. Ayar'||-
'lanabilir koruyucu \015feritler, g\00fc\00e7 kayna\011f\0131 ve kablo'||-
'lar i\00e7in \00e7\0131kart\0131labilir cep. Kolay ta\015f\0131ma i'||-
'\00e7in iki kat geni\015flikte omuz ask\0131s\0131.'-
));
INSERT INTO product_descriptions VALUES(2725-
,'TR'-
,UNISTR(-
'Makine Ya\011f\0131'-
),UNISTR(-
'CD-ROM s\00fcr\00fcc\00fc kapaklar\0131n\0131 ve k\0131zaklar\0131n'||-
'\0131 ya\011flamak i\00e7in Makine Ya\011f\0131. \0130nce ve orta ak'||-
'\0131\015f i\00e7in kendi kendini temizleyen ayarlanabilir a\011f'||-
'\0131zl\0131kl\0131.'-
));
INSERT INTO product_descriptions VALUES(2782-
,'TR'-
,UNISTR(-
'Ki\015fisel Bilgisayar \00c7antas\0131 - C/S'-
),UNISTR(-
'Kanvas Bilgisayar \00c7antas\0131 - manueller, ek donan\0131m ve \00e7'||-
'al\0131\015fma ka\011f\0131tlar\0131 i\00e7in cepleri olan tek diz'||-
'\00fcst\00fc ta\015f\0131y\0131c\0131s\0131. Ayarlanabilir koruyucu'||-
' \015feritler ve g\00fc\00e7 kayna\011f\0131 ve kablolar i\00e7in '||-
'\00e7\0131kart\0131labilir cep. Seyahat s\0131ras\0131nda kolay eri'||-
'\015fim i\00e7in \00e7\0131t\00e7\0131tl\0131 kapanma \00f6zelli'||-
'\011fine sahip d\0131\015f cep.'-
));
INSERT INTO product_descriptions VALUES(3187-
,'TR'-
,UNISTR(-
'Plastik Levha - B/HD'-
),UNISTR(-
'Plastik Levha - Mavi, y\00fcksek yo\011funluk.'-
));
INSERT INTO product_descriptions VALUES(3189-
,'TR'-
,UNISTR(-
'Plastik Levha - G'-
),UNISTR(-
'Plastik Levha - Ye\015fil, standart yo\011funluk.'-
));
INSERT INTO product_descriptions VALUES(3191-
,'TR'-
,UNISTR(-
'Plastik Levha - O'-
),UNISTR(-
'Plastik Levha - Turuncu, standart yo\011funluk.'-
));
INSERT INTO product_descriptions VALUES(3193-
,'TR'-
,UNISTR(-
'Plastik Levha - W/HD'-
),UNISTR(-
'Plastik Levha - Beyaz, y\00fcksek yo\011funluk.'-
));
commit;
set define on
